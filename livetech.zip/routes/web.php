<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\front\frontview;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\testimonialController;
use App\Http\Controllers\newsmediaController;
use App\Http\Controllers\dashboardController;
use App\Http\Controllers\blogController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

// -----------------------------Start Front Views----------------

Route::get('/',[frontview::class,'home']);
Route::get('/about',[frontview::class,'about']);
Route::get('/gallery',[frontview::class,'gallery']);
Route::get('/services',[frontview::class,'services']);
Route::get('/contact-us',[frontview::class,'contact']);

Route::get('/vision-and-mission',[frontview::class,'vision']);
Route::get('/video-editing',[frontview::class,'video']);

Route::get('/media',[frontview::class,'media']);
Route::get('/test',[frontview::class,'test']);

Route::get('/career',[frontview::class,'career']);
Route::post('/resume_form/',[frontview::class,'insertResume']);

Route::get('/casestudy',[frontview::class,'casestudy']);
Route::get('/casestudydetails',[frontview::class,'casestudydetails']);

Route::get('/blog',[frontview::class,'blog']);
Route::get('/blogdetails/{id}',[frontview::class,'blogdetails']);

Route::get('/page/{type}',[frontview::class,'page']);
Route::get('/pagedetails/{slug}',[frontview::class,'pagedetails']);

Route::get('/page2/{type}',[frontview::class,'page2']);
Route::get('/pagedetails2/{slug}',[frontview::class,'pagedetails2']);

Route::get('/page3/{type}',[frontview::class,'page3']);
Route::get('/pagedetails3/{slug}',[frontview::class,'pagedetails3']);

Route::get('/page4/{type}',[frontview::class,'page4']);
Route::get('/pagedetails4/{slug}',[frontview::class,'pagedetails4']);

Route::get('/page5/{type}',[frontview::class,'page5']);
Route::get('/pagedetails5/{slug}',[frontview::class,'pagedetails5']);

Route::get('/page6/{type}',[frontview::class,'page6']);
Route::get('/pagedetails6/{slug}',[frontview::class,'pagedetails6']);

Route::get('/page7/{type}',[frontview::class,'page7']);
Route::get('/pagedetails7/{slug}',[frontview::class,'pagedetails7']);

Route::get('/contact/',[frontview::class,'contact']);
Route::post('/contact_form/',[frontview::class,'insert']);


// -----------------------------End Front Views----------------


// -----------------------Start Admin Panel ----------------------

Route::get('admin/',[AdminController::class,'index']);

Route::post('/admin/login_submit',[AdminController::class,'auth']);

Route::group(['middleware'=>'admin_auth'],function(){

    Route::get('admin/dashboard',[AdminController::class,'dashboard']);

    //------------Start Pages----------------
    Route::get('admin/pages',[PageController::class,'index']);
    Route::get('admin/pages/add-page',[PageController::class,'show']);
    Route::post('/admin/pages/insert',[PageController::class,'insert']);
    Route::get('admin/pages/edit/{id}',[PageController::class,'edit']);
    Route::post('/admin/pages/update/{id}',[PageController::class,'update']);
    Route::get('admin/pages/delete/{id}',[PageController::class,'delete']);

    Route::get('admin/pages/editbanner/{id}',[PageController::class,'editbanner']);
    Route::post('/admin/pages/updatebanner/{id}',[PageController::class,'updatebanner']);


    //********** END************

    //------------Start Testimonials----------------
    Route::get('admin/testi',[testimonialController::class,'index']);
    Route::get('admin/testi/add-testi',[testimonialController::class,'show']);
    Route::post('/admin/testi/insert',[testimonialController::class,'insert']);
    Route::get('admin/testi/edit/{id}',[testimonialController::class,'edit']);
    Route::post('/admin/testi/update/{id}',[testimonialController::class,'update']);
    Route::get('admin/testi/delete/{id}',[testimonialController::class,'delete']);
    //********** END************

    //------------Start Blogs----------------
    Route::get('admin/blogs',[blogController::class,'index']);
    Route::get('admin/blogs/add-blogs',[blogController::class,'show']);
    Route::post('/admin/blogs/insert',[blogController::class,'insert']);
    Route::get('admin/blogs/edit/{id}',[blogController::class,'edit']);
    Route::post('/admin/blogs/update/{id}',[blogController::class,'update']);
    Route::get('admin/blogs/delete/{id}',[blogController::class,'delete']);
    //********** END************

    //------------Start News----------------
    Route::get('admin/news',[newsmediaController::class,'index']);
    Route::get('admin/news/add-news',[newsmediaController::class,'show']);
    Route::post('/admin/news/insert',[newsmediaController::class,'insert']);
    Route::get('admin/news/edit/{id}',[newsmediaController::class,'edit']);
    Route::post('/admin/news/update/{id}',[newsmediaController::class,'update']);
    Route::get('admin/news/delete/{id}',[newsmediaController::class,'delete']);
    //********** END************

    //------------Start Gallery----------------
    Route::get('admin/gallery',[dashboardController::class,'index']);
    Route::get('admin/gallery/add-gallery',[dashboardController::class,'show']);
    Route::post('/admin/gallery/insert',[dashboardController::class,'insert']);
    Route::get('admin/gallery/edit/{id}',[dashboardController::class,'edit']);
    Route::post('/admin/gallery/update/{id}',[dashboardController::class,'update']);
    Route::get('admin/gallery/delete/{id}',[dashboardController::class,'delete']);
    //********** END************

    Route::get('admin/contactlist',[dashboardController::class,'contactlist']);
    Route::get('admin/contactlists/contactdeleted/{id}',[dashboardController::class,'deletecontactlist']);

    Route::get('admin/resumelist',[dashboardController::class,'resumelist']);
    Route::get('admin/resumelists/resumedeleted/{id}',[dashboardController::class,'deleteresumelist']);


    Route::get('admin/logout', function () {
        session()->forget('ADMIN_LOGIN');
        session()->forget('ADMIN_ID');
        session()->flash('error','Logout sucessfully');
        return redirect('admin/');
    });


});


// -----------------------End Admin Panel ----------------------
