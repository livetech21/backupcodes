<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Admin;

class AdminController extends Controller
{
    public function index(Request $request)

    {
        if($request->session()->has('ADMIN_LOGIN')){
            return redirect('admin/dashboard');
        }else{
            return view('admin.adminlogin');
        }
        return view('admin.adminlogin');
      }

    public function auth(Request $request)
    {
        $username=$request->post('username');
        $password=$request->post('password');

        $result=Admin::where(['username'=>$username,'password'=>$password])->get();
        if(isset($result['0']->id)){
            $request->session()->put('ADMIN_LOGIN',true);
            $request->session()->put('ADMIN_ID',$result['0']->id);

            return redirect('admin/dashboard');
        }else{
            $request->session()->flash('error','Incorrect Username or Password!!');
            return redirect('admin/');
        }

    }

    public function dashboard()
    {
        return view('admin.dashboard');
    }

}
