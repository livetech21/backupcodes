<?php

namespace App\Http\Controllers\front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use Storage;
use File;

class frontview extends Controller
{
    public function home()
    {
        return view('front/home');
    }

    public function about()
    {
        return view('front/about');
    }

    public function gallery()
    {
        $gallery= DB::table('galleries')->get();
        return view('front/gallery',['gallery'=>$gallery]);
    }

    public function services()
    {
        return view('front/services');
    }

    public function contact()
    {
        return view('front/contact');
    }

    public function video()
    {
        return view('front/video');
    }

    public function vision()
    {
        return view('front/vision');
    }

    public function newsmedia()
    {
        return view('front/newsmedia');
    }

    // public function blog()
    // {
    //     return view('front/blog');
    // }


    public function blog()
    {
        $blog1= DB::table('blogs')->limit(1)->get();
        $blog= DB::table('blogs')->get();
        return view('front/blog',['blog'=>$blog,'blog1'=>$blog1]);
    }

    public function blogdetails($id)
    {
        $data=DB::table('blogs')->where('id',$id)->get();
        $blog= DB::table('blogs')->get();
        return view('front/blogdetails',['data'=>$data,'blog'=>$blog]);
    }


    public function page($type)
    {
        $page= DB::table('pages')->where('type',$type)->get();
        return view('front/page',['page'=>$page]);
    }
    public function pagedetails($slug)
    {
        $page=DB::table('pages')->where('slug',$slug)->get();
        return view('front/pagedetails',['page'=>$page]);
    }


    public function page2($type)
    {
        $page= DB::table('pages')->where('type',$type)->get();
        return view('front/page2',['page'=>$page]);
    }
    public function pagedetails2($slug)
    {
        $page=DB::table('pages')->where('slug',$slug)->get();
        return view('front/pagedetails2',['page'=>$page]);
    }

    public function page3($type)
    {
        $page= DB::table('pages')->where('type',$type)->get();
        return view('front/page3',['page'=>$page]);
    }
    public function pagedetails3($slug)
    {
        $page=DB::table('pages')->where('slug',$slug)->get();
        return view('front/pagedetails3',['page'=>$page]);
    }

    public function page4($type)
    {
        $page= DB::table('pages')->where('type',$type)->get();
        return view('front/page4',['page'=>$page]);
    }
    public function pagedetails4($slug)
    {
        $page=DB::table('pages')->where('slug',$slug)->get();
        return view('front/pagedetails4',['page'=>$page]);
    }

    public function page5($type)
    {
        $page= DB::table('pages')->where('type',$type)->get();
        return view('front/page5',['page'=>$page]);
    }
    public function pagedetails5($slug)
    {
        $page=DB::table('pages')->where('slug',$slug)->get();
        return view('front/pagedetails5',['page'=>$page]);
    }

    public function page6($type)
    {
        $page= DB::table('pages')->where('type',$type)->get();
        return view('front/page6',['page'=>$page]);
    }
    public function pagedetails6($slug)
    {
        $page=DB::table('pages')->where('slug',$slug)->get();
        return view('front/pagedetails6',['page'=>$page]);
    }

    public function page7($type)
    {
        $page= DB::table('pages')->where('type',$type)->get();
        return view('front/page7',['page'=>$page]);
    }
    public function pagedetails7($slug)
    {
        $page=DB::table('pages')->where('slug',$slug)->get();
        return view('front/pagedetails7',['page'=>$page]);
    }

    public function faq()
    {
        return view('front/faq');
    }

    public function test()
    {
        return view('front/test');
    }

    public function casestudy()
    {
        return view('front/casestudies');
    }
    public function casestudydetails()
    {
        return view('front/casestudydetails');
    }

    public function media()
    {
        return view('front/media');
    }

    public function career()
    {
        return view('front/career');
    }

    public function insert(Request $request)
    {
        $request->validate([
            'name'=>'required|max:30|regex:/^[A-Za-z0-9 ]+$/',
            'email'=>'required|max:60',
            'phone'=>'required|max:10|regex:/^[A-Za-z0-9 ]+$/',
            'subject'=>'required|max:60|regex:/^[A-Za-z0-9 ]+$/',
            'message'=>'required'


        ]);
        $data=array(
           'name'=>$request->input('name'),
           'email'=>$request->input('email'),
           'phone'=>$request->input('phone'),
           'sub'=>$request->input('subject'),
           'des'=>$request->input('message')

       );

       DB::table('contacts')->insert($data);

        $request->session()->flash('message','Thank you for contact us');
       return redirect('/contact');
    }


    public function insertResume(Request $request)
    {

        $request->validate([
            'name'=>'required|max:30|regex:/^[A-Za-z0-9 ]+$/',
            'email'=>'required',
            'phone'=>'required|max:10|regex:/^[A-Za-z0-9 ]+$/',
            'college'=>'',
            'qualification'=>'',
            'marks'=>'',
            'type'=>'',
            'skill'=>'',
            'address'=>'',
            'image'=>'required',
            'image1'=>'required'

        ]);

        $image=$request->file('image');
        $ext=$image->extension();
        $file=time().'.'.$ext;
        $image->move('uploads/resume/',$file);

        $image1=$request->file('image1');
        $ext1=$image1->extension();
        $file1=time().'-resume.'.$ext1;
        $image1->move('uploads/resume/',$file1);

        $data=array(
           'name'=>$request->input('name'),
           'email'=>$request->input('email'),
           'phone'=>$request->input('phone'),
           'college'=>$request->input('college'),
           'qualification'=>$request->input('qualification'),
           'marks'=>$request->input('marks'),
           'skill'=>$request->input('skill'),
           'type'=>$request->input('type'),
           'address'=>$request->input('address'),
           'photo'=>$file,
           'photo1'=>$file1

       );

       DB::table('careers')->insert($data);

        $request->session()->flash('message','Thank you !!');
       return redirect('/careers');
    }



}
