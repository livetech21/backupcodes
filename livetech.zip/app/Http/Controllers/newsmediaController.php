<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Newsmedia;
use Illuminate\Support\Facades\DB;

use Storage;
use File;

class newsmediaController extends Controller
{


    public function index()
    {
        $result['data']=Newsmedia::all();
        return view('admin/news-list',$result);
    }

    public function show()
    {
         return view('admin/news-add');

    }

    public function insert(Request $request)
    {

        if($request->hasfile('image')){

            $request->validate([

                'image'=>'required|mimes:jpeg,jpg,png',
                'name'=>'required',
                'link'=>'required',
                'description1'=>'required'

            ]);

            $image=$request->file('image');
            $ext=$image->extension();
            $file=time().'.'.$ext;
            $image->move('uploads/newsmedia/',$file);

            $data=array(
                'name'=>$request->input('name'),
                'link'=>$request->input('link'),
                'photo'=>$file,
                'des'=>$request->input('description1')
            );

            DB::table('newsmedias')->insert($data);

            $request->session()->flash('message','newsmedia Added Successfully!!');
           return redirect('admin/news');

        }else{
            $request->session()->flash('message','Please Add Correct Image!!');
            return redirect('admin/news/add-news');
        }


    }

    public function edit($id)
    {
       $data= DB::table('newsmedias')->where('id',$id)->get();
        return view('admin/news-edit',['data'=>$data]);

    }

    public function update(Request $request,$id)
    {
          $request->validate([

            'image'=>'mimes:jpeg,jpg,png'

        ]);

         $data=array(

            'name'=>$request->input('name'),
            'link'=>$request->input('link'),
            'des'=>$request->input('description1')

        );


        if($request->hasfile('image')){
          $arrImage=DB::table('newsmedias')->get();
            File::delete('uploads/newsmedia/'.$arrImage[0]->photo);

        $image=$request->file('image');
        $ext=$image->extension();
        $file=time().'.'.$ext;
        $image->move('uploads/newsmedia/',$file);
        $data['photo']=$file;

        DB::table('newsmedias')->where('id',$id)->update($data);

    }
    else{

        $data=array(
            'name'=>$request->input('name'),
            'link'=>$request->input('link'),
            'des'=>$request->input('description1')
        );

        DB::table('newsmedias')->where('id',$id)->update($data);

}

         $request->session()->flash('message','news Updated Successfully!!');
        return redirect('admin/news');
    }


    public function delete(Request $request,$id){
        $arrImage=DB::table('newsmedias')->where(['id'=>$id])->get();
        if(File::exists('uploads/newsmedia/'.$arrImage[0]->photo)){
            File::delete('uploads/newsmedia/'.$arrImage[0]->photo);
        }
        $model=Newsmedia::find($id);
        $model->delete();
        $request->session()->flash('message','news Deleted successfully!!');
        return redirect('admin/news');
    }

}
