<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Gallery;
use App\Models\Contact;
use App\Models\Career;
use Illuminate\Support\Facades\DB;

use Storage;
use File;

class dashboardController extends Controller
{

    public function index()
    {
        $result['data']=Gallery::all();
        return view('admin/gallery-list',$result);
    }

    public function show()
    {
         return view('admin/gallery-add');

    }

    public function insert(Request $request)
    {

        if($request->hasfile('image')){

            $request->validate([

                'image'=>'required|mimes:jpeg,jpg,png',
                'name'=>'required',
                'type'=>'required',
                'description1'=>'required'

            ]);

            $image=$request->file('image');
            $ext=$image->extension();
            $file=time().'.'.$ext;
            $image->move('uploads/gallery/',$file);

            $data=array(
                'name'=>$request->input('name'),
                'type'=>$request->input('type'),
                'photo'=>$file,
                'des'=>$request->input('description1')
            );

            DB::table('galleries')->insert($data);

            $request->session()->flash('message','Gallery Added Successfully!!');
           return redirect('admin/gallery');

        }else{
            $request->session()->flash('message','Please Add Correct Image!!');
            return redirect('admin/gallery/add-gallery');
        }


    }

    public function edit($id)
    {
       $data= DB::table('galleries')->where('id',$id)->get();
        return view('admin/gallery-edit',['data'=>$data]);

    }

    public function update(Request $request,$id)
    {
          $request->validate([

            'image'=>'mimes:jpeg,jpg,png'

        ]);

         $data=array(

            'name'=>$request->input('name'),
            'type'=>$request->input('type'),
            'des'=>$request->input('description1')

        );


        if($request->hasfile('image')){
          $arrImage=DB::table('galleries')->get();
            File::delete('uploads/gallery/'.$arrImage[0]->photo);

        $image=$request->file('image');
        $ext=$image->extension();
        $file=time().'.'.$ext;
        $image->move('uploads/gallery/',$file);
        $data['photo']=$file;

        DB::table('galleries')->where('id',$id)->update($data);

    }
    else{

        $data=array(
            'name'=>$request->input('name'),
            'type'=>$request->input('type'),
            'des'=>$request->input('description1')
        );

        DB::table('galleries')->where('id',$id)->update($data);

}

         $request->session()->flash('message','Gallery Updated Successfully!!');
        return redirect('admin/gallery');
    }


    public function delete(Request $request,$id){
        $arrImage=DB::table('galleries')->where(['id'=>$id])->get();
        if(File::exists('uploads/gallery/'.$arrImage[0]->photo)){
            File::delete('uploads/gallery/'.$arrImage[0]->photo);
        }
        $model=Gallery::find($id);
        $model->delete();
        $request->session()->flash('message','Gallery Deleted successfully!!');
        return redirect('admin/gallery');
    }


// --------------------------contact-list---------------

public function contactlist()
{
    $result['data']=Contact::all();
    return view('admin/contact-list',$result);
}

public function deletecontactlist(Request $request,$id)
{
    $model=Contact::find($id);
    $model->delete();
    $request->session()->flash('message','Conact Deleted !!');
    return redirect('admin/contactlist');

}

// --------------------------------------------------------

// --------------------------Resume-list---------------

public function resumelist()
{
    $result['data']=Career::all();
    return view('admin/resume-list',$result);
}

public function deleteresumelist(Request $request,$id)
{
    $arrImage=DB::table('careers')->where(['id'=>$id])->get();
    if(File::exists('uploads/resume/'.$arrImage[0]->photo) && File::exists('uploads/resume/'.$arrImage[0]->photo1) ){
        File::delete('uploads/resume/'.$arrImage[0]->photo);
        File::delete('uploads/resume/'.$arrImage[0]->photo1);
    }
    $model=Career::find($id);
    $model->delete();
    $request->session()->flash('message','Entry Deleted successfully!!');
    return redirect('admin/resumelist');

}

// --------------------------------------------------------


}
