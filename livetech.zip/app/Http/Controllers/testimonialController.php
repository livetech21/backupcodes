<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Testimonial;
use Illuminate\Support\Facades\DB;

use Storage;
use File;

class testimonialController extends Controller
{


    public function index()
    {
        $result['data']=Testimonial::all();
        return view('admin/testi-list',$result);
    }

    public function show()
    {
         return view('admin/testi-add');

    }

    public function insert(Request $request)
    {

        if($request->hasfile('image')){

            $request->validate([

                'image'=>'required|mimes:jpeg,jpg,png',
                'name'=>'required',
                'description1'=>'required'

            ]);

            $image=$request->file('image');
            $ext=$image->extension();
            $file=time().'.'.$ext;
            $image->move('uploads/testimonials/',$file);

            $data=array(
                'name'=>$request->input('name'),
                'photo'=>$file,
                'des'=>$request->input('description1')
            );

            DB::table('testimonials')->insert($data);

            $request->session()->flash('message','testimonials Added Successfully!!');
           return redirect('admin/testi');

        }else{
            $request->session()->flash('message','Please Add Correct Image!!');
            return redirect('admin/testi/add-testi');
        }


    }

    public function edit($id)
    {
       $data= DB::table('testimonials')->where('id',$id)->get();
        return view('admin/testi-edit',['data'=>$data]);

    }

    public function update(Request $request,$id)
    {
          $request->validate([

            'image'=>'mimes:jpeg,jpg,png'

        ]);

         $data=array(

            'name'=>$request->input('name'),
            'des'=>$request->input('description1')

        );


        if($request->hasfile('image')){
          $arrImage=DB::table('testimonials')->get();
            File::delete('uploads/testimonials/'.$arrImage[0]->photo);

        $image=$request->file('image');
        $ext=$image->extension();
        $file=time().'.'.$ext;
        $image->move('uploads/testimonials/',$file);
        $data['photo']=$file;

        DB::table('testimonials')->where('id',$id)->update($data);

    }
    else{

        $data=array(
            'name'=>$request->input('name'),
            'des'=>$request->input('description1')
        );

        DB::table('testimonials')->where('id',$id)->update($data);

}

         $request->session()->flash('message','testimonials Updated Successfully!!');
        return redirect('admin/testi');
    }


    public function delete(Request $request,$id){
        $arrImage=DB::table('testimonials')->where(['id'=>$id])->get();
        if(File::exists('uploads/testimonials/'.$arrImage[0]->photo)){
            File::delete('uploads/testimonials/'.$arrImage[0]->photo);
        }
        $model=Testimonial::find($id);
        $model->delete();
        $request->session()->flash('message','testimonials Deleted successfully!!');
        return redirect('admin/testi');
    }

}
