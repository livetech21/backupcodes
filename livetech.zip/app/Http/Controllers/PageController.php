<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Page;
use Illuminate\Support\Facades\DB;

use Storage;
use File;

class PageController extends Controller
{

    public function index()
    {
        $result['data']=Page::all();
        return view('admin/page-list',$result);
    }

    public function show()
    {
         return view('admin/page-add');

    }

    public function insert(Request $request)
    {

        if($request->hasfile('image')){

            $request->validate([

                'image'=>'required|mimes:jpeg,jpg,png',
                'image1'=>'required|mimes:jpeg,jpg,png',
                'name'=>'required',
                'title'=>'required',
                'slug'=>'required',
                'type'=>'required',
                'description1'=>'required'

            ]);

            $image=$request->file('image');
            $ext=$image->extension();
            $file=time().'.'.$ext;
            $image->move('uploads/pages/',$file);

            $image1=$request->file('image1');
            $ext1=$image1->extension();
            $file1=time().'-service.'.$ext1;
            $image1->move('uploads/pages/bannerimg/',$file1);

            $data=array(
                'name'=>$request->input('name'),
                'title'=>$request->input('title'),
                'slug'=>$request->input('slug'),
                'type'=>$request->input('type'),
                'photo'=>$file,
                'photo1'=>$file1,
                'des'=>$request->input('description1')
            );

            DB::table('pages')->insert($data);

            $request->session()->flash('message','Page Added Successfully!!');
           return redirect('admin/pages');

        }else{
            $request->session()->flash('message','Please Add Correct Image!!');
            return redirect('admin/pages/add-pages');
        }


    }

    public function edit($id)
    {
       $data= DB::table('pages')->where('id',$id)->get();
        return view('admin/page-edit',['data'=>$data]);

    }

    public function update(Request $request,$id)
    {
          $request->validate([

            'image'=>'mimes:jpeg,jpg,png'

        ]);

         $data=array(

            'name'=>$request->input('name'),
            'title'=>$request->input('title'),
            'slug'=>$request->input('slug'),
            'type'=>$request->input('type'),
            'photo'=>$request->input('image'),
            'des'=>$request->input('description1')

        );


        if($request->hasfile('image')){
          $arrImage=DB::table('pages')->get();
            File::delete('uploads/pages/'.$arrImage[0]->photo);

        $image=$request->file('image');
        $ext=$image->extension();
        $file=time().'.'.$ext;
        $image->move('uploads/pages/',$file);
        $data['photo']=$file;

        DB::table('pages')->where('id',$id)->update($data);

    }
    else{

        $data=array(
            'name'=>$request->input('name'),
            'title'=>$request->input('title'),
            'slug'=>$request->input('slug'),
            'type'=>$request->input('type'),
            'des'=>$request->input('description1')
        );

        DB::table('pages')->where('id',$id)->update($data);

}

         $request->session()->flash('message','Page Updated Successfully!!');
        return redirect('admin/pages');
    }


    public function delete(Request $request,$id){
        $arrImage=DB::table('pages')->where(['id'=>$id])->get();
        if(File::exists('uploads/pages/'.$arrImage[0]->photo) && File::exists('uploads/pages/bannerimg/'.$arrImage[0]->photo1) ){
            File::delete('uploads/pages/'.$arrImage[0]->photo);
            File::delete('uploads/pages/bannerimg/'.$arrImage[0]->photo1);
        }
        $model=Page::find($id);
        $model->delete();
        $request->session()->flash('message','Page Deleted successfully!!');
        return redirect('admin/pages');
    }

    public function editbanner($id)
    {
       $data= DB::table('pages')->where('id',$id)->get();
        return view('admin/page-edit-banner',['data'=>$data]);

    }

    public function updatebanner(Request $request,$id)
    {
          $request->validate([

            'image1'=>'mimes:jpeg,jpg,png',


        ]);

         $data=array(
            'photo1'=>$request->input('image1')

        );


        if($request->hasfile('image1') ){
            $arrImage=DB::table('pages')->where(['id'=>$id])->get();
            if(File::exists('uploads/pages/bannerimg/'.$arrImage[0]->photo1) ){
                File::delete('uploads/pages/bannerimg/'.$arrImage[0]->photo1);
            }

        $image=$request->file('image1');
        $ext=$image->extension();
        $file=time().'-services.'.$ext;
        $image->move('uploads/pages/bannerimg/',$file);
        $data['photo1']=$file;

        DB::table('pages')->where('id',$id)->update($data);

    }
    else{

        $request->session()->flash('message','Image should be correct!!');
        return redirect('admin/pages/editbanner');

}

         $request->session()->flash('message','Banner Image Updated Successfully!!');
        return redirect('admin/pages');
    }


}
