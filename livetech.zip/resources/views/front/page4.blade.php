@extends('front/layout')
@section('page_title','Livetech-CRM-services')

@section('container')

<style>
  .card {
      box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;
  }

  .card:hover {
    box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
      transition: 0.3s;
      border-left:2px solid #2fc5b9;
      border-right:2px solid #2b6db4;
      padding:15px;
      border-radius:10px;
  }

  .kk{
    border:2px solid #075196;
  }
    .kk:hover{
    border:3px solid #067751;
  }
  .txt:hover {
    border-bottom: 2px solid #067751;
}
</style>

<img class="img-fluid" src="{{ asset('img/services.png') }}" alt="livetch"/>

<div style="background-image: linear-gradient(to right, #ebebe0, #2fc5b9);" >
<div class="container marketing" >
<br>
  <p style="font-size: 30px;color:#075196;text-align: center;"><b>Our Excellent CRM Services</b></p>
  <hr style="background-color:#28AE7B;width:20%;height:2px;text-align: center;margin-top: -10px;">

<br>
  <!-- Three columns of text below the carousel -->
  <div class="row" >

  @foreach($page as $list)
    <div class="col-lg-3">
<div class="card" style="max-height:300px;">
      <img class="rounded-circle" style="display: block;margin-left: auto;margin-right: auto;height:100px;width:100px;" src="{{asset('uploads/pages/'.$list->photo) }}" alt="Generic placeholder image">
      <h5 style="color:#075196;text-align:center;">{{$list->title}}</h5>
      <p align="justify">{{substr($list->des,0,50)}} ...</p>
      <p><a class="btn btn-outline-primary" href="{{ url('pagedetails4/'.$list->slug)}}" role="button">View details &raquo;</a></p>
</div>
    </div><!-- /.col-lg-4 -->
@endforeach


  </div><!-- /.row -->


</div>
</div>

<style>

  .counter{
    color: #f27f21;
    font-family: 'Open Sans', sans-serif;
    text-align: center;
    height: 190px;
    width: 190px;
    padding: 30px 25px 25px;
    margin: 0 auto;
    border: 3px solid #f27f21;
    border-radius: 20px 20px;
    position: relative;
    z-index: 1;
}
.counter:before,
.counter:after{
    content: "";
    background: #f3f3f3;
    border-radius: 20px;
    box-shadow: 4px 4px 2px rgba(0,0,0,0.2);
    position: absolute;
    left: 15px;
    top: 15px;
    bottom: 15px;
    right: 15px;
    z-index: -1;
}
.counter:after{
    background: transparent;
    width: 100px;
    height: 100px;
    border: 15px solid #f27f21;
    border-top: none;
    border-right: none;
    border-radius: 0 0 0 20px;
    box-shadow: none;
    top: auto;
    left: -10px;
    bottom: -10px;
    right: auto;
}
.counter .counter-icon{
    font-size: 35px;
    line-height: 35px;
    margin: 0 0 15px;
    transition: all 0.3s ease 0s;
}
.counter:hover .counter-icon{ transform: rotateY(360deg); }
.counter .counter-value{
    color: #555;
    font-size: 30px;
    font-weight: 600;
    line-height: 20px;
    margin: 0 0 20px;
    display: block;
    transition: all 0.3s ease 0s;
}
.counter:hover .counter-value{ text-shadow: 2px 2px 0 #d1d8e0; }
.counter h3{
    font-size: 17px;
    font-weight: 700;
    text-transform: uppercase;
    margin: 0 0 15px;
}
.counter.blue{
    color: #075196;
    border-color: #075196;
}
.counter.blue:after{
  border-bottom-color: #075196;
  border-left-color: #075196;
}
.counter.red{
  color: #df4010;
  border-color: #df0808;
}
.counter.red:after{
  border-bottom-color: #d60101;
  border-left-color: #d60101;
}
.counter.green{
  color: #28c700;
  border-color: #28c700;
}
.counter.green:after{
  border-bottom-color: #28c700;
  border-left-color: #28c700;
}

@media screen and (max-width:990px){
    .counter{ margin-bottom: 40px; }
}

</style>

<div >
<p style="font-size: 30px;color:#075196;text-align: center;"><b>We Also Work On</b></p>
<hr style="background-color:#28AE7B;width:20%;height:2px;text-align: center;margin-top: -10px;">

<div class="container">
    <div class="row">
        <div class="col-md-3 col-sm-6">
            <div class="counter blue">
                <div class="counter-icon">
                    <i class="fa fa-globe"></i>
                </div>
                <span class="counter-value">761</span>
                <h3>Web Designing</h3>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="counter blue">
                <div class="counter-icon">
                    <i class="fa fa-rocket"></i>
                </div>
                <span class="counter-value">719</span>
                <h3>Web Development</h3>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="counter blue">
              <div class="counter-icon">
                  <i class="fa fa-rocket"></i>
              </div>
              <span class="counter-value">719</span>
              <h3>Web Development</h3>
          </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="counter blue">
            <div class="counter-icon">
                <i class="fa fa-rocket"></i>
            </div>
            <span class="counter-value">719</span>
            <h3>Web Development</h3>
        </div>
    </div>
    </div>
</div>
</div>


<br>





@endsection
