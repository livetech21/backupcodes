<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
    <meta http-equiv="Expires" content="0" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/homecss.css') }}">
    <link rel="stylesheet" href="{{ asset('css/blogcss.css') }}">

    <script src="{{ asset('js/headercss.js ') }}"></script>
    <script src="{{ asset('js/slide.js ') }}"></script>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">


    <title>@yield('page_title')</title>

</head>

<body>
<header>

<style>
    .back-to-top {
        display: none;
        width: 30px;
        height: 30px;
        bottom: 20px;
        right: 20px;
        z-index: 500;
    }
</style>
<style>
    .sticky {
      position: fixed;
    top: 0;
    width: 100%;
    margin-left: -240px;
    z-index: 999;
    background-color: white;

}




    .sticky+.content {
        padding-top: 60px;
    }

    #float {
        position: relative;
        -webkit-animation: floatBubble 0.5s infinite normal ease-out;
        animation: floatBubble 0.5s normal ease-out;
    }

    @-webkit-keyframes floatBubble {
        0% {
            top: 5px;
        }
        100% {
            top: 0px;
        }
    }

    @keyframes floatBubble {
        0% {
            top: 5px;
        }
        100% {
            top: 0px;
        }
    }
</style>
<style>
    .dropdown {
        position: relative;
        display: inline-block;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        min-width: 220px;
        box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
        color: #000;
        padding: 15px;
        font-weight: 400;

        font-size: 14px;
        text-align: justify;
        z-index: 1;
        background-color: #f6f6f6;
        line-height: 25px;
    }

    .dropdown:hover .dropdown-content {
        display: block;
    }
</style>
<style>
    .arrow {
        border: solid black;
        border-width: 0 3px 3px 0;
        display: inline-block;
        padding: 3px;
    }

    .right {
        transform: rotate(-45deg);
        -webkit-transform: rotate(-45deg);
    }

    .left {
        transform: rotate(135deg);
        -webkit-transform: rotate(135deg);
    }

    .up {
        transform: rotate(-135deg);
        -webkit-transform: rotate(-135deg);
    }

    .down {
        transform: rotate(45deg);
        -webkit-transform: rotate(45deg);
    }
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<div class='container-fluid'>


    <div class="row" style="background-color:#075196;padding:5px;">

      <div class="col-6">

        <div class="dropdown" >
          <span class="icon" style="font-size: 15px;font-weight: 200;padding:5px;color:white;"><b> Company &nbsp;&nbsp; <i class="fa fa-shopping-bag"></i></b></span>
          <div style="position: absolute;">

              <div class="dropdown-content" id="float" style="border-bottom:5px solid #28AE7B;">
                  <a href="#/vision"><p class="ah" style="margin-top:2px;margin-bottom:2px;">Vission & Mision</p></a>
                  <a href="#/career"><p class="ah" style="margin-top:2px;margin-bottom:2px;">Career</p></a>
                  <a href="#/lifelts"><p class="ah" style="margin-top:2px;margin-bottom:2px;">Life at Livetech</p></a>
                  <a href="#/gallery"><p class="ah" style="margin-top:2px;margin-bottom:2px;">Portfolio </p></a>
                  <a href="#/contact"><p class="ah" style="margin-top:2px;margin-bottom:2px;">Contact</p></a>
              <p style="margin-top:2px;margin-bottom:2px;color:#075196;"><i class="fa fa-envelope"></i>&nbsp;&nbsp;info@livetech.com</p>
<p style="margin-top:2px;margin-bottom:2px;color:#075196;"><i class="fa fa-phone"></i>&nbsp;&nbsp;+91-8010704950</p>
                </div>
          </div>

      </div>
        </div>
        <div class="col-6">
        <i class='fa fa-facebook icon' style='color:white;float:right;padding:5px;'></i> &nbsp;
        <i class='fa fa-twitter icon' style='color:white;float:right;padding:5px;'></i> &nbsp;
        <i class='fa fa-linkedin icon' style='color:white;float:right;padding:5px;'></i> &nbsp;
        <i class='fa fa-youtube icon' style='color:white;float:right;padding:5px;'></i>&nbsp;

      </div>

    </div>


    <div class="row">
        <div class="col-lg-12">
            <div class="row">

                <div class='col-lg-12 col-xs-12'>



                    <nav class="navbar navbar-expand-lg navbar-light " id="navbar">
                      <a href='/'>
                        <img src="{{asset('images/livetech.png')}}" style='width:150px;height:85px;margin-top:20px;margin-right:50px;'>
                    </a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                      <span class="navbar-toggler-icon"></span>
                    </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <a href='/'> <img src="images/livetech.png" style='width:150px;height:85px;margin-top:10px;' href="javascript: void(0)" class="back-to-top">
                            </a>

                            <ul class="navbar-nav">
                                <li class="nav-item active" >
                                    <div class="dropdown"  style='margin-top:15px; background-color:white'>
                                        <img src="{{asset('images/website designing.png') }}" style='height: 50px;width:50px;margin-left:25px;'>&nbsp; Website Designing
                                        <div style="position: absolute;">

                                            <div class="dropdown-content" id="float" style="border-bottom:5px solid #075196;">
                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('pagedetails/Web-Design-Services')}}" style='color:#075196'>Web Design Services</a></p>
                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('pagedetails/Mobile-Website-Designing')}}" style='color:#075196'>Mobile Website Designing</a></p>
                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('pagedetails/Graphic')}}" style='color:#075196'>Ecommerce web-Designing</a></p>

                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('pagedetails/Graphic')}}" style='color:#075196'>Ecommerce web-Development</a></p>

                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('pagedetails/Graphic')}}" style='color:#075196'>Website Re-Designing</a></p>
                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('pagedetails/Graphic')}}" style='color:#075196'>PWA Development</a></p>
                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Content Management System</a></p>
                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>PSD To XHTML</a></p>

                                            </div>


                                        </div>


                                    </div>
                                </li>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <li class="nav-item active">
                                    <div class="dropdown" style='margin-top:15px; background-color:white'>
                                        <span style=""><img src="{{asset('images/digital-marketing.png') }}" style='height: 45px;width:60px;margin-left:25px;'>&nbsp; Digital Marketing</span>
                                        <div style="position: absolute;">

                                            <div class="dropdown-content" id="float" style="border-bottom:5px solid #075196;">
                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('pagedetails/SEO')}}" style='color:#075196'>SEO</a></p>
                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"> <a href="{{ url('pagedetails/Enterprise SEO')}}" style='color:#075196'>Enterprise SEO</a></p>
                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Local SEO</a></p>
                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Ecommerce SEO</a></p>
                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Video SEO</a></p>
                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Google Recovery Services</a></p>
                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>SEO Reseller Services</a></p>
                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Multi Lingual SEO</a></p>
                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Web Analytics</a></p>
                                            </div>


                                        </div>

                                    </div>
                                </li>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <li class="nav-item active">
                                    <div class="dropdown" style='margin-top:15px; background-color:white'>
                                        <span style=""><img src="{{asset('images/erp-icon.png') }}" style='height: 50px;width:60px;margin-left:25px;'>&nbsp;ERP</span>
                                        <div style="position: absolute;" class="wx">

                                            <div class="dropdown-content" id="float" style="border-bottom:5px solid #075196;">
                                                <div class='row'>
                                                    <div class='col-lg-12'>

                                                        <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('pagedetails/ERP')}}" style='color:#075196;'>&nbsp;ERP</a></p>

                                                        <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('pagedetails/Retail ERP')}}" style='color:#075196'>Retail ERP</a></p>
                                                        <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Manufacturing ERP</a></p>

                                                        <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>ERP Web-Development</a></p>
                                                        <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>ERP Web-SEO</a></p>
                                                        <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>ERP For Financial Services</a></p>
                                                        <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Automotive ERP</a></p>
                                                        <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>ERP Web-Designing</a></p>
                                                        <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Furniture ERP</a></p>
                                                        <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Construction ERP</a></p>
                                                        <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>ERP For Service Industry</a></p>

                                                        <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Real Estate ERP</a></p>
                                                        <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Media & Advertising</a></p>
                                                        <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Banking ERP</a></p>
                                                        <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Healthcare ERP</a></p>
                                                        <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Hospitality ERP</a></p>
                                                      </div>

                                                    <div class='col-lg-12'>

                                                    </div>

                                                </div>


                                            </div>


                                        </div>

                                    </div>
                                </li>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <li class="nav-item active">
                                    <div class="dropdown" style='margin-top:15px; background-color:white'>
                                        <span style=""><img src="{{asset('images/crm icon 2.png') }}" style='height: 45px;width:70px;margin-top: 4px;margin-left:25px;'>&nbsp; CRM</span>
                                        <div style="position: absolute;" class="wx">

                                            <div class="dropdown-content" id="float" style="border-bottom:5px solid #075196;">
                                                <div class='container'>
                                                    <div class='row'>
                                                        <div class='col-lg-12 col-xs-12'>

                                                            <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('pagedetails/Manfacturing CRM')}}" style='color:#075196;'>Manufaturing CRM</a></p>
                                                            <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('pagedetails/CRM For Financial Services')}}" style='color:#075196;'>CRM-Financial</a></p>
                                                            <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196;'>Wealth CRM</a></p>
                                                            <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196;'>Retail CRM</a></p>
                                                            <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Real Estate CRM</a> </p>
                                                            <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>Construction CRM</a></p>
                                                            <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196;'>Banking CRM</a></p>
                                                            <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196;'>Healthcare CRM</a></p>
                                                            <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196;'>Hospitality CRM</a></p>
                                                            <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196;'>E-commerce CRM</a></p>
                                                            <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>CRM</a></p>

                                                            <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>CRM Service Industry</a></p>

                                                        </div>
                                                        <div class='col-lg-6 col-xs-12'>

                                                        </div>

                                                    </div>
                                                </div>


                                            </div>


                                        </div>

                                    </div>
                                </li>
                               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <li class="nav-item active">
                                    <div class="dropdown" style='margin-top:15px; background-color:white'>
                                        <span style=""><img src="{{asset('images/ecommerce-solution.png') }}" style='height: 50px;width:50px;margin-left:25px;'>&nbsp; Ecommerce-Solutions</span>
                                        <div style="position: absolute;">

                                            <div class="dropdown-content" id="float" style="border-bottom:5px solid #075196;">


                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('pagedetails/Graphic')}}" style='color:#075196'>E-Commerce Web-Designing</a></p>
                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>E-Commerce Web-Designing</a></p>

                                                <p class="ah" style="margin-top:2px;margin-bottom:2px;"><a href="{{ url('page/Graphic')}}" style='color:#075196'>E-Commerce Development</a></p>

                                            </div>


                                        </div>

                                    </div>
                                </li>
                            </ul>
                        </div>
                    </nav>

<div class="row" style="color: #28AE7B; margin-top: 0; margin-bottom: 0; border-bottom: 7px solid #28AE7B;">
</div>
                    <!-- <div class="row" style="padding:5px;background-color:#075196;">
                    <div class="col" >
                    <div class="dropdown" >
                        <span class="kk" style="font-size: 15px;font-weight: 200;padding:5px;"><b>Company &#9660;</b></span>
                        <div style="position: absolute;">

                            <div class="dropdown-content" id="float">
                                <p>Vission & Mision</p>
                                <p>Team</p>
                                <p>Career</p>
                                <p>Life at Livetech</p>
                            </div>


                        </div>

                    </div>
                </div>

                <div class="col" >
                  <div class="dropdown" >
                    <a href="#/gallery"><span class="kk" style="font-size: 15px;font-weight: 200;padding:5px;"><b>Portfolio </b></span></a>

                  </div>
                 </div>

                   <div class="col" >
                   <div class="dropdown" >
                        <a href="#/contact"><span class="kk" style="font-size: 15px;font-weight: 200;padding:5px;"><b>Contact </b></span></a>


                    </div>
</div>
</div> -->

                </div>
            </div>
        </div>
    </div>

</header>


@section('container')
        @show



        <div style="background: linear-gradient(5deg, #075196 0%, #075196 25%, transparent 26%), linear-gradient(-5deg, #075196 0%, #075196 24%, transparent 25%);height:100px;width:100%;">

</div>
<footer>
<style>
  .hero-image {
    /* Use "linear-gradient" to add a darken background effect to the image (photographer.jpg). This will make the text easier to read */
    background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("photographer.jpg");

    /* Set a specific height */
    height: 100%;

    /* Position and center the image to scale nicely on all screens */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    position: relative;
  }
  .home-newsletter {
    padding: 30px 0;
    background: #075196;
    }

    .home-newsletter .single {
    max-width: auto;
    margin: 0 auto;
    text-align: center;
    position: relative;
    z-index: 2; }
    .home-newsletter .single h2 {
    font-size: 22px;
    color: white;
    text-transform: uppercase;
    margin-bottom: auto; }
    .home-newsletter .single .form-control {
    height: 50px;
    background: rgba(255, 255, 255, 0.6);
    border-color: transparent;
    border-radius: 20px 0 0 20px; }
    .home-newsletter .single .form-control:focus {
    box-shadow: none;
    border-color: #243c4f; }
    .home-newsletter .single .btn {
    min-height: 50px;
    border-radius: 0 20px 20px 0;
    background: #243c4f;
    color: #fff;
    }

</style>

<section class="home-newsletter" style="background-image: url('imgnew/sg.jpg');">
  <div class="container">
  <div class="row">


    <div class="col-lg-6 col-sm-6">


      <div class="single">
        <h2 style="margin-top:15px;">Subscribe to our Newsletter</h2>

      </div>

    </div>

    <div class="col-lg-6 col-sm-6">


    <div class="single">

    <div class="input-group">
           <input type="email" class="form-control" placeholder="Enter your email">
           <span class="input-group-btn">
           <button class="btn btn-theme" type="submit">Subscribe</button>
           </span>
            </div>
    </div>


  </div>
  </div>
  </div>
  </section>
<hr style="color:white;margin-top: 0;
margin-bottom: 0;">

<div class="container-fluid" id="footer" >
    <div class="row" style="background-color: #075196;">


      <div class="col-lg-3">
            <p style="margin-top:20px;color:white;font-size: 18px;text-align: center;"><b>Abut Company</b></p>
            <hr style="background-color: white;width:30%">
            <ul id="kkm" style="list-style: none;color:white">
               <p align="justify">LTS is IT Company and we are dealing with Web Development, mobile application, Big Data Solution, Digital Marketing, Web Portal Development, ERP developemnt, Software Development and IT Services.</p>
            </ul>
        </div>
        <div class="col-lg-3">
            <p style="margin-top:20px;color:white;font-size: 20px;text-align: center;"><b>Quick Links</b></p>
            <hr style="background-color: white;width:30%">
            <ul style="list-style: none;color:white;text-align: center;margin-left:-30px;">
              <a href="/"><li style="color:white;line-height: 1;">Home</li></a>
                <br>
                <a href="/about">
                    <li style="color:white;line-height: 1;">About Us</li>
                </a>
                <br>
                <a href="/gallery">
                    <li style="color:white">Portfolio</li>
                </a>
                <br>
                <a href="/services">
                  <li style="color:white">Services</li>
              </a>
              <br>
                <a href="/blog">
                  <li style="color:white">Blogs</li>
              </a>

              <br>
                <a href="/page">
                  <li style="color:white">Page</li>
              </a>
              <br>
                <a href="/pagedetails">
                  <li style="color:white">Pagedetails</li>
              </a>
              <br>
                <a href="/career">
                  <li style="color:white">Career</li>
              </a>
              <br>
                <a href="/contact-us">
                    <li style="color:white">Contact Us</li>
                </a>

            </ul>
        </div>
        <div class="col-lg-3">
          <p style="margin-top:20px;color:white;font-size: 18px;text-align: center;"><b>Services</b></p>
          <hr style="background-color: white;width:30%">
          <ul style="list-style: none;color:white;text-align: center;margin-left:-30px;">
            <a href="#/"><li style="color:white">Web Development</li></a>
              <br>
              <a href="#/about">
                  <li style="color:white;font-size:15px;">Digital Marketing</li>
              </a>
              <br>
              <a href="#/gallery">
                  <li style="color:white">Graphic and Video Editing</li>
              </a>
              <br>
              <a href="#/">
                  <li style="color:white">Custom CRM</li>
              </a>
              <br>
              <a href="#/">
                  <li style="color:white">Custom ERP</li>
              </a>
              <br>
              <a href="#/">
                  <li style="color:white">Mobile App</li>
              </a>

          </ul>
      </div>
        <div class="col-lg-3">
          <p style="margin-top:20px;color:white;font-size: 18px;text-align: center;"><b>CONTACT INFO</b></p>
          <hr style="background-color: white;width:30%">
          <ul id="kkm" style="list-style: none;color:white">
              <li><i class="fa fa-map-marker"></i>&nbsp; D-175, Sector 49, Noida, GB Nagar (U.P.)</li>
              <br>
              <li><i class="fa fa-phone"></i>&nbsp;+91-8010704950 </li>
              <br>
              <li><i class="fa fa-envelope"></i>&nbsp;livetechservices.in</li>


          </ul>

    </div>

<div class="col-lg-12">
  <div id="accordion">
    <div class="card" style="background-color:transparent;">
      <div class="card-header" id="headingTwoo">
        <h5 class="mb-0">
          <a class="collapsed" data-toggle="collapse" data-target="#collapseff" aria-expanded="false" aria-controls="collapseff" style="color:white;font-size:18px;">
            Quick Directory Links
          </a>
          <i class="fa fa-arrow-down btn btn-outline-primary collapsed" style="float:right;color:white;" data-toggle="collapse" data-target="#collapseff" aria-expanded="false" aria-controls="collapseff" aria-hidden="true"></i>
        </h5>
      </div>
      <div id="collapseff" style="padding:0.2px;" class="collapse" aria-labelledby="headingTwoo" data-parent="#accordion">
        <div class="card-body">

          <div class="row">

          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
            <ul class="list-unstyled mb-0">
              <li>
                <a routerLink="/6lr61-9v-alkaline-battery" class="text-white">IT</a>
              </li>
              <li>
                <a routerLink="/6lr61-9v-alkaline-battery" class="text-white">Software solutions</a>
              </li>

            </ul>
          </div>
          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">

            <ul class="list-unstyled mb-0">
              <li>
                <a routerLink="/c-lr14-1.5v-alkaline-battery" class="text-white">CRM</a>
              </li>
              <li>
                <a routerLink="/c-lr14-1.5v-alkaline-battery" class="text-white">Digital Marketing</a>
              </li>

            </ul>
          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">

            <ul class="list-unstyled mb-0">
              <li>
                <a routerLink="/lr6-aa-Ultra-Digital-Battery" class="text-white">SMO</a>
              </li>
              <li>
                <a routerLink="/lr6-aa-Ultra-Digital-Battery" class="text-white">ERP</a>
              </li>


            </ul>


          </div>

          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">

            <ul class="list-unstyled mb-0">
              <li>
                <a routerLink="/ultra-digital-batteries" class="text-white">Testing Solutions</a>
              </li>
              <li>
                <a routerLink="/alkaline-batteries" class="text-white">Technology</a>
              </li>



            </ul>


          </div>

</div>

        </div>
      </div>
    </div>
    </div>

</div>

    <div class="col-lg-12">

      <hr style="background-color: white;">
      <p style="color:white;text-align:center">© Copyrights All Rights Reserved. Designed and Developed by <a href="livetechservices.in">LTS</a></p>

  </div>

</div>


</footer>

</body>

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

</html>
