@extends('front/layout')
@section('page_title','Livetech-Video-Editing')

@section('container')

<style>
@media all and (min-width: 480px) {
    .deskContent {display:block;}
    .phoneContent {display:none;}
  }

  @media all and (max-width: 479px) {
    .deskContent {display:none;}
    .phoneContent {display:block;}
  }
  </style>



<style>
    .card {
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
        transition: 0.3s;
    }

    .card:hover {
      box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
      transition: 0.3s;
      border-left:2px solid #2fc5b9;
      border-right:2px solid #2b6db4;
      border-radius:10px;
  }

    .card-counter{
      box-shadow: 2px 2px 10px #DADADA;
      margin: 5px;
      padding: 20px 10px;
      background-color: #fff;
      height: 100px;
      border-radius: 5px;
      transition: .3s linear all;
    }

    .card-counter:hover{
      box-shadow: 4px 4px 20px #DADADA;
      transition: .3s linear all;
    }

    .card-counter.primary{
      background-color: #007bff;
      color: #FFF;
    }

    .card-counter.danger{
      background-color: #ef5350;
      color: #FFF;
    }

    .card-counter.success{
      background-color: #66bb6a;
      color: #FFF;
    }

    .card-counter.info{
      background-color: #26c6da;
      color: #FFF;
    }

    .card-counter i{
      font-size: 5em;
      opacity: 0.2;
    }

    .card-counter .count-numbers{
      position: absolute;
      right: 35px;
      top: 20px;
      font-size: 32px;
      display: block;
    }

    .card-counter .count-name{
      position: absolute;
      right: 35px;
      top: 65px;
      font-style: italic;
      text-transform: capitalize;
      opacity: 0.5;
      display: block;
      font-size: 18px;
    }

</style>
<div class="deskContent">
<img class="img-fluid carasual-hh" src="{{asset('img/videoediting.png') }}" alt="Immense" style="border-bottom:2px solid #e0e0e0;" />
</div>

<div class="phoneContent">
<img class="img-fluid carasual-hh" src="{{asset('img/videoediting.png') }}" alt="Immense" style="border-bottom:2px solid #e0e0e0;" />
</div>

<div >
<div class='container'>

        <div class='col-lg-12' style="background-image: url( '{{ asset('img/bgg8.png') }}' );">
            <br> <br>
            <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b>Video Editing</b></p>
            <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">


        </div>
        <div class='row'>
            <div class='col-lg-6 col-xs-12'>
                <br><br>
                <div class="card" style='width:auto'>
                  <div class="card-body">
                    <img src="{{asset('img/videoimg.png') }}" class="img-fluid img-flip" alt="livetech"/></div>

                </div>
                </div>
            <div class='col-lg-6 col-xs-12' style="margin-top:-60px;">
                <br><br><br><br>

                <div class='card' style='border: 2px solid  #2b6db4 ;'>
                    <div class='card-body'>
                        <p style='color: #2b6db4;;font-family: "open sans", sans-serif;font-size: 15px;'><b>Videos From Livetech</b></p>
                        <!-- <ul style='color:#2fc5b9;;font-family: "open sans", sans-serif;font-size: 15px;line-height: 35px;margin-left: -35px;list-style:
                            none;'>

                         <b>   <li> <i style="font-size:24px" class="fa">&#xf105;</i> &nbsp; Evolution of digital marketing & why it is the buzzword</li>
                            <li> <i style="font-size:24px" class="fa">&#xf105;</i> &nbsp; Evolution of digital marketing & why it is the buzzword</li>
                            <li> <i style="font-size:24px" class="fa">&#xf105;</i> &nbsp; Evolution of digital marketing & why it is the buzzword</li>
                            <li> <i style="font-size:24px" class="fa">&#xf105;</i> &nbsp; Evolution of digital marketing & why it is the buzzword</li>
                        </b>

                        </ul> -->


                    </div>
                </div>


            </div>
        </div>

</div>


<style>
  .hori-timeline .events {
    border-top: 3px solid #e9ecef;
}
.hori-timeline .events .event-list {
    display: block;
    position: relative;
    text-align: center;
    padding-top: 70px;
    margin-right: 0;
}
.hori-timeline .events .event-list:before {
    content: "";
    position: absolute;
    height: 36px;
    border-right: 2px dashed #dee2e6;
    top: 0;
}
.hori-timeline .events .event-list .event-date {
    position: absolute;
    top: 38px;
    left: 0;
    right: 0;
    width: 75px;
    margin: 0 auto;
    border-radius: 4px;
    padding: 2px 4px;
}
@media (min-width: 1140px) {
    .hori-timeline .events .event-list {
        display: inline-block;
        width: 24%;
        padding-top: 45px;
    }
    .hori-timeline .events .event-list .event-date {
        top: -12px;
    }
}
.bg-soft-primary {
    background-color: rgba(64,144,203,.3)!important;
}
.bg-soft-success {
    background-color: rgba(71,189,154,.3)!important;
}
.bg-soft-danger {
    background-color: rgba(231,76,94,.3)!important;
}
.bg-soft-warning {
    background-color: rgba(249,213,112,.3)!important;
}
.card {
    border: none;
    margin-bottom: 24px;
    -webkit-box-shadow: 0 0 13px 0 rgba(236,236,241,.44);
    box-shadow: 0 0 13px 0 rgba(236,236,241,.44);
}
</style>


<style>
  .contact-form{
    background: #fff;
    margin-top: 10%;
    margin-bottom: 5%;
    width: 70%;
}
.contact-form .form-control{
    border-radius:1rem;
}
.contact-image{
    text-align: center;
}
.contact-image img{
    border-radius: 6rem;
    width: 11%;
    margin-top: -3%;
    transform: rotate(29deg);
}
.contact-form form{
    padding: 5%;
}
.contact-form form .row{
    margin-bottom: -7%;
}
.contact-form h3{
    margin-bottom: 8%;
    margin-top: -10%;
    text-align: center;
    color: #0062cc;
}
.contact-form .btnContact {
    width: 100%;
    border: none;
    border-radius: 1rem;
    padding: 1.5%;
    background: #0062cc;
    font-weight: 600;
    color: #fff;
    cursor: pointer;
}
.btnContactSubmit
{
    width: 50%;
    border-radius: 1rem;
    padding: 1.5%;
    color: #fff;
    background-color: #0062cc;
    border: none;
    cursor: pointer;
}
</style>

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" style="color:#067751;">Quick call <i class="fa fa-bullhorn"></i></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="background-image: url('imgnew/bg6.jpg');">
        <div class="container contact-form">
          <div class="contact-image">
              <img src="https://image.ibb.co/kUagtU/rocket_contact.png" alt="rocket_contact"/>
          </div>
          <form method="post">
              <h3>Drop Us a Message</h3>
             <div class="row">
                  <div class="col-lg-12">
                      <div class="form-group">
                          <input type="text" name="txtName" class="form-control" placeholder="Your Name *" value="" />
                      </div>
                      <div class="form-group">
                          <input type="text" name="txtEmail" class="form-control" placeholder="Your Email *" value="" />
                      </div>
                      <div class="form-group">
                          <input type="text" name="txtPhone" class="form-control" placeholder="Your Phone Number *" value="" />
                      </div>

                  </div>
                  <div class="col-lg-12">
                      <div class="form-group">
                          <textarea name="txtMsg" class="form-control" placeholder="Your Message *" style="width: 100%; height: 150px;"></textarea>
                      </div>
                      <div class="form-group">
                        <input type="submit" name="btnSubmit" class="btnContact" value="Send Message" />
                    </div>
                  </div>

              </div>
          </form>
</div>
      </div>

    </div>
  </div>
</div>

<div style="background-image: url( '{{ asset('img/bgg8.png') }}' );">
  <div class="container">
  <div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="card" style="border: 1px solid #888888;box-shadow: 5px 10px #888888;">
                <div class="card-body" style="background-image: url( '{{ asset('img/bgg7.png') }}' );">
                    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b>Our Process</b></p>
                    <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">


                    <div class="hori-timeline" dir="ltr">
                        <ul class="list-inline events">
                            <li class="list-inline-item event-list">
                                <div class="px-4">
                                    <div class="event-date bg-soft-primary text-primary">Step 1</div>
                                    <h5 class="font-size-16" style="color:#2b6db4;">Logging</h5>
                                    <p class="text-muted">Usually handled by an assistant editor, logging is the process of sorting and organizing the unedited, raw footage (called "dailies”).</p>
                                    <div>
                                      <button type="button" class="btn btn-success" style="background-color:cadetblue;" data-toggle="modal" data-target="#exampleModalCenter">
                                        Contact <i class="fa fa-bullhorn"></i>
                                      </button>
                                    </div>
                                </div>
                            </li>
                            <li class="list-inline-item event-list">
                                <div class="px-4">
                                    <div class="event-date bg-soft-success text-success">Step 2</div>
                                    <h5 class="font-size-16" style="color:#2b6db4;">First assembly </h5>
                                    <p class="text-muted">The first assembly, or assembly cut, is the editor’s first cut of the entire movie.</p>
                                    <div>
                                      <button type="button" class="btn btn-success" style="background-color:cadetblue;" data-toggle="modal" data-target="#exampleModalCenter">
                                        Contact <i class="fa fa-bullhorn"></i>
                                      </button>
                                    </div>
                                </div>
                            </li>
                            <li class="list-inline-item event-list">
                                <div class="px-4">
                                <div class="event-date bg-soft-primary text-primary">Step 3</div>
                                    <h5 class="font-size-16" style="color:#2b6db4;">Rough cut</h5>
                                    <p class="text-muted">The rough cut may take many months and is usually the first time that the editor works with the film director. </p>
                                    <div>
                                      <button type="button" class="btn btn-success" style="background-color:cadetblue;" data-toggle="modal" data-target="#exampleModalCenter">
                                        Contact <i class="fa fa-bullhorn"></i>
                                      </button>
                                    </div>
                                </div>
                            </li>
                            <li class="list-inline-item event-list">
                                <div class="px-4">
                                <div class="event-date bg-soft-success text-success">Step 4</div>
                                    <h5 class="font-size-16" style="color:#2b6db4;">Final cut</h5>
                                    <p class="text-muted">The editor adds the finishing touches. This includes sound effects, music, visual effects, titles, and color grading.</p>
                                    <div>
                                      <button type="button" class="btn btn-success" style="background-color:cadetblue;" data-toggle="modal" data-target="#exampleModalCenter">
                                        Contact <i class="fa fa-bullhorn"></i>
                                      </button>
                                    </div>
                                </div>
                            </li>
</ul>

                    </div>
                </div>
            </div>
            <!-- end card -->
        </div>
    </div>
  </div>
  </div>
  </div>



<br>
<style>
  /* Rounded tabs */

@media (min-width: 576px) {
  .rounded-nav {
    border-radius: 50rem !important;
  }
}

@media (min-width: 576px) {
  .rounded-nav .nav-link {
    border-radius: 50rem !important;
  }
}

/* With arrow tabs */

.with-arrow .nav-link.active {
  position: relative;
}

.with-arrow .nav-link.active::after {
  content: '';
  border-left: 6px solid transparent;
  border-right: 6px solid transparent;
  border-top: 6px solid #2b90d9;
  position: absolute;
  bottom: -6px;
  left: 50%;
  transform: translateX(-50%);
  display: block;
}

/* lined tabs */

.lined .nav-link {
  border: none;
  border-bottom: 3px solid transparent;
}

.lined .nav-link:hover {
  border: none;
  border-bottom: 3px solid transparent;
}

.lined .nav-link.active {
  background: none;
  color: #555;
  border-color: #2fc5b9;
}

/*
*
* ==========================================
* FOR DEMO PURPOSE
* ==========================================
*
*/


.nav-pills .nav-link {
  color: #555;
}
.text-uppercase {
  letter-spacing: 0.1em;
}

.thumb {
  width: 100%;
  height: 300px;
  margin: 70px auto;
  perspective: 1000px;
}

.thumb a {
  display: block;
  width: 100%;
  height: 100%;
  background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)),
  url("{{asset('imgnew/test.jpg') }}");
  background-size: 0, cover;
  transform-style: preserve-3d;
  transition: all 0.5s;
}

.thumb:hover a {
  transform: rotateX(80deg);
  transform-origin: bottom;
}
.thumb a:after {
  content: '';
  position: absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 36px;
  background: inherit;
  background-size: cover, cover;
  background-position: bottom;
  transform: rotateX(90deg);
  transform-origin: bottom;
}
.thumb a span {
  color: white;
  text-transform: uppercase;
  position: absolute;
  top: 100%;
  left: 0;
  width: 100%;
  font: bold 12px/36px "Open Sans";
  text-align: center;
  transform: rotateX(-89.99deg);
  transform-origin: top;
  z-index: 1;
}
.thumb a:before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  box-shadow: 0 0 100px 50px rgba(0, 0, 0, 0.5);
  transition: all 0.5s;
  opacity: 0.15;
  transform: rotateX(95deg) translateZ(-80px) scale(0.75);
  transform-origin: bottom;
}

.thumb:hover a:before {
  opacity: 1;
  box-shadow: 0 0 25px 25px rgba(0, 0, 0, 0.5);
  transform: rotateX(0) translateZ(-60px) scale(0.85);
}


</style>


<div class="thumb">
  <a href="#">
      <span>Welcome to the Livetech</span>
  </a>
</div>



<div style="padding:20px;">
<div class="row">
<!--
  <div class="col-lg-7 col-md-7 col-xs-12">


  <p style="margin-top:20px;font-size: 30px;color:#2b6db4;text-align: center;"><b>Stages of Video Editing Process</b></p>
          <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">


<div class="card">

<div style="padding:15px;background-image: url('{{ asset('img/bgg4.png') }}');  background-repeat: no-repeat;
  background-size: auto;" >
<h4> <b style="color:#2b6db4;font-weight:600;"> 1. Choosing your software </b> </h4>

<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="{{ asset('img/icons/downarrow.png') }}" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>

<p align="justify">
The most common question you’ll come across in video editing is, “What program did you use to make this?”. While there are dozens of recommended video editing software applications out there, they all essentially produce the same results.
</p>
</div>
<hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

<div style="padding:15px;background-image: url('{{ asset('img/bgg4.png') }}');  background-repeat: no-repeat;
  background-size: auto;">
<h4> <b style="color:#2b6db4;font-weight:600;"> 2. Transferring footage and organising projects </b> </h4>
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="{{ asset('img/icons/downarrow.png') }}" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>
<p align="justify">
The first step in video editing is transferring all of your footage from your camera to your computer. If your footage is from a video camera or DSLR, then you’ll want to copy your footage off the SD card from your device. If your footage is from an iPhone, then you can connect the phone to a Windows computer via USB cable and access the read-only device. On Mac, I would recommend using “Image Capture”, a pre-installed application, to easily transfer your files from your iPhone.
</p>
</div>
<hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

<div style="padding:15px;background-image: url('{{ asset('img/bgg4.png') }}');  background-repeat: no-repeat;
  background-size: auto;">
<h4> <b style="color:#2b6db4;font-weight:600;"> 3. Finding and assembling the best takes </b> </h4>
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="{{ asset('img/icons/downarrow.png') }}" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>
<p align="justify">
Go through the clips and look for the best takes of each one. This may be the best reading of your script or the most visually impressive shot. To do this, double click each file in your project and scrub through the clip to assess the quality of each.

This step is important to assure the highest quality for your final product. Be super critical of things like delivery, pacing, and the facial expressions of your subject.
</p>
</div>
<hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

<div style="padding:15px;background-image: url('{{ asset('img/bgg4.png') }}');  background-repeat: no-repeat;
  background-size: auto;">
<h4><b style="color:#2b6db4;font-weight:600;"> 4. Trimming the head and tail </b></h4>
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="{{ asset('img/icons/downarrow.png') }}" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>
<p align="justify">
With the arrangement of your video now in place, you can start to make some finer adjustments to the pace and flow. In a nutshell, you’ll want to trim the beginning and end of each of the clips you arranged in the timeline. Don’t underestimate the importance of this step! Fine-tuning your edit will help to create a video that feels more like a human conversation and less like a robot monologue.
</p>
</div>
<hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

<div style="padding:15px;background-image: url('{{ asset('img/bgg4.png') }}');  background-repeat: no-repeat;
  background-size: auto;">
<h4> <b style="color:#2b6db4;font-weight:600;"> 5. Adding music and B-roll </b></h4>
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="{{ asset('img/icons/downarrow.png') }}" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>
<p align="justify">
Background music plays a really important role in your video. It’s a powerful way to drive the video forward and create emotion around your message.
</p>
</div>
<hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

<div style="padding:15px;background-image: url('{{ asset('img/bgg4.png') }}');  background-repeat: no-repeat;
  background-size: auto;">
<h4> <b style="color:#2b6db4;font-weight:600;"> 6. Exporting a proof </b></h4>
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="{{ asset('img/icons/downarrow.png') }}" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>
<p align="justify">
A worthwhile tip if you’re stuck in a creative rut is to take a break and come back later to your edit. Grab a drink or a snack, or just step away for a few minutes. Come back to the video with fresh eyes. This will help you notice things you may have missed when you were deep in the zone.
</p>
</div>
<hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

<div style="padding:15px;background-image: url('{{ asset('img/bgg4.png') }}');  background-repeat: no-repeat;
  background-size: auto;">
<h4> <b style="color:#2b6db4;font-weight:600;"> 7. Wrap-up and further resources  </b></h4>
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="{{ asset('img/icons/downarrow.png') }}" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>
<p align="justify">
As mentioned in my previous post, there has never been a better time to start learning how to edit video. Editing is often seen as the most intimidating part of the video production process, but it doesn’t have to be that way!
</p>
</div>


</div>


  </div> -->




  <div class="phoneContent">
  <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b>Latest Blogs</b></p>
          <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

<div id="carouselExampleControls1s1" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">

    <div class="row" style="padding:15px;">

        <div class="col-lg-12 col-md-12 col-xs-12">
        <div class="card" style='width:100%;margin-top:5px;'>
                                      <div class="card-body">
                                          <img src="{{asset('images/ultimage-guide-app-store.jpg') }}" style='width:100%;height:100px;'>

                                          <p style='font-size: 18px;margin-top: 20px;'>App Store Optimization<br><br> Aug 21, 2020</p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet.
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>


                                      </div>
                                  </div>
        </div>
    </div>

    </div>
    <div class="carousel-item">
    <div class="row" style="padding:15px;">

        <div class="col-lg-12 col-md-12 col-xs-12">
        <div class="card" style='width:100%'>
                                      <div class="card-body">
                                          <img src="{{asset('images/ultimage-guide-app-store.jpg') }}" style='width:100%;height:100px;'>

                                          <p style='font-size: 18px;margin-top: 20px;'>App Store Optimization <br><br> Aug 21, 2020</p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet.
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>


                                      </div>
                                  </div>
        </div>
    </div>
    </div>

  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls1s1" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls1s1" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>

      </div>

  <div class="col-lg-12 col-md-12 col-xs-12 deskContent">
  <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b>Latest Blogs</b></p>
          <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

  <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">

    <div class="row" style="padding:5px;">
        <div class="col-lg-6 col-md-6 col-xs-12">
        <div class="card" style='width:100%;margin-top:5px;'>
                                      <div class="card-body" >
                                         <p style='font-size: 18px;'>App Store Optimization (ASO) The Ultimate ASO Guide 2020 <br>
                                              <br> Aug 21, 2020
                                          </p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet. The best part, you ask? I'm going ...
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>

                                          <img src="{{asset('images/ultimage-guide-app-store.jpg') }}" style='width:100%;height:100px;margin-top:20px ;'>

                                      </div>
                                  </div>
        </div>
        <div class="col-lg-6 col-md-6 col-xs-12">
        <div class="card" style='width:100%;margin-top:5px;'>
                                      <div class="card-body">
                                          <img src="{{asset('images/seo-tools-20201.jpg') }}" style='width:100%;height:100px;'>

                                          <p style='font-size: 18px;margin-top: 20px;'>App Store Optimization (ASO) The Ultimate ASO Guide 2020 <br><br> Aug 21, 2020</p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet. The best part, you ask? I'm going ...
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>


                                      </div>
                                  </div>
        </div>
    </div>

    </div>
    <div class="carousel-item">

    <div class="row" style="padding:5px;">
        <div class="col-lg-6 col-md-6 col-xs-12">
        <div class="card" style='width:100%;margin-top:5px;'>
                                      <div class="card-body" >
                                         <p style='font-size: 18px;'>App Store Optimization (ASO) The Ultimate ASO Guide 2020 <br>
                                              <br> Aug 21, 2020
                                          </p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet. The best part, you ask? I'm going ...
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>

                                          <img src="{{asset('images/ultimage-guide-app-store.jpg') }}" style='width:100%;height:100px;margin-top:20px ;'>

                                      </div>
                                  </div>
        </div>
        <div class="col-lg-6 col-md-6 col-xs-12">
        <div class="card" style='width:100%;margin-top:5px;'>
                                      <div class="card-body">
                                          <img src="{{asset('images/seo-tools-20201.jpg') }}" style='width:100%;height:100px;'>

                                          <p style='font-size: 18px;margin-top: 20px;'>App Store Optimization (ASO) The Ultimate ASO Guide 2020 <br><br> Aug 21, 2020</p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet. The best part, you ask? I'm going ...
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>


                                      </div>
                                  </div>
        </div>
    </div>

    </div>
    <div class="carousel-item">

    <div class="row" style="padding:5px;">
        <div class="col-lg-6 col-md-6 col-xs-12">
        <div class="card" style='width:100%;margin-top:5px;'>
                                      <div class="card-body" >
                                         <p style='font-size: 18px;'>App Store Optimization (ASO) The Ultimate ASO Guide 2020 <br>
                                              <br> Aug 21, 2020
                                          </p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet. The best part, you ask? I'm going ...
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>

                                          <img src="{{asset('images/ultimage-guide-app-store.jpg') }}" style='width:100%;height:100px;margin-top:20px ;'>

                                      </div>
                                  </div>
        </div>
        <div class="col-lg-6 col-md-6 col-xs-12">
        <div class="card" style='width:100%;margin-top:5px;'>
                                      <div class="card-body">
                                          <img src="{{asset('images/seo-tools-20201.jpg') }}" style='width:100%;height:100px;'>

                                          <p style='font-size: 18px;margin-top: 20px;'>App Store Optimization (ASO) The Ultimate ASO Guide 2020 <br><br> Aug 21, 2020</p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet. The best part, you ask? I'm going ...
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>


                                      </div>
                                  </div>
        </div>
    </div>

    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<br/>


  </div>

</div>


</div>



<style>
  .parallax {
      /* The image used */
      background-image: url("{{asset('images/get in touch.jpg') }}");
      /* Set a specific height */
      min-height: 400px;
      /* Create the parallax scrolling effect */
      background-attachment: fixed;
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
  }
</style>


<div class="phoneContent">
<div class="parallax">
  <div style="background-color:#2b6db4;opacity:0.8;height: auto;padding:10px;">

      <br>
      <p style="font-size: 30px;color:white;text-align: center;"><b>What Clients say</b></p>
<br>
<div id="carouselExampleControlstts" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">

<div class="row">
    <!-- <div class="col-lg-6 col-md-6 col-xs-12">

    </div> -->
    <div class="col-lg-12 col-md-12 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="{{ asset('images/seo.jpg') }}" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
</div>

    </div>
    <div class="carousel-item">


<div class="row">
    <!-- <div class="col-lg-6 col-md-6 col-xs-12">
    </div> -->
    <div class="col-lg-12 col-md-12 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="{{ asset('images/seo.jpg') }}" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
</div>


    </div>

    <div class="carousel-item">


    <div class="row">
    <!-- <div class="col-lg-6 col-md-6 col-xs-12">

    </div> -->
    <div class="col-lg-12 col-md-12 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="{{ asset('images/seo.jpg') }}" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
</div>


    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControlstts" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControlstts" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


      <div>
          <div>

          </div>
      </div>
  </div>

</div>
</div>

<div class="deskContent">
<div class="parallax">
  <div style="background-color:#2b6db4;opacity:0.8;height: auto;padding:10px;">

      <br>
      <p style="font-size: 30px;color:white;text-align: center;"><b>What Clients say</b></p>
<br>
<div id="carouselExampleControlstt" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">

<div class="row">
    <div class="col-lg-6 col-md-6 col-xs-12">
    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="{{ asset('images/seo.jpg') }}" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
    <div class="col-lg-6 col-md-6 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="{{ asset('images/seo.jpg') }}" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
</div>

    </div>
    <div class="carousel-item">


<div class="row">
    <div class="col-lg-6 col-md-6 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="{{ asset('images/seo.jpg') }}" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
    <div class="col-lg-6 col-md-6 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="{{ asset('images/seo.jpg') }}" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
</div>


    </div>

    <div class="carousel-item">


    <div class="row">
    <div class="col-lg-6 col-md-6 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="{{ asset('images/seo.jpg') }}" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
    <div class="col-lg-6 col-md-6 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="{{ asset('images/seo.jpg') }}" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
</div>


    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControlstt" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControlstt" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


      <div>
          <div>

          </div>
      </div>
  </div>

</div>
</div>



<div style="width:100%;height:100px;background: linear-gradient(
-2deg, #2fc5b9 0%, #2fc5b9 36%, white 37%);"></div>
<div class='container-fluid' style='background-color: #2fc5b9;'>
  <div class='container' >
      <div class='row' >
          <div class='col-lg-12'>
            <br>
            <p style="font-size: 30px;color:white;text-align: center;"><b>Faq's</b></p>

          </div>
          <div>

          </div>
      </div>

      <div class='row' >
          <div class='col-lg-12'>


              <section>
                  <p style='color:white'><i class="fa fa-ravelry" aria-hidden="true"></i> Agile Methodology</p> <button type="button" class="pull-right btn btn-outline-primary" style="margin-top: -40px;color:white;border-color:white;" data-toggle="collapse" data-target="#demo"><i class="fa fa-plus" ></i></button>
                  <section id="demo" class="collapse">

                      <p style="margin-top: 10px;color:white">We provide Agile methodology,it seeks alternatives to traditional project management & help teams respond to unpredictability through incremental, iterative work cadences and empirical feedbacks.</p>

                  </section>
                  <hr style="background-color: white;">
              </section>
              <br>



              <section>
                  <p style='color:white'><i class="fa fa-life-ring" aria-hidden="true"></i> End To End Solution</p> <button type="button" class="pull-right btn btn-outline-primary" style="margin-top: -40px;color:white;border-color:white;" data-toggle="collapse" data-target="#demo1"><i class="fa fa-plus" ></i></button>
                  <section id="demo1" class="collapse">

                      <p style="margin-top: 10px;color:#fff">We provide end to end solution to our customers, it means that the supplier of an application program or system will provide all the hardware and/or software components and resources to meet the customer's requirement.</p>

                  </section>
                  <hr style="background-color: white;">
              </section>
              <br>


              <section>
                  <p style='color:white'><i class="fa fa-laptop" aria-hidden="true"></i> Quality Code</p> <button type="button" class="pull-right btn btn-outline-primary" style="margin-top: -40px;color:white;border-color:white;" data-toggle="collapse" data-target="#demo2"><i class="fa fa-plus" ></i></button>
                  <section id="demo2" class="collapse">

                      <p style="margin-top: 10px;color:#fff">We provide bug-free code to our clients. Our quality products consist of the features highly adhering to the needs of customers.</p>

                  </section>
                  <hr style="background-color: white;">
              </section>
              <br>


              <section>
                  <p style='color:white'><i class="fa fa-language" aria-hidden="true"></i> Onsite Support</p> <button type="button" class="pull-right btn btn-outline-primary" style="margin-top: -40px;color:white;border-color:white;" data-toggle="collapse" data-target="#demo3"><i class="fa fa-plus" ></i></button>
                  <section id="demo3" class="collapse">

                      <p style="margin-top: 10px;color:#fff">We provide onsite support services.The User Support and Engagement On-Site Support group is committed to providing professional, informed, courteous, customer-focused IT services.</p>

                  </section>
                  <hr style="background-color: white;">
              </section>


          </div>
          <div>

          </div>
      </div>
  </div>
</div>
<div style="width:100%;height:100px;background: linear-gradient(-4deg, white 50%,transparent 50%, #2fc5b9 51%)"></div>





@endsection
