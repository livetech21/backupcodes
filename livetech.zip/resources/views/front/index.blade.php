@extends('front/layout')
@section('page_title','Livetech-Index')

@section('container')




@endsection
