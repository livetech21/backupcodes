@extends('front/layout')
@section('page_title','Livetech-Case-Studies')

@section('container')

<style>
    .card{
        padding:15px;
    }
      .card:hover {
      box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
      transition: 0.3s;
      border-left:2px solid #2fc5b9;
      border-right:2px solid #2b6db4;
      border-radius:10px;
      padding:none;
  }
    </style>

<img class="img-fluid" src="{{ asset('img/gallery.png') }}" alt="livetch"/>

<div class="album py-5 bg-light">

  <div >
  <div class="container" style="background-image: url('{{ asset('img/bgg3.png') }}');
  background-size: auto;">
    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b>Case Studies In Details</b></p>
<hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">


<div class="row">
    <div class="col-lg-6 col-xs-12">
        <div class="card" style="padding:20px;">
            <h3>Heighlights</h3>
            <hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

            <p align="justify">nbcsdn cb dx cbndx cb xdbv sc.</p>
            <p align="justify">nbcsdn cb dx cbndx cb xdbv sc.</p>
            <p align="justify">nbcsdn cb dx cbndx cb xdbv sc.</p>

        </div>
    </div>
    <div class="col-lg-6 col-xs-12">
    <img class="img-fluid img-flip" src="{{ asset('img/bgg1.png') }}" alt="livetch"/>
    </div>
</div>



  </div>
</div>

</div>


<div class="container">

<p style="margin-top:20px;font-size: 30px;color:#2b6db4;text-align: center;"><b>Overview</b></p>
          <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">


<div class="card">

<div style="padding:15px;background-image: url('{{ asset('img/bgg4.png') }}');  background-repeat: no-repeat;
  background-size: auto;" >
<h4> <b style="color:#2b6db4;font-weight:600;"> About Clients </b> </h4>

<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="{{ asset('img/icons/downarrow.png') }}" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>

<p align="justify">
jfcbds csdb bsd fbsd f sdmnf sdn fcnsd.</p>
</div>
<hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

<div style="padding:15px;background-image: url('{{ asset('img/bgg4.png') }}');  background-repeat: no-repeat;
  background-size: auto;">
<h4> <b style="color:#2b6db4;font-weight:600;"> Challenges </b> </h4>
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="{{ asset('img/icons/downarrow.png') }}" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>
<p align="justify">
sndvhzfbc sbdn cbsd cbnsd bnv dxc.
</p>
</div>
<hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

<div style="padding:15px;background-image: url('{{ asset('img/bgg4.png') }}');  background-repeat: no-repeat;
  background-size: auto;">
<h4> <b style="color:#2b6db4;font-weight:600;"> Key Initiative </b> </h4>
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="{{ asset('img/icons/downarrow.png') }}" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>
<p align="justify">
jsd bfc d cbsd cbnsd bncsd.
</p>
</div>
<hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

<div style="padding:15px;background-image: url('{{ asset('img/bgg4.png') }}');  background-repeat: no-repeat;
  background-size: auto;">
<h4><b style="color:#2b6db4;font-weight:600;">Business Impact </b></h4>
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="{{ asset('img/icons/downarrow.png') }}" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>
<p align="justify">
cjsdvcb sdbnc sdbc bsd xfx.
</p>
</div>



</div>
</div>

@endsection
