@extends('front/layout')
@section('page_title','Livetech-Contact-us')

@section('container')


<style>
  .parallax {
      /* The image used */
      background-image: url("images/get in touch.jpg");
      min-height: 500px;
      background-attachment: fixed;
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
  }
</style>

<img class="img-fluid" src="{{ asset('img/contact.png') }}" alt="livetch"/>

<div >
<div style="background: url('images/get in touch.jpg') no-repeat center bottom;
      background-size: 100% auto;background-color:#2b6db4;">
<div class="container">

  <p style="font-size: 30px;color:white;text-align: center;"><b>Get In Touch</b></p>

  <div class='row'>

      <div class="col-lg-6 col-xs-12" style="background-color:white;border-radius:15px;">
          <br>
          <h4 style='color:#2b6db4;'> <b style="color:#2fc5b9;">LiveTech</b> Private Limited</h4>
          <br>
          <h5 style='color:#2b6db4;'>Location :</h5>
          <p style='color:#2b6db4;;font-size: 16px;'>223, First Floor, MSX Mall, Swarn Nagari, Surajpur Site 4, Greater Noida, Uttar Pradesh 201308</p>

          <h5 style='color:#2b6db4;'><i class='fa fa-phone' style='color:#2b6db4;'></i>&nbsp; Enquiry :</h5>
          <p style='color:#2b6db4;font-size: 16px;'> +91 9643824091</p>

          <h5 style='color:#2b6db4;'><i class='fa fa-envelope' style='color:#2b6db4;'></i>&nbsp;Email :</h5>
          <p style='color:#2b6db4;;font-size: 16px;'>info@livetechservices.com</p>
          <h5 style='color:#2b6db4;'><i class='fa fa-star' style='color:#2b6db4;'></i>&nbsp;Follow Us :</h5>
          <p style='color:#2b6db4;;font-size: 16px;'><i class='fa fa-facebook' style='color:#2b6db4;padding:5px;'></i><i class='fa fa-twitter' style='color:#2b6db4;padding:5px;'></i><i class='fa fa-linkedin' style='color:#2b6db4;padding:5px;'></i></p>
          <br>


</div>

      <div class="col-lg-6 col-xs-12" style="margin-top:10px;">

@if(session('message'))
 <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
             {{ session('message')}}

           </div>
            @endif
<form action="{{ url('contact_form') }}" method="post" role="form" class="info-box">
            	@csrf
              <div class="form-row">
                <div class="col form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Name..." value="{{ old('name') }}"  />
                   @error('name')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
                <div class="col form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Email..." value="{{ old('email') }}"  />
                @error('email')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
              </div>
              <div class="form-row">
                <div class="col form-group">
                  <input type="number" name="phone" class="form-control" id="phone" placeholder="Phone..."  value="{{ old('phone') }}" />
                   @error('phone')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
                <div class="col form-group">
                  <input type="text" class="form-control" name="subject" id="subject" placeholder="subject..." value="{{ old('subject') }}" />
                @error('subject')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
              </div>

              <div class="form-group">
                <textarea class="form-control" name="message" rows="5"   placeholder="Message"></textarea>
                  @error('message')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
              </div>

<center>             <button type="submit" class="btn btn-primary">SUBMIT</button></center>
            </form>

      </div>


  </div>
</div>
<br>
</div>
</div>

<div >
<div id="map1" class="map" style="border:2px solid #2b6db4">
  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3504.120212764419!2d77.36765251446462!3d28.566152693834276!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce5f2fa697fad%3A0x26e338c34c82ba35!2sShiv%20Mandir%20Barola%20Sec%2049!5e0!3m2!1sen!2sin!4v1599210740927!5m2!1sen!2sin" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
</div>
</div>



@endsection
