@extends('front/layout')
@section('page_title','Livetech-Home')

@section('container')


<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">

  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="imgnew/bb2.jpg" style="animation: slideIn 1.5s ease-in-out forwards;" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="imgnew/bb2.jpg" style="animation: slideIn 1.5s ease-in-out forwards;" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="imgnew/bb2.jpg" style="animation: slideIn 1.5s ease-in-out forwards;" alt="Third slide">
    </div>
  </div>

</div>
<span>
<div style="text-align:center;margin-top:5px;">
  <i data-target="#carouselExampleIndicators" data-slide-to="0" class="active" class="fa fa-circle spin circle buttonok" style="padding:5px;color:#191970;"></i>
  <i data-target="#carouselExampleIndicators" data-slide-to="1" class="fa fa-circle spin circle buttonok" style="padding:5px;color:#191970;"></i>
  <i data-target="#carouselExampleIndicators" data-slide-to="2" class="fa fa-circle spin circle buttonok" style="padding:5px;color:#191970;"></i>
</div>
</span>

<style>
  .card {
      box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
      transition: 0.3s;
      background-color:transparent;
  }

  .card:hover {
      box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
      border:2px solid #075196;
  }

  .kk{
    border:2px solid #075196;
  }
    .kk:hover{
    border:3px solid #067751;
  }

.thumb {
  width: 100%;
  height: 300px;
  margin: 10px auto;
  perspective: 1000px;
}

.thumb a {
  display: block;
  width: 100%;
  height: 100%;
  background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)),
  url("imgnew/test.jpg");
  background-size: 0, cover;
  transform-style: preserve-3d;
  transition: all 0.5s;
}

.thumb:hover a {
  transform: rotateX(80deg);
  transform-origin: bottom;
}
.thumb a:after {
  content: '';
  position: absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 36px;
  background: inherit;
  background-size: cover, cover;
  background-position: bottom;
  transform: rotateX(90deg);
  transform-origin: bottom;
}
.thumb a span {
  color: white;
  text-transform: uppercase;
  position: absolute;
  top: 100%;
  left: 0;
  width: 100%;
  text-align: center;
  transform: rotateX(-89.99deg);
  transform-origin: top;
  z-index: 1;
}
.thumb a:before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  box-shadow: 0 0 100px 50px rgba(0, 0, 0, 0.5);
  transition: all 0.5s;
  opacity: 0.15;
  transform: rotateX(95deg) translateZ(-80px) scale(0.75);
  transform-origin: bottom;
}

.thumb:hover a:before {
  opacity: 1;
  box-shadow: 0 0 25px 25px rgba(0, 0, 0, 0.5);
  transform: rotateX(0) translateZ(-60px) scale(0.85);
}

</style>


<div >
  <div class='container'>
    <div class='row'>

        <div class='col-lg-12'>
          <br>
            <p style="font-size: 30px;color:#075196;text-align: center;"><b>Build and Deploy with Excellent Services</b></p>
            <hr style="background-color:#28AE7B;width:20%;height:2px;text-align: center;margin-top: -10px;">

        </div>


    <div class="container" style="background-image: url('imgnew/bg1.jpg');">
      <div class="row" >

          <div class='col-lg-6 col-xs-12' style="margin-top: 20px;">
              <div class='card ch kk'>
                  <div class='card-body' style='padding:2px;padding-bottom: 15px;padding-top: 10px;padding-left: 10px;'>
                      <div class='row'>
                          <div class=" col-lg-4 col-sm-4 col-xs-12">
                            <img src='images/web  desgning bg.png' style="margin-left: auto;margin-right: auto;display: block;">


                          </div>
                          <div class="col-md-8 col-sm-8 col-xs-12">

                           <a href='#/WebDesignServices'> <h5 text-alignment="center" style='font-size: 19px;font-weight: 500;margin-top: 20px;text-align: center;color:#075196;'>Website Design</h5></a>
                              <div style='font-family: revert;padding:5px;color:black;'>We are expert in designing and developing responsive websites and portals. It enables customers access website from any device.</div>

                          </div>






                      </div>


                  </div>
              </div>
          </div>


          <div class='col-lg-6 col-xs-12' style="margin-top: 20px;">
              <div class='card ch kk' >
                  <div class='card-body' style='padding:2px;padding-bottom: 15px;padding-top: 10px;padding-left: 10px;'>
                      <div class='row'>
                          <div class=" col-lg-4 col-sm-4 col-xs-12">
                              <img src='images/digital marketing bg.png' style="margin-left: auto;margin-right: auto;display: block;">


                          </div>
                          <div class="col-md-8 col-sm-8 col-xs-12">

                            <a href='#/WebDesignServices'> <h5 style='font-size: 19px;font-weight: 500;margin-top: 20px;text-align: center;color:#075196;'>Digital Marketing</h5></a>
                            <div style='font-family: revert;padding:5px;color:black;'>We provide digital marketing services to our client to greatly help them promote their products and services.</div>

                          </div>






                      </div>


                  </div>
              </div>
          </div>
      </div>
      <div class="row">

        <div class='col-lg-6 col-xs-12' style="margin-top: 20px;">
            <div class='card ch kk' >
                <div class='card-body' style='padding:2px;padding-bottom: 15px;padding-top: 10px;padding-left: 10px;'>
                    <div class='row'>
                        <div class=" col-lg-4 col-sm-4 col-xs-12">
                          <img src='images/erp icon bg.png' style="margin-left: auto;margin-right: auto;display: block;">


                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-12">

                          <a href='#/WebDesignServices'>  <h5 style='font-size: 19px;font-weight: 500;margin-top: 20px;text-align: center;color:#075196;'>ERP</h5></a>
                          <div style='font-family: revert;padding:5px;color:black;'>We offer ERP development and maintenence services across varied industries and services.</div>

                        </div>






                    </div>


                </div>
            </div>
        </div>


        <div class='col-lg-6 col-xs-12' style="margin-top: 20px;">
            <div class='card ch kk' >
                <div class='card-body' style='padding:2px;padding-bottom: 15px;padding-top: 10px;padding-left: 10px;'>
                    <div class='row'>
                        <div class=" col-lg-4 col-sm-4 col-xs-12">
                          <img src='images/ecommerce solution bg.png' style="margin-left: auto;margin-right: auto;display: block;">


                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-12">

                          <a href='#/WebDesignServices'>  <h5 style='font-size: 19px;font-weight: 500;margin-top: 20px;text-align: center;color:#075196;'>E-commerce Solutions</h5></a>
                          <div style='font-family: revert;padding:5px;color:black;'>We offer E-commerce Solutions and maintenence services across varied industries and services.</div>

                        </div>






                    </div>


                </div>
            </div>
        </div>
    </div>
    <div class="row">

      <div class='col-lg-6 col-xs-12' style="margin-top: 20px;">
          <div class='card ch kk'>
              <div class='card-body' style='padding:2px;padding-bottom: 15px;padding-top: 10px;padding-left: 10px;'>
                  <div class='row'>
                      <div class=" col-lg-4 col-sm-4 col-xs-12">
                        <img src='images/crm bg.png' style="margin-left: auto;margin-right: auto;display: block;">


                      </div>
                      <div class="col-md-8 col-sm-8 col-xs-12">

                        <a href='#/WebDesignServices'> <h5 style='font-size: 19px;font-weight: 500;margin-top: 20px;text-align: center;color:#075196;'>CRM</h5></a>
                        <div style='font-family: revert;padding:5px;color:black;'>We offer attractive CRM Development, Responsive store design & development, eCommerce Mobile Apps development, Plugins & Module development and Product Support services.</div>

                      </div>






                  </div>


              </div>
          </div>
      </div>


      <div class='col-lg-6 col-xs-12' style="margin-top: 20px;">
          <div class='card ch kk'>
              <div class='card-body' style='padding:2px;padding-bottom: 15px;padding-top: 10px;padding-left: 10px;'>
                  <div class='row'>
                      <div class=" col-lg-4 col-sm-4 col-xs-12">
                        <img src='images/design_icon.png' style="margin-left: auto;margin-right: auto;display: block;">


                      </div>
                      <div class="col-md-8 col-sm-8 col-xs-12">

                        <a href='#/WebDesignServices'> <h5 style='font-size: 19px;font-weight: 500;margin-top: 20px;text-align: center;color:#075196;'>Graphics Designing</h5></a>
                        <div style='font-family: revert;padding:5px;color:black;'>We develop various types of logo's of Websites which best meet business objectives of our clients and create long-term value for their business. Our solutions help customers organize business cost effectively without compromising quality.</div>

                      </div>






                  </div>


              </div>
          </div>
      </div>
  </div>
  <br>
  </div>

  </div>
  </div>
  <br>
  </div>


<div >
<div class='col-lg-12'>
  <br>
    <p style="font-size: 30px;color:#075196;text-align: center;"><b>Why Do You Choose Live Tech Services</b></p>
    <hr style="background-color:#28AE7B;width:20%;height:2px;text-align: center;margin-top: -10px;">

</div>

<div class="container" style="margin-bottom:20px;">
<div class="col-lg-12 ">
<div class="row ">
    <div class="col-xl-3 col-lg-6" style="padding:5px;">
        <div class="card l-bg-cherry">
            <div class="card-statistic-3 p-4">
                <div class="card-icon card-icon-large"><i class="fa fa-user" style="margin-right:50px;font-size:200px;"></i></div>
                <div class="mb-4">
                    <h5 class="card-title mb-0">Agile Methodology</h5>
                </div>
                <div class="row align-items-center mb-2 d-flex">
                    <div class="col-8">
                        <h2 class="d-flex align-items-center mb-0">
                            99 %
                        </h2>
                    </div>
                    <div class="col-4 text-right">
                        <span> <i class="fa fa-arrow-up" ></i></span>
                    </div>
                </div>
                <div class="progress mt-1 " data-height="8" style="height: 8px;">
                    <div class="progress-bar l-bg-cyan" role="progressbar" data-width="25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style="width: 95%;"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6" style="padding:5px;">
        <div class="card l-bg-cherry">
            <div class="card-statistic-3 p-4">
                <div class="card-icon card-icon-large"><i class="fa fa-users" style="margin-right:50px;font-size:200px;"></i></div>
                <div class="mb-4">
                    <h5 class="card-title mb-0">End To End Solution</h5>
                </div>
                <div class="row align-items-center mb-2 d-flex">
                    <div class="col-8">
                        <h2 class="d-flex align-items-center mb-0">
                            99 %
                        </h2>
                    </div>
                    <div class="col-4 text-right">
                        <span> <i class="fa fa-arrow-up"></i></span>
                    </div>
                </div>
                <div class="progress mt-1 " data-height="8" style="height: 8px;">
                    <div class="progress-bar l-bg-green" role="progressbar" data-width="25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style="width: 95%;"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6" style="padding:5px;">
        <div class="card l-bg-cherry">
            <div class="card-statistic-3 p-4">
                <div class="card-icon card-icon-large"><i class="fa fa-globe" style="margin-right:50px;font-size:200px;"></i></div>
                <div class="mb-4">
                    <h5 class="card-title mb-0">Quality Code</h5>
                </div>
                <div class="row align-items-center mb-2 d-flex">
                    <div class="col-8">
                        <h2 class="d-flex align-items-center mb-0">
                            100 %
                        </h2>
                    </div>
                    <div class="col-4 text-right">
                        <span> <i class="fa fa-arrow-up"></i></span>
                    </div>
                </div>
                <div class="progress mt-1 " data-height="8" style="height: 8px;">
                    <div class="progress-bar l-bg-orange" role="progressbar" data-width="25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style="width: 100%;"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6" style="padding:5px;">
        <div class="card l-bg-cherry">
            <div class="card-statistic-3 p-4">
                <div class="card-icon card-icon-large"><i class="fa fa-bullhorn" style="margin-right:50px;font-size:200px;"></i></div>
                <div class="mb-4">
                    <h5 class="card-title mb-0">Onsite Support</h5>
                </div>
                <div class="row align-items-center mb-2 d-flex">
                    <div class="col-8">
                        <h2 class="d-flex align-items-center mb-0">
                           100 %
                        </h2>
                    </div>
                    <div class="col-4 text-right">
                        <span> <i class="fa fa-arrow-up"></i></span>
                    </div>
                </div>
                <div class="progress mt-1 " data-height="8" style="height: 8px;">
                    <div class="progress-bar l-bg-cyan" role="progressbar" data-width="50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 100%;"></div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>


<div >
<div class='col-lg-12'>
  <br>
    <p style="font-size: 30px;color:#075196;text-align: center;"><b>About Us</b></p>
    <hr style="background-color:#28AE7B;width:20%;height:2px;text-align: center;margin-top: -10px;">

</div>

<div class='container' style='margin-bottom:10px;'>
  <div class='row'>

<div class="col-lg-6">
  <!-- <img src="assets/imgnew/test.jpg" class="img-fluid" style="border-radius:50%;margin-top:10px;height:350px;width:100%;"> -->
  <div class="thumb" >
    <a href="#">
        <span>Welcome to the Livetech</span>
    </a>
  </div>

</div>
<div class="col-lg-6">
<!--
<div class="list-group" style="margin-top:10px;">
  <a href="#" class="list-group-item list-group-item-action d-flex" aria-current="true">
    <div class="d-flex gap-2 w-100 justify-content-between">
      <div style="padding:5px;">
        <h5 class="mb-0 txt" style="color:#075196;text-align:center;">Manufacturing Domain<i class="fa fa-long-arrow-right float-right" style="font-weight:100px;"></i></h5>
        <p align="justify" class="mb-0 opacity-75">We provide the different type of ERP and softwares such as School Management Software, Account Management Software and Inventory Management Software.</p>
      </div>
    </div>
  </a>
  <a href="#" class="list-group-item list-group-item-action d-flex" aria-current="true">

    <div class="d-flex gap-2 w-100 justify-content-between">
      <div style="padding:5px;">
        <h5 class="mb-0 txt" style="color:#075196;text-align:center;">Retail Supply Chain<i class="fa fa-long-arrow-right float-right" style="font-weight:100px;"></i></h5>
        <p align="justify" class="mb-0 opacity-75">Our Expert team of Retail & Supply Chain Management deliver highly reliable and robust products.</p>
      </div>
    </div>
  </a>
  <a href="#" class="list-group-item list-group-item-action d-flex" aria-current="true">

    <div class="d-flex gap-2 w-100 justify-content-between">
      <div style="padding:5px;">
        <h5 class="mb-0 txt" style="color:#075196;text-align:center;">Finance Domain<i class="fa fa-long-arrow-right float-right" style="font-weight:100px;"></i></h5>
        <p align="justify" class="mb-0 opacity-75">We bring highly learned financial domain experts for robust, secure and dependable financial solutions.</p>
      </div>
    </div>
  </a> -->

  <p align="justify" style="margin-top:10px;color:#067751;font-weight:500;">LTS is one of the fastest growing software development companies in Delhi NCR that provides one-stop-web-solution to every organization and individual. We have a vivid presence in the Indian as well as the International market for our top-notch software development services, Being a customer oriented company, we pay special attention to offer our clients an insight driven intuitive service to ensure the best outcome at the most affordable budget.understand the requirement of our customers, thus we have hired the professionals who can think like a customer and deliver the solutions exactly. Our products are totally trend defining that rely on the basis of market's needs. We cover almost all verticals of software solutions from the web to latest android and ios application. We are trying to make customer’s life easy and comfortable through technology because we are making something different for them.</p>
<button type="button" class="btn btn-success" style="background-color:cadetblue;" data-toggle="modal" data-target="#exampleModalCenter">
  Quick call <i class="fa fa-bullhorn"></i>
</button>


</div>


</div>

  </div>

</div>
</div>


  <style>
      .cards {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 2rem;
        margin: 4rem 5vw;
        padding: 0;
        list-style-type: none;
      }

      .card {
        position: relative;
        display: block;
        height: 100%;
        border-radius: calc(var(--curve) * 1px);
        overflow: hidden;
        text-decoration: none;
      }

      .card__image {
        width: 100%;
        height: auto;
      }

      .card__overlay {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        z-index: 1;
        border-radius: calc(var(--curve) * 1px);
        background-color: var(--surface-color);
        transform: translateY(100%);
        transition: .2s ease-in-out;
      }

      .card:hover .card__overlay {
        transform: translateY(0);
      }

      .card__header {
        position: relative;
        display: flex;
        align-items: center;
        gap: 2em;
        padding: 2em;
        border-radius: calc(var(--curve) * 1px) 0 0 0;
        background-color: cadetblue;
        transform: translateY(-100%);
        transition: .2s ease-in-out;
      }

      .card__arc {
        width: 80px;
        height: 80px;
        position: absolute;
        bottom: 100%;
        right: 0;
        z-index: 1;
      }

      .card__arc path {
        fill: cadetblue;
        d: path("M 40 80 c 22 0 40 -22 40 -40 v 40 Z");
      }

      .card:hover .card__header {
        transform: translateY(0);
      }

      .card__thumb {
        flex-shrink: 0;
        width: 50px;
        height: 50px;
        border-radius: 50%;
      }

      .card__title {
        font-size: 1em;
        margin: 0 0 .3em;
        color: #6A515E;
      }

      .card__tagline {
        display: block;
        margin: 1em 0;

        font-size: .8em;
        color: #D7BDCA;
      }

      .card__status {
        font-size: .8em;
        color: #D7BDCA;
      }

      .card__description {
        padding: 0 2em 2em;
        margin: 0;
        color: white;

        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 3;
        overflow: hidden;
        background-color: #0068a1;
      }
  </style>


  <style>
    .card {
        background-color: #fff;
        border-radius: 10px;
        border: none;
        position: relative;
        margin-bottom: 30px;
        box-shadow: 0 0.46875rem 2.1875rem rgba(90,97,105,0.1), 0 0.9375rem 1.40625rem rgba(90,97,105,0.1), 0 0.25rem 0.53125rem rgba(90,97,105,0.12), 0 0.125rem 0.1875rem rgba(90,97,105,0.1);
    }
    .l-bg-cherry {
        background: linear-gradient(to right, #075196, rgba(29, 192, 170, 0.623)) !important;
        color: #fff;
    }

    .l-bg-blue-dark {
        background: linear-gradient(to right, #373b44, rgba(29, 192, 170, 0.623)) !important;
        color: #fff;
    }

    .l-bg-green-dark {
        background: linear-gradient(to right, #0a504a, #38ef7d) !important;
        color: #fff;
    }

    .l-bg-orange-dark {
        background: linear-gradient(to right, #a86008, #ffba56) !important;
        color: #fff;
    }

    .card .card-statistic-3 .card-icon-large .fas, .card .card-statistic-3 .card-icon-large .far, .card .card-statistic-3 .card-icon-large .fab, .card .card-statistic-3 .card-icon-large .fal {
        font-size: 110px;
    }

    .card .card-statistic-3 .card-icon {
        text-align: center;
        line-height: 50px;
        margin-left: 15px;
        color: #000;
        position: absolute;
        right: -5px;
        top: 20px;
        opacity: 0.1;
    }

    .l-bg-cyan {
        background: linear-gradient(135deg, #289cf5, #84c0ec) !important;
        color: #fff;
    }

    .l-bg-green {
        background: linear-gradient(135deg, #23bdb8 0%, #43e794 100%) !important;
        color: #fff;
    }

    .l-bg-orange {
        background: linear-gradient(to right, #f9900e, #ffba56) !important;
        color: #fff;
    }

    .l-bg-cyan {
        background: linear-gradient(135deg, #289cf5, #84c0ec) !important;
        color: #fff;
    }
    </style>


<style>
    /* Rounded tabs */

@media (min-width: 576px) {
    .rounded-nav {
      border-radius: 50rem !important;
    }
  }

  @media (min-width: 576px) {
    .rounded-nav .nav-link {
      border-radius: 50rem !important;
    }
  }

  /* With arrow tabs */

  .with-arrow .nav-link.active {
    position: relative;
  }

  .with-arrow .nav-link.active::after {
    content: '';
    border-left: 6px solid transparent;
    border-right: 6px solid transparent;
    border-top: 6px solid #2b90d9;
    position: absolute;
    bottom: -6px;
    left: 50%;
    transform: translateX(-50%);
    display: block;
  }

  /* lined tabs */

  .lined .nav-link {
    border: none;
    border-bottom: 3px solid transparent;
  }

  .lined .nav-link:hover {
    border: none;
    border-bottom: 3px solid transparent;
  }

  .lined .nav-link.active {
    background: none;
    color: #555;
    border-color: #28AE7B;
  }

  /*
  *
  * ==========================================
  * FOR DEMO PURPOSE
  * ==========================================
  *
  */


  .nav-pills .nav-link {
    color: #555;
  }
  .text-uppercase {
    letter-spacing: 0.1em;
  }


</style>

<div class="">
<div class='col-lg-12'>
  <br>
    <p style="font-size: 30px;color:#075196;text-align: center;"><b>Our Servecing Domains</b></p>
    <hr style="background-color:#28AE7B;width:20%;height:2px;text-align: center;margin-top: -10px;">

</div>

  <div class="container">

    <div class="p-5 bg-white rounded shadow mb-5">
      <!-- Lined tabs-->
      <ul id="myTab2" role="tablist" class="nav nav-tabs nav-pills with-arrow lined flex-sm-row text-center">
        <li class="nav-item flex-sm-fill">
          <a id="home2-tab" data-toggle="tab" href="#home2" role="tab" aria-controls="home2" aria-selected="true" class="nav-link text-uppercase font-weight-bold mr-sm-3 rounded-0 active"><b style="color:#0068a1;">Health</b></a>
        </li>
        <li class="nav-item flex-sm-fill">
          <a id="profile2-tab" data-toggle="tab" href="#profile2" role="tab" aria-controls="profile2" aria-selected="false" class="nav-link text-uppercase font-weight-bold mr-sm-3 rounded-0"><b style="color:#0068a1;">Real Estate</b></a>
        </li>
        <li class="nav-item flex-sm-fill">
          <a id="contact2-tab" data-toggle="tab" href="#contact2" role="tab" aria-controls="contact2" aria-selected="false" class="nav-link text-uppercase font-weight-bold rounded-0"><b style="color:#0068a1;">Media</b></a>
        </li>

        <li class="nav-item flex-sm-fill">
          <a id="profile2-tab" data-toggle="tab" href="#profile12" role="tab" aria-controls="profile2" aria-selected="false" class="nav-link text-uppercase font-weight-bold mr-sm-3 rounded-0"><b style="color:#0068a1;">NGO's</b></a>
        </li>
        <li class="nav-item flex-sm-fill">
          <a id="contact2-tab" data-toggle="tab" href="#contact12" role="tab" aria-controls="contact2" aria-selected="false" class="nav-link text-uppercase font-weight-bold rounded-0"><b style="color:#0068a1;">Hotel</b></a>
        </li>
        <li class="nav-item flex-sm-fill">
          <a id="profile2-tab" data-toggle="tab" href="#profile22" role="tab" aria-controls="profile2" aria-selected="false" class="nav-link text-uppercase font-weight-bold mr-sm-3 rounded-0"><b style="color:#0068a1;">Booking</b></a>
        </li>
        <li class="nav-item flex-sm-fill">
          <a id="contact2-tab" data-toggle="tab" href="#contact22" role="tab" aria-controls="contact2" aria-selected="false" class="nav-link text-uppercase font-weight-bold rounded-0"><b style="color:#0068a1;" >Education</b></a>
        </li>
        <li class="nav-item flex-sm-fill">
          <a id="profile2-tab" data-toggle="tab" href="#profile32" role="tab" aria-controls="profile2" aria-selected="false" class="nav-link text-uppercase font-weight-bold mr-sm-3 rounded-0"><b style="color:#0068a1;" >Labs</b></a>
        </li>
      </ul>
      <div id="myTab2Content" class="tab-content">

        <div id="home2" role="tabpanel" aria-labelledby="home-tab" class="tab-pane fade px-4 py-5 show active" style="background-image: url('imgnew/bg5.jpg');">
          <p class="leade " align="justify">We are expert in designing and developing responsive websites and portals. It enables customers access website from any device.</p>
        </div>
        <div id="profile2" role="tabpanel" aria-labelledby="profile-tab" class="tab-pane fade px-4 py-5" style="background-image: url('imgnew/bg6.jpg');">
          <p class="leade">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
            irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
        <div id="contact2" role="tabpanel" aria-labelledby="contact-tab" class="tab-pane fade px-4 py-5" style="background-image: url('imgnew/bg4.jpg');">
          <p class="leade" align="justify">We provide digital marketing services to our client to greatly help them promote their products and services.</p>
        </div>
        <div id="profile12" role="tabpanel" aria-labelledby="profile-tab" class="tab-pane fade px-4 py-5" style="background-image: url('imgnew/bg1.jpg');">
          <p class="leade" align="justify">We offer attractive CRM Development, Responsive store design & development, eCommerce Mobile Apps development, Plugins & Module development and Product Support services.</p>
        </div>
        <div id="contact12" role="tabpanel" aria-labelledby="contact-tab" class="tab-pane fade px-4 py-5" style="background-image: url('imgnew/bg2.jpg');">
          <p class="leade" align="justify">We offer clients mobile development services for android and ios platforms.</p>
        </div>
        <div id="profile22" role="tabpanel" aria-labelledby="profile-tab" class="tab-pane fade px-4 py-5" style="background-image: url('imgnew/bg4.jpg');">
          <p class="leade">We use the best-in-class technology to design and develop web portals.Our team of developers are very well versed in developing any kind of portals.</p>
        </div>
        <div id="contact22" role="tabpanel" aria-labelledby="contact-tab" class="tab-pane fade px-4 py-5" style="background-image: url('imgnew/bg3.jpg');">
          <p class="leade" align="justify">We offer ERP development and maintenence services across varied industries and services.</p>
        </div>
        <div id="profile32" role="tabpanel" aria-labelledby="profile-tab" class="tab-pane fade px-4 py-5" style="background-image: url('imgnew/bg2.jpg');">
          <p class="leade" align="justify">We are specialised in delivering Graphics Designing, Our team comprises of the experts who have strong experience of handling large chunks of data.</p>
        </div>
        <div id="contact32" role="tabpanel" aria-labelledby="contact-tab" class="tab-pane fade px-4 py-5"style="background-image: url('imgnew/bg1.jpg');">
          <p class="leade" align="justify">We develop softwares which best meet business objectives of our clients and create long-term value for their business. Our solutions help customers organize business cost effectively without compromising quality.</p>
        </div>

      </div>
      <!-- End lined tabs -->
    </div>

  </div>
</div>




<div >
<div style="background-color:white;">
<div class="container">

  <p style="font-size: 30px;color:#075196;text-align: center;"><b>Get In Touch</b></p>

  <div class='row'>

      <div class="col-lg-6 col-xs-12">
        <!-- <p align="justify" style='color:black;border-radius:10px;background-color:white;padding:10px;font-family: revert;font-size: 15px;line-height: 25px;font-weight:200px;'>LTS is IT Company and we are dealing with Web Development, mobile application, Big Data Solution, Digital Marketing, Web Portal Development, ERP developemnt, Software Development and IT Services.</p> -->
        <div class="thumb" >
          <a href="#">
              <span>Quick Contact</span>
          </a>
        </div>
        <br>
      </div>


      <div class="col-lg-6 col-xs-12">

@if(session('message'))
 <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
             {{ session('message')}}

           </div>
            @endif
<form action="{{ url('contact_form') }}" method="post" role="form" class="info-box">
            	@csrf
              <div class="form-row">
                <div class="col form-group">
                  <input type="text" name="name" class="form-control" id="name" style="border: 2px solid #075196;height: 44px;color: #075196;padding: 6px 12px;font-size: 16px;font-weight: 500;line-height: 24px;position: relative;margin-bottom: 10px;background-color:transparent; font-family: revert;" placeholder="Name" value="{{ old('name') }}"  />
                   @error('name')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
                <div class="col form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Email" value="{{ old('email') }}" style="border: 2px solid #075196;height: 44px;color: #075196;padding: 6px 12px;font-size: 16px;font-weight: 500;line-height: 24px;position: relative;margin-bottom: 10px;background-color:transparent; font-family: revert;" />
                @error('email')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
              </div>
              <div class="form-row">
                <div class="col form-group">
                  <input type="number" name="phone" class="form-control" id="phone" placeholder="Phone"  value="{{ old('phone') }}" style="border: 2px solid #075196;height: 44px;color: #075196;padding: 6px 12px;font-size: 16px;font-weight: 500;line-height: 24px;position: relative;margin-bottom: 10px;background-color:transparent; font-family: revert;" />
                   @error('phone')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
                <div class="col form-group">
                  <input type="text" class="form-control" name="subject" id="subject" placeholder="subject" value="{{ old('subject') }}" style="border: 2px solid #075196;height: 44px;color: #075196;padding: 6px 12px;font-size: 16px;font-weight: 500;line-height: 24px;position: relative;margin-bottom: 10px;background-color:transparent; font-family: revert;" />
                @error('subject')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
              </div>

              <div class="form-group">
                <textarea class="form-control" name="message" rows="5"   placeholder="Message" style="border: 2px solid #075196;height: auto;color: #075196;padding: 6px 12px;font-size: 16px;font-weight: 500;line-height: 24px;position: relative;margin-bottom: 10px;background-color:transparent; font-family: revert;"></textarea>
                  @error('message')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
              </div>

<center>             <button type="submit" class="btn btn-primary" style='background-color: #067751;color:white;width:100px;height:40px;'>SUBMIT</button></center>
            </form>



          <br>
      </div>


  </div>
</div>
</div>
</div>


</div>

<style>
  .contact-form{
    background: #fff;
    margin-top: 10%;
    margin-bottom: 5%;
    width: 70%;
}
.contact-form .form-control{
    border-radius:1rem;
}
.contact-image{
    text-align: center;
}
.contact-image img{
    border-radius: 6rem;
    width: 11%;
    margin-top: -3%;
    transform: rotate(29deg);
}
.contact-form form{
    padding: 5%;
}
.contact-form form .row{
    margin-bottom: -7%;
}
.contact-form h3{
    margin-bottom: 8%;
    margin-top: -10%;
    text-align: center;
    color: #0062cc;
}
.contact-form .btnContact {
    width: 100%;
    border: none;
    border-radius: 1rem;
    padding: 1.5%;
    background: #0062cc;
    font-weight: 600;
    color: #fff;
    cursor: pointer;
}
.btnContactSubmit
{
    width: 50%;
    border-radius: 1rem;
    padding: 1.5%;
    color: #fff;
    background-color: #0062cc;
    border: none;
    cursor: pointer;
}
</style>

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" style="color:#067751;">Quick call <i class="fa fa-bullhorn"></i></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="background-image: url('imgnew/bg6.jpg');">
        <div class="container contact-form">
          <div class="contact-image">
              <img src="https://image.ibb.co/kUagtU/rocket_contact.png" alt="rocket_contact"/>
          </div>
          <form method="post">
              <h3>Drop Us a Message</h3>
             <div class="row">
                  <div class="col-lg-12">
                      <div class="form-group">
                          <input type="text" name="txtName" class="form-control" placeholder="Your Name *" value="" />
                      </div>
                      <div class="form-group">
                          <input type="text" name="txtEmail" class="form-control" placeholder="Your Email *" value="" />
                      </div>
                      <div class="form-group">
                          <input type="text" name="txtPhone" class="form-control" placeholder="Your Phone Number *" value="" />
                      </div>

                  </div>
                  <div class="col-lg-12">
                      <div class="form-group">
                          <textarea name="txtMsg" class="form-control" placeholder="Your Message *" style="width: 100%; height: 150px;"></textarea>
                      </div>
                      <div class="form-group">
                        <input type="submit" name="btnSubmit" class="btnContact" value="Send Message" />
                    </div>
                  </div>

              </div>
          </form>
</div>
      </div>

    </div>
  </div>
</div>


<br>
<img src="imgnew/cc.jpg" class="img-fluid" width="100%" style="margin-bottom:10px;height:200px;">




<style>
  .parallax {
      /* The image used */
      background-image: url("images/bg1.jpg");
      /* Set a specific height */
      min-height: 450px;
      /* Create the parallax scrolling effect */
      background-attachment: fixed;
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
  }
</style>

<div >
<div class="parallax">
  <div style="background-color:  #075196;opacity:0.8;height: auto;padding:10px;">

      <br>
      <p style="font-size: 30px;color:white;text-align: center;"><b>What Clients say</b></p>
<br>
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">

<div class="row">
    <div class="col-lg-6 col-md-6 col-xs-12">
    <center>
<div class="container">

<div style="border:2px white solid;padding:10px;border-radius:15px;">
<img class="img-fluid" src="images/seo.jpg" style="border:5px white solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
<br>
<p align="justify" style="color:white;">
<i class="fa fa-quote-left" style="color:white;" aria-hidden="true"></i>
hcbsdx cdhx vjd hjfd vdnfx cvjndf v dvb sjxd bs dba frbferj frhjdbf hfse dch vfghsdb vbdx bsd.
<i class="fa fa-quote-right" style="color:white;" aria-hidden="true"></i>
</p>
<h4   style="margin-right:20px;color:white;"><b>- &nbsp; Tony</b></h4>
</div>
</div>
</center>
    </div>
    <div class="col-lg-6 col-md-6 col-xs-12">
    <center>
<div class="container">

<div style="border:2px white solid;padding:10px;border-radius:15px;">
<img class="img-fluid" src="images/seo.jpg" style="border:5px white solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
<br>
<p align="justify" style="color:white;">
<i class="fa fa-quote-left" style="color:white;" aria-hidden="true"></i>
hcbsdx cdhx vjd hjfd vdnfx cvjndf v dvb sjxd bs dba frbferj frhjdbf hfse dch vfghsdb vbdx bsd.
<i class="fa fa-quote-right" style="color:white;" aria-hidden="true"></i>
</p>
<h4   style="margin-right:20px;color:white;"><b>- &nbsp; Tony</b></h4>
</div>
</div>
</center>
    </div>
</div>

    </div>
    <div class="carousel-item">


<div class="row">
    <div class="col-lg-6 col-md-6 col-xs-12">
    <center>
<div class="container">

<div style="border:2px white solid;padding:10px;border-radius:15px;">
<img class="img-fluid" src="images/seo.jpg" style="border:5px white solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
<br>
<p align="justify" style="color:white;">
<i class="fa fa-quote-left" style="color:white;" aria-hidden="true"></i>
hcbsdx cdhx vjd hjfd vdnfx cvjndf v dvb sjxd bs dba frbferj frhjdbf hfse dch vfghsdb vbdx bsd.
<i class="fa fa-quote-right" style="color:white;" aria-hidden="true"></i>
</p>
<h4   style="margin-right:20px;color:white;"><b>- &nbsp; Tony</b></h4>
</div>
</div>
</center>
    </div>
    <div class="col-lg-6 col-md-6 col-xs-12">
    <center>
<div class="container">

<div style="border:2px white solid;padding:10px;border-radius:15px;">
<img class="img-fluid" src="images/seo.jpg" style="border:5px white solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
<br>
<p align="justify" style="color:white;">
<i class="fa fa-quote-left" style="color:white;" aria-hidden="true"></i>
hcbsdx cdhx vjd hjfd vdnfx cvjndf v dvb sjxd bs dba frbferj frhjdbf hfse dch vfghsdb vbdx bsd.
<i class="fa fa-quote-right" style="color:white;" aria-hidden="true"></i>
</p>
<h4   style="margin-right:20px;color:white;"><b>- &nbsp; Tony</b></h4>
</div>
</div>
</center>
    </div>
</div>


    </div>

    <div class="carousel-item">


    <div class="row">
    <div class="col-lg-6 col-md-6 col-xs-12">
    <center>
<div class="container">

<div style="border:2px white solid;padding:10px;border-radius:15px;">
<img class="img-fluid" src="images/seo.jpg" style="border:5px white solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
<br>
<p align="justify" style="color:white;">
<i class="fa fa-quote-left" style="color:white;" aria-hidden="true"></i>
hcbsdx cdhx vjd hjfd vdnfx cvjndf v dvb sjxd bs dba frbferj frhjdbf hfse dch vfghsdb vbdx bsd.
<i class="fa fa-quote-right" style="color:white;" aria-hidden="true"></i>
</p>
<h4   style="margin-right:20px;color:white;"><b>- &nbsp; Tony</b></h4>
</div>
</div>
</center>
    </div>
    <div class="col-lg-6 col-md-6 col-xs-12">
    <center>
<div class="container">

<div style="border:2px white solid;padding:10px;border-radius:15px;">
<img class="img-fluid" src="images/seo.jpg" style="border:5px white solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
<br>
<p align="justify" style="color:white;">
<i class="fa fa-quote-left" style="color:white;" aria-hidden="true"></i>
hcbsdx cdhx vjd hjfd vdnfx cvjndf v dvb sjxd bs dba frbferj frhjdbf hfse dch vfghsdb vbdx bsd.
<i class="fa fa-quote-right" style="color:white;" aria-hidden="true"></i>
</p>
<h4   style="margin-right:20px;color:white;"><b>- &nbsp; Tony</b></h4>
</div>
</div>
</center>
    </div>
</div>


    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


      <div>
          <div>

          </div>
      </div>
  </div>

</div>
</div>

<style>
  .modal.left .modal-dialog,
  .modal.right .modal-dialog {
      position: fixed;
      margin: auto;
      width: 320px;
      height: 100%;
      -webkit-transform: translate3d(0%, 0, 0);
      -ms-transform: translate3d(0%, 0, 0);
      -o-transform: translate3d(0%, 0, 0);
      transform: translate3d(0%, 0, 0);
  }

  .modal.left .modal-content,
  .modal.right .modal-content {
      height: 100%;
      width: 100%;
      margin-top: 100px;
      margin-left: 20px;
      overflow-y: hidden;
      padding: 10px 5px 0px 5px;
  }

  .modal.left .modal-body,
  .modal.right .modal-body {
      padding: 15px 15px 80px;
  }
  /*Right*/

  .modal.right.fade .modal-dialog {
      right: -30px;
      -webkit-transition: opacity 0.4s linear, right 0.8s ease-out;
      -moz-transition: opacity 0.3s linear, right 0.8s ease-out;
      -o-transition: opacity 0.3s linear, right 0.8s ease-out;
      transition: opacity 0.3s linear, right 0.8s ease-out;
      background: transparent;
  }

  .modal.right.fade.in .modal-dialog {
      right: 0;
  }

  .fade.show {
      background-color: transparent;
  }

  #hiddenPanel {
      position: fixed;
      top: 0;
      right: -270px;
      width: 270px;
      height: 250px;
  }

  #close-bar {
      /* position: absolute;
      left: -20px;
      margin-top: -350px; */
      /* background-image: url('assets/images/lets.png'); */
      /* background-color: red; */
      /* color: white;
      width: 20px;
      height: 250px; */
  }

</style>


<section id="hiddenPanel" class="txt-highlight-color bg-color bg-pattern">
  <div class="modal-dialog" role="document">
      <div class="modal-content " style='padding:10px;margin-top: 100px;'>




          <div class="modal-body " style="background-color: #075196;height: 435px;">
              <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close" style='color:white'><span aria-hidden="true">&times;</span></button> -->
<br>
              <p style='color:white;text-align: center;font-size: 14px;font-family: open sans,sans-serif;'><b>Request a call back now</b></p>

              <form style='margin-top:52px;'>
                  <input class='form-control' placeholder="Name" style="height:33px">
                  <input class='form-control' placeholder="Email" style='margin-top:13px;height:33px'>
                  <input class='form-control' placeholder="Phone" style='margin-top:13px;height:33px'>
                  <input class='form-control' placeholder="Service" style='margin-top:13px;height:33px'>
                  <textarea class='form-control' rows='2' placeholder="Message" style='margin-top:13px;'>
                       </textarea>
                  <br>
                  <div style='text-align: center;'>
                      <button class='btn btn-success' style='border-radius: 200px;'>Submit</button>
                  </div>


              </form>
          </div>

      </div>
      <!-- modal-content -->
  </div>


  <span id="close-bar" class="myButton" style='position: absolute;
      margin-top: 200px;
  height: 48px;
  width: 160px;
  text-align: center;
  box-shadow: -2px -1px 8px rgba(58,56,52,.28);
  cursor: pointer;
  background: #0068a1;
  top: 45%;
  font-weight: 600;
  left: -104px;
  border-radius: 3px 3px 0 0;
  transform: rotate(270deg);
  cursor: pointer;
  color: #fff;
  line-height: 48px;
  font-size: 16px;
  z-index: 999;' data-toggle="modal" data-target="#exampleModalCenter">Let's Connect </span>
</section>

<div class="modal right fade " id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
      <div class="modal-content " style='padding:10px;'>




          <div class="modal-body " style="background-color: #075196;height:200px">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close" style='color:white'><span aria-hidden="true">&times;</span></button>

              <p style='color:white;text-align: center;font-size: 14px;font-family: open sans,sans-serif;'><b>Request a call back now</b></p>

              <form style='margin-top:52px;'>
                  <input class='form-control' placeholder="Name" style="height:33px">
                  <input class='form-control' placeholder="Email" style='margin-top:13px;height:33px'>
                  <input class='form-control' placeholder="Phone" style='margin-top:13px;height:33px'>
                  <input class='form-control' placeholder="Service" style='margin-top:13px;height:33px'>
                  <textarea class='form-control' rows='2' placeholder="Message" style='margin-top:13px;'>
                       </textarea>
                  <br>
                  <div style='text-align: center;'>
                      <button class='btn btn-success' style='border-radius: 200px;'>Submit</button>
                  </div>


              </form>
          </div>

      </div>
      <!-- modal-content -->
  </div>
  <!-- modal-dialog -->
</div>



<div style="background-color:#d6d6c2;padding:50px;">
<br>
  <div class='row'>
      <div class="col-lg-8">
          <p style="font-size: 30px;color:#075196;text-align: center;"><b>Latest Blogs</b></p>
          <hr style="background-color:#28AE7B;width:20%;height:2px;text-align: center;margin-top: -10px;">

          <div id="carouselExampleControls11" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">

    <div class="row" style="padding:15px;">
        <div class="col-lg-6 col-md-6 col-xs-12">
        <div class="card" style='width:100%;margin-top:5px;'>
                                      <div class="card-body" >
                                         <p style='font-size: 18px;'>App Store Optimization (ASO) The Ultimate ASO Guide 2020 <br>
                                              <br> Aug 21, 2020
                                          </p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet. The best part, you ask? I'm going ...
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>

                                          <img src='images/ultimage-guide-app-store.jpg' style='width:100%;height:100px;margin-top:20px ;'>

                                      </div>
                                  </div>
        </div>
        <div class="col-lg-6 col-md-6 col-xs-12">
        <div class="card" style='width:100%;margin-top:5px;'>
                                      <div class="card-body">
                                          <img src='images/seo-tools-20201.jpg' style='width:100%;height:100px;'>

                                          <p style='font-size: 18px;margin-top: 20px;'>App Store Optimization (ASO) The Ultimate ASO Guide 2020 <br><br> Aug 21, 2020</p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet. The best part, you ask? I'm going ...
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>


                                      </div>
                                  </div>
        </div>
    </div>

    </div>
    <div class="carousel-item">
    <div class="row" style="padding:15px;">
        <div class="col-lg-6 col-md-6 col-xs-12">
        <div class="card" style='width:100%'>
                                      <div class="card-body" >
                                         <p style='font-size: 18px;'>App Store Optimization (ASO) The Ultimate ASO Guide 2020 <br>
                                              <br> Aug 21, 2020
                                          </p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet. The best part, you ask? I'm going ...
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>

                                          <img src='images/ultimage-guide-app-store.jpg' style='width:100%;height:100px;margin-top:20px ;'>

                                      </div>
                                  </div>
        </div>
        <div class="col-lg-6 col-md-6 col-xs-12">
        <div class="card" style='width:100%'>
                                      <div class="card-body">
                                          <img src='images/seo-tools-20201.jpg' style='width:100%;height:100px;'>

                                          <p style='font-size: 18px;margin-top: 20px;'>App Store Optimization (ASO) The Ultimate ASO Guide 2020 <br><br> Aug 21, 2020</p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet. The best part, you ask? I'm going ...
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>


                                      </div>
                                  </div>
        </div>
    </div>
    </div>

  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls11" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls11" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

      </div>
      <div class="col-lg-4">
        <p style="font-size: 30px;color:#075196;text-align: center;"><b>Latest News</b></p>
        <hr style="background-color:#28AE7B;width:20%;height:2px;text-align: center;margin-top: -10px;">

          <br>

              <div  class="item">
                  <div   style='background-color: white;'>

                  <marquee width="100%" direction="up" height="auto">

                  <p style='padding: 20px 20px 17px;border-radius:10px;background-color: #075196;color:white;font-weight: 600;font-size: 14px;'>
                    cdgbhg jdsbn sdn bsd cbnsd bnsd csd chjsd bc sdbsd.
                    <br><br>
                    <span>15 Jan, 2022</span>
                    </p>

                    <p style='padding: 20px 20px 17px;border-radius:10px;background-color: #075196;color:white;font-weight: 600;font-size: 14px;'>
                    cdgbhg jdsbn sdn bsd cbnsd bnsd csd chjsd bc sdbsd.
                    <br><br>
                    <span>15 Jan, 2022</span>
                    </p>

                    <p style='padding: 20px 20px 17px;border-radius:10px;background-color: #075196;color:white;font-weight: 600;font-size: 14px;'>
                    cdgbhg jdsbn sdn bsd cbnsd bnsd csd chjsd bc sdbsd.
                    <br><br>
                    <span>15 Jan, 2022</span>
                    </p>
</marquee>

                  </div>

              </div>



      </div>
  </div>
</div>
</div>


  <div style="width:100%;height:100px;background: linear-gradient(
-2deg, #28AE7B 0%, #28AE7B 36%, #d6d6c2 37%);"></div>
<div class='container-fluid' style='background-color: #28AE7B;'>
  <div class='container' >
      <div class='row' >
          <div class='col-lg-12'>
            <br>
            <p style="font-size: 30px;color:white;text-align: center;"><b>Faq's</b></p>

          </div>
          <div>

          </div>
      </div>

      <div class='row' >
          <div class='col-lg-12'>


              <section>
                  <p style='color:white'><i class="fa fa-ravelry" aria-hidden="true"></i> Agile Methodology</p> <button type="button" class="pull-right btn btn-outline-primary" style="margin-top: -40px;color:white;border-color:white;" data-toggle="collapse" data-target="#demo"><i class="fa fa-plus" ></i></button>
                  <section id="demo" class="collapse">

                      <p style="margin-top: 10px;color:white">We provide Agile methodology,it seeks alternatives to traditional project management & help teams respond to unpredictability through incremental, iterative work cadences and empirical feedbacks.</p>

                  </section>
                  <hr style="background-color: white;">
              </section>
              <br>



              <section>
                  <p style='color:white'><i class="fa fa-life-ring" aria-hidden="true"></i> End To End Solution</p> <button type="button" class="pull-right btn btn-outline-primary" style="margin-top: -40px;color:white;border-color:white;" data-toggle="collapse" data-target="#demo1"><i class="fa fa-plus" ></i></button>
                  <section id="demo1" class="collapse">

                      <p style="margin-top: 10px;color:#fff">We provide end to end solution to our customers, it means that the supplier of an application program or system will provide all the hardware and/or software components and resources to meet the customer's requirement.</p>

                  </section>
                  <hr style="background-color: white;">
              </section>
              <br>


              <section>
                  <p style='color:white'><i class="fa fa-laptop" aria-hidden="true"></i> Quality Code</p> <button type="button" class="pull-right btn btn-outline-primary" style="margin-top: -40px;color:white;border-color:white;" data-toggle="collapse" data-target="#demo2"><i class="fa fa-plus" ></i></button>
                  <section id="demo2" class="collapse">

                      <p style="margin-top: 10px;color:#fff">We provide bug-free code to our clients. Our quality products consist of the features highly adhering to the needs of customers.</p>

                  </section>
                  <hr style="background-color: white;">
              </section>
              <br>


              <section>
                  <p style='color:white'><i class="fa fa-language" aria-hidden="true"></i> Onsite Support</p> <button type="button" class="pull-right btn btn-outline-primary" style="margin-top: -40px;color:white;border-color:white;" data-toggle="collapse" data-target="#demo3"><i class="fa fa-plus" ></i></button>
                  <section id="demo3" class="collapse">

                      <p style="margin-top: 10px;color:#fff">We provide onsite support services.The User Support and Engagement On-Site Support group is committed to providing professional, informed, courteous, customer-focused IT services.</p>

                  </section>
                  <hr style="background-color: white;">
              </section>


          </div>
          <div>

          </div>
      </div>
  </div>
</div>
<div style="width:100%;height:100px;background: linear-gradient(-4deg, white 50%,transparent 50%, #28AE7B 51%)"></div>


<style>
  .parallax {
      /* The image used */
      background-image: url("images/get in touch.jpg");
      min-height: auto;
      background-attachment: fixed;
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
  }
</style>

<br>
<img src="imgnew/cc.jpg" class="img-fluid" width="100%" style="margin-bottom:10px;height:200px;">



@endsection
