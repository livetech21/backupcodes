@extends('front/layout')
@section('page_title','Livetech-Index')

@section('container')

<style>

@media all and (min-width: 480px) {

.card{
   max-height: 400px;
}

}

@media all and (max-width: 479px) {

.card{
   max-height: 450px;
}

}

    </style>



<div class="deskContent">
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">

  <div class="carousel-inner">
    <div class="carousel-item active div-img">
      <img class="d-block w-100" src="img/banner/Web/banner2.png" style="animation: slideIn 1.5s ease-in-out forwards;" alt="livetech">
    </div>
    <div class="carousel-item div-img">
      <img class="d-block w-100" src="img/banner/SEO/banner2.png" style="animation: slideIn 1.5s ease-in-out forwards;" alt="livetech">
    </div>
    <div class="carousel-item div-img">
      <img class="d-block w-100" src="img/banner/CRM/banner2.png" style="animation: slideIn 1.5s ease-in-out forwards;" alt="livetech">
    </div>
    <div class="carousel-item div-img">
      <img class="d-block w-100" src="img/banner/ERP/banner2.png" style="animation: slideIn 1.5s ease-in-out forwards;" alt="livetech">
    </div>
    <div class="carousel-item div-img">
      <img class="d-block w-100" src="img/banner/E com/banner2.png" style="animation: slideIn 1.5s ease-in-out forwards;" alt="livetech">
    </div>
    <div class="carousel-item div-img">
      <img class="d-block w-100" src="img/banner/Graphic/banner2.png" style="animation: slideIn 1.5s ease-in-out forwards;" alt="livetech">
    </div>
  </div>

</div>
<span>
<div style="text-align:center;margin-top:5px;">
<i data-target="#carouselExampleIndicators" data-slide-to="0" class="active" class="fa fa-circle spin circle" style="padding:5px;color:#191970;"></i>
<i data-target="#carouselExampleIndicators" data-slide-to="1" class="fa fa-circle spin circle" style="padding:5px;color:#191970;"></i>
<i data-target="#carouselExampleIndicators" data-slide-to="2" class="fa fa-circle spin circle" style="padding:5px;color:#191970;"></i>
<i data-target="#carouselExampleIndicators" data-slide-to="3" class="fa fa-circle spin circle" style="padding:5px;color:#191970;"></i>
<i data-target="#carouselExampleIndicators" data-slide-to="4" class="fa fa-circle spin circle" style="padding:5px;color:#191970;"></i>
<i data-target="#carouselExampleIndicators" data-slide-to="5" class="fa fa-circle spin circle" style="padding:5px;color:#191970;"></i>
<i data-target="#carouselExampleIndicators" data-slide-to="6" class="fa fa-circle spin circle" style="padding:5px;color:#191970;"></i>
</div>
</span>
</div>

<div class="phoneContent">
<div id="carouselExampleIndicators1" class="carousel slide" data-ride="carousel">

<div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="img/banner/Web/mbbanner2.png" style="animation: slideIn 1.5s ease-in-out forwards;" alt="livetech">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="img/banner/SEO/mbbanner2.png" style="animation: slideIn 1.5s ease-in-out forwards;" alt="livetech">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="img/banner/CRM/mbbanner2.png" style="animation: slideIn 1.5s ease-in-out forwards;" alt="livetech">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="img/banner/ERP/mbbanner2.png" style="animation: slideIn 1.5s ease-in-out forwards;" alt="livetech">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="img/banner/E com/mbbanner2.png" style="animation: slideIn 1.5s ease-in-out forwards;" alt="livetech">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="img/banner/Graphic/mbbanner2.png" style="animation: slideIn 1.5s ease-in-out forwards;" alt="livetech">
    </div>
  </div>

</div>
<span>
<div style="text-align:center;margin-top:5px;">
<i data-target="#carouselExampleIndicators1" data-slide-to="0" class="active" class="fa fa-circle spin circle" style="padding:5px;color:#191970;"></i>
<i data-target="#carouselExampleIndicators1" data-slide-to="1" class="fa fa-circle spin circle" style="padding:5px;color:#191970;"></i>
<i data-target="#carouselExampleIndicators1" data-slide-to="2" class="fa fa-circle spin circle" style="padding:5px;color:#191970;"></i>
<i data-target="#carouselExampleIndicators1" data-slide-to="3" class="fa fa-circle spin circle" style="padding:5px;color:#191970;"></i>
<i data-target="#carouselExampleIndicators1" data-slide-to="4" class="fa fa-circle spin circle" style="padding:5px;color:#191970;"></i>
<i data-target="#carouselExampleIndicators1" data-slide-to="5" class="fa fa-circle spin circle" style="padding:5px;color:#191970;"></i>
<i data-target="#carouselExampleIndicators1" data-slide-to="6" class="fa fa-circle spin circle" style="padding:5px;color:#191970;"></i>
</div>
</span>
</div>



<style>


  .card {
      box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
      transition: 0.3s;
      background-color:transparent;
  }

  /* .card:hover {
      box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
      border:2px solid #2b6db4;
  } */

  .card:hover {
      box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
      border-left:2px solid #2b6db4;
      border-right:2px solid #067751;
      transition: all 0.3s ease;
  }

  /* .kk{
    border:2px solid #2b6db4;
  }
    .kk:hover{
    border:3px solid #067751;
  } */

.thumb {
  width: 100%;
  height: 300px;
  margin: 10px auto;
  perspective: 1000px;
}

.thumb a {
  display: block;
  width: 100%;
  height: 100%;
  background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)),
  url("imgnew/test.jpg");
  background-size: 0, cover;
  transform-style: preserve-3d;
  transition: all 0.5s;
}

.thumb:hover a {
  transform: rotateX(80deg);
  transform-origin: bottom;
}
.thumb a:after {
  content: '';
  position: absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 36px;
  background: inherit;
  background-size: cover, cover;
  background-position: bottom;
  transform: rotateX(90deg);
  transform-origin: bottom;
}
.thumb a span {
  color: white;
  text-transform: uppercase;
  position: absolute;
  top: 100%;
  left: 0;
  width: 100%;
  text-align: center;
  transform: rotateX(-89.99deg);
  transform-origin: top;
  z-index: 1;
}
.thumb a:before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  box-shadow: 0 0 100px 50px rgba(0, 0, 0, 0.5);
  transition: all 0.5s;
  opacity: 0.15;
  transform: rotateX(95deg) translateZ(-80px) scale(0.75);
  transform-origin: bottom;
}

.thumb:hover a:before {
  opacity: 1;
  box-shadow: 0 0 25px 25px rgba(0, 0, 0, 0.5);
  transform: rotateX(0) translateZ(-60px) scale(0.85);
}

</style>


<div class='col-lg-12'>
          <br>
            <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b style="color:#2fc5b9;">Build and Deploy with </b><b>Excellent Services</b></p>
            <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

        </div>

<div style="background-image: url('img/bgg7.png');">
  <div class='container' >
    <div class='row'>


    <div class="container" >
      <div class="row" >

          <div class='col-lg-6 col-xs-12' style="margin-top: 20px;">
              <div class='card ch kk'>
                  <div class='card-body' style='padding:2px;padding-bottom: 15px;padding-top: 10px;padding-left: 10px;'>
                      <div class='row'>
                          <div class=" col-lg-4 col-sm-4 col-xs-12">
                            <img src='img/icons/web.png' class="img-flip" style="height:200px;width:200px;margin-left: auto;margin-right: auto;display: block;">


                          </div>
                          <div class="col-md-8 col-sm-8 col-xs-12" style="background-image: url('img/bgg4.png');  background-repeat: no-repeat;
  background-size: auto;">

                           <a href="{{ url('page/WEB')}}"> <h5 text-alignment="center" class="slidepp" style='font-size: 19px;font-weight: 500;margin-top: 5px;text-align: center;color:#2b6db4;'>Website Design</h5></a>
                              <p align="justify" style='padding:5px;color:#2b6db4;letter-spacing:1px;'>We are expert in designing and developing responsive websites and portals. It enables customers access website from any device.</p>
                              <a href="{{ url('page/WEB')}}" class="btn btn-primary">Read more...</a>
                          </div>






                      </div>


                  </div>
              </div>
          </div>


          <div class='col-lg-6 col-xs-12' style="margin-top: 20px;">
              <div class='card ch kk' >
                  <div class='card-body' style='padding:2px;padding-bottom: 15px;padding-top: 10px;padding-left: 10px;'>
                      <div class='row'>
                          <div class=" col-lg-4 col-sm-4 col-xs-12">
                              <img src='img/icons/digital.png' class="img-flip" style="height:200px;width:200px;margin-left: auto;margin-right: auto;display: block;">


                          </div>
                          <div class="col-md-8 col-sm-8 col-xs-12" style="background-image: url('img/bgg4.png');  background-repeat: no-repeat;
  background-size: auto;">

                            <a href="{{ url('page2/Digital')}}"> <h5 class="slidepp" style='font-size: 19px;font-weight: 500;margin-top: 5px;text-align: center;color:#2b6db4;'>Digital Marketing</h5></a>
                            <p align="justify" style='padding:5px;color:#2b6db4;letter-spacing:1px;'>We provide digital marketing services to our client to greatly help them promote their products and services.</p>
                            <a href="{{ url('page2/Digital')}}" class="btn btn-primary">Read more...</a>
                          </div>






                      </div>


                  </div>
              </div>
          </div>
      </div>
      <div class="row">

        <div class='col-lg-6 col-xs-12' style="margin-top: 20px;">
            <div class='card ch kk' >
                <div class='card-body' style='padding:2px;padding-bottom: 15px;padding-top: 10px;padding-left: 10px;'>
                    <div class='row'>
                        <div class=" col-lg-4 col-sm-4 col-xs-12">
                          <img src='img/icons/erp.png' class="img-flip" style="height:200px;width:200px;margin-left: auto;margin-right: auto;display: block;">


                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-12" style="background-image: url('img/bgg4.png');  background-repeat: no-repeat;
  background-size: auto;">

                          <a href="{{ url('page3/ERP')}}">  <h5 class="slidepp" style='font-size: 19px;font-weight: 500;margin-top: 5px;text-align: center;color:#2b6db4;'>ERP</h5></a>
                          <p align="justify" style='padding:5px;color:#2b6db4;letter-spacing:1px;'>We offer ERP development and maintenence services across varied industries and services.</p>
                          <a href="{{ url('page3/ERP')}}" class="btn btn-primary">Read more...</a>
                        </div>






                    </div>


                </div>
            </div>
        </div>


        <div class='col-lg-6 col-xs-12' style="margin-top: 20px;">
            <div class='card ch kk' >
                <div class='card-body' style='padding:2px;padding-bottom: 15px;padding-top: 10px;padding-left: 10px;'>
                    <div class='row'>
                        <div class=" col-lg-4 col-sm-4 col-xs-12">
                          <img src='img/icons/e-comm.png' class="img-flip" style="height:200px;width:200px;margin-left: auto;margin-right: auto;display: block;">


                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-12" style="background-image: url('img/bgg4.png');  background-repeat: no-repeat;
  background-size: auto;">

                          <a href="{{ url('page5/E-commerce')}}">  <h5 class="slidepp" style='font-size: 19px;font-weight: 500;margin-top: 5px;text-align: center;color:#2b6db4;'>E-commerce Solutions</h5></a>
                          <p align="justify" style='padding:5px;color:#2b6db4;letter-spacing:1px;'>We offer E-commerce Solutions and maintenence services across varied industries and services.</p>
                          <a href="{{ url('page5/E-commerce')}}" class="btn btn-primary">Read more...</a>
                        </div>






                    </div>


                </div>
            </div>
        </div>
    </div>
    <div class="row">

      <div class='col-lg-6 col-xs-12' style="margin-top: 20px;">
          <div class='card ch kk'>
              <div class='card-body' style='padding:2px;padding-bottom: 15px;padding-top: 10px;padding-left: 10px;'>
                  <div class='row'>
                      <div class=" col-lg-4 col-sm-4 col-xs-12">
                        <img src='img/icons/crm.png' class="img-flip" style="height:150px;width:200px;margin-left: auto;margin-right: auto;display: block;margin-top:20px;">


                      </div>
                      <div class="col-md-8 col-sm-8 col-xs-12" style="background-image: url('img/bgg4.png');  background-repeat: no-repeat;
  background-size: auto;">

                        <a href="{{ url('page4/CRM')}}"> <h5 class="slidepp" style='font-size: 19px;font-weight: 500;margin-top: 5px;text-align: center;color:#2b6db4;'>CRM</h5></a>
                        <p align="justify" style='padding:5px;color:#2b6db4;letter-spacing:1px;'>We offer attractive CRM Development, Responsive store design & development, eCommerce Mobile Apps development, Plugins & Module development and Product Support services.</p>
                        <a href="{{ url('page4/CRM')}}" class="btn btn-primary">Read more...</a>
                      </div>






                  </div>


              </div>
          </div>
      </div>


      <div class='col-lg-6 col-xs-12' style="margin-top: 20px;">
          <div class='card ch kk'>
              <div class='card-body' style='padding:2px;padding-bottom: 15px;padding-top: 10px;padding-left: 10px;'>
                  <div class='row'>
                      <div class=" col-lg-4 col-sm-4 col-xs-12">
                        <img src='img/icons/graphic.png' class="img-flip" style="height:150px;width:200px;margin-left: auto;margin-right: auto;display: block;margin-top:20px;">


                      </div>
                      <div class="col-md-8 col-sm-8 col-xs-12" style="background-image: url('img/bgg4.png');  background-repeat: no-repeat;
  background-size: auto;">

                        <a href="{{ url('page6/Graphic')}}"> <h5 class="slidepp" style='font-size: 19px;font-weight: 500;margin-top: 5px;text-align: center;color:#2b6db4;'>Graphics Designing</h5></a>
                        <p align="justify" style='padding:5px;color:#2b6db4;letter-spacing:1px;'>We develop various types of logo's of Websites which best meet business objectives of our clients and create long-term value for their business. </p>
<a href="{{ url('page6/Graphic')}}" class="btn btn-primary">Read more...</a>
                      </div>






                  </div>


              </div>
          </div>
      </div>
  </div>
  <br>
  </div>

  </div>
  </div>
  <br>
  </div>


  <div class='col-lg-12'>
  <br>
    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b style="color:#2fc5b9;">Why Do You Choose </b><b> LiveTech Services</b></p>
    <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

</div>
<div style="  background: linear-gradient(to right, transparent, #2b6db4),
      url('img/bgg3.png');">
<br/>
<div class="container" style="margin-bottom:20px;">
<div class="col-lg-12 ">
<div class="row ">
    <div class="col-xl-3 col-lg-6" style="padding:5px;">
        <div class="card l-bg-cherry">
            <div class="card-statistic-3 p-4">
                <div class="card-icon card-icon-large"><i class="fa fa-user" style="margin-right:50px;font-size:200px;"></i></div>
                <div class="mb-4">
                    <h5 class="card-title mb-0">Agile Methodology</h5>
                </div>
                <div class="row align-items-center mb-2 d-flex">
                    <div class="col-8">
                        <h2 class="d-flex align-items-center mb-0">
                            99 %
                        </h2>
                    </div>
                    <div class="col-4 text-right">
                        <span> <i class="fa fa-arrow-up" ></i></span>
                    </div>
                </div>
                <div class="progress mt-1 " data-height="8" style="height: 8px;">
                    <div class="progress-bar l-bg-cyan" role="progressbar" data-width="25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style="width: 95%;"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6" style="padding:5px;">
        <div class="card l-bg-cherry">
            <div class="card-statistic-3 p-4">
                <div class="card-icon card-icon-large"><i class="fa fa-users" style="margin-right:50px;font-size:200px;"></i></div>
                <div class="mb-4">
                    <h5 class="card-title mb-0">End To End Solution</h5>
                </div>
                <div class="row align-items-center mb-2 d-flex">
                    <div class="col-8">
                        <h2 class="d-flex align-items-center mb-0">
                            99 %
                        </h2>
                    </div>
                    <div class="col-4 text-right">
                        <span> <i class="fa fa-arrow-up"></i></span>
                    </div>
                </div>
                <div class="progress mt-1 " data-height="8" style="height: 8px;">
                    <div class="progress-bar l-bg-green" role="progressbar" data-width="25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style="width: 95%;"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6" style="padding:5px;">
        <div class="card l-bg-cherry">
            <div class="card-statistic-3 p-4">
                <div class="card-icon card-icon-large"><i class="fa fa-globe" style="margin-right:50px;font-size:200px;"></i></div>
                <div class="mb-4">
                    <h5 class="card-title mb-0">Quality Code</h5>
                </div>
                <div class="row align-items-center mb-2 d-flex">
                    <div class="col-8">
                        <h2 class="d-flex align-items-center mb-0">
                            100 %
                        </h2>
                    </div>
                    <div class="col-4 text-right">
                        <span> <i class="fa fa-arrow-up"></i></span>
                    </div>
                </div>
                <div class="progress mt-1 " data-height="8" style="height: 8px;">
                    <div class="progress-bar l-bg-orange" role="progressbar" data-width="25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style="width: 100%;"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6" style="padding:5px;">
        <div class="card l-bg-cherry">
            <div class="card-statistic-3 p-4">
                <div class="card-icon card-icon-large"><i class="fa fa-bullhorn" style="margin-right:50px;font-size:200px;"></i></div>
                <div class="mb-4">
                    <h5 class="card-title mb-0">Onsite Support</h5>
                </div>
                <div class="row align-items-center mb-2 d-flex">
                    <div class="col-8">
                        <h2 class="d-flex align-items-center mb-0">
                           100 %
                        </h2>
                    </div>
                    <div class="col-4 text-right">
                        <span> <i class="fa fa-arrow-up"></i></span>
                    </div>
                </div>
                <div class="progress mt-1 " data-height="8" style="height: 8px;">
                    <div class="progress-bar l-bg-cyan" role="progressbar" data-width="50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 100%;"></div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<br/>
</div>
</div>



<div >
<div class='col-lg-12'>
  <br>
    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b style="color:#2fc5b9;">About </b><b> Us</b></p>
    <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

</div>

<div class='container' style='margin-bottom:10px;'>
  <div class='row'>

<div class="col-lg-6">
  <!-- <img src="assets/imgnew/test.jpg" class="img-fluid" style="border-radius:50%;margin-top:10px;height:350px;width:100%;"> -->

  <img src="{{ asset('img/photo.png') }}" class="img-fluid slidepp" alt="livetech"/>

</div>
<div class="col-lg-6" style="background-image: url('img/bgg8.png');background-repeat:no-repeat;">
<!--
<div class="list-group" style="margin-top:10px;">
  <a href="#" class="list-group-item list-group-item-action d-flex" aria-current="true">
    <div class="d-flex gap-2 w-100 justify-content-between">
      <div style="padding:5px;">
        <h5 class="mb-0 txt" style="color:#2b6db4;text-align:center;">Manufacturing Domain<i class="fa fa-long-arrow-right float-right" style="font-weight:100px;"></i></h5>
        <p align="justify" class="mb-0 opacity-75">We provide the different type of ERP and softwares such as School Management Software, Account Management Software and Inventory Management Software.</p>
      </div>
    </div>
  </a>
  <a href="#" class="list-group-item list-group-item-action d-flex" aria-current="true">

    <div class="d-flex gap-2 w-100 justify-content-between">
      <div style="padding:5px;">
        <h5 class="mb-0 txt" style="color:#2b6db4;text-align:center;">Retail Supply Chain<i class="fa fa-long-arrow-right float-right" style="font-weight:100px;"></i></h5>
        <p align="justify" class="mb-0 opacity-75">Our Expert team of Retail & Supply Chain Management deliver highly reliable and robust products.</p>
      </div>
    </div>
  </a>
  <a href="#" class="list-group-item list-group-item-action d-flex" aria-current="true">

    <div class="d-flex gap-2 w-100 justify-content-between">
      <div style="padding:5px;">
        <h5 class="mb-0 txt" style="color:#2b6db4;text-align:center;">Finance Domain<i class="fa fa-long-arrow-right float-right" style="font-weight:100px;"></i></h5>
        <p align="justify" class="mb-0 opacity-75">We bring highly learned financial domain experts for robust, secure and dependable financial solutions.</p>
      </div>
    </div>
  </a> -->

  <p align="justify" style="margin-top:10px;color:#067751;font-weight:500;padding:10px;">LTS is one of the fastest growing software development companies in Delhi NCR that provides one-stop-web-solution to every organization and individual. We have a vivid presence in the Indian as well as the International market for our top-notch software development services, Being a customer oriented company, we pay special attention to offer our clients an insight driven intuitive service to ensure the best outcome at the most affordable budget.understand the requirement of our customers, thus we have hired the professionals who can think like a customer and deliver the solutions exactly. Our products are totally trend defining that rely on the basis of market's needs. We cover almost all verticals of software solutions from the web to latest android and ios application. We are trying to make customer’s life easy and comfortable through technology because we are making something different for them.</p>
<button type="button" class="btn btn-success" style="background-color:cadetblue;" data-toggle="modal" data-target="#exampleModalCenter">
  Quick call <i class="fa fa-bullhorn"></i>
</button>


</div>


</div>

  </div>

</div>
</div>


  <style>
      .cards {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 2rem;
        margin: 4rem 5vw;
        padding: 0;
        list-style-type: none;
      }

      .card {
        position: relative;
        display: block;
        height: 100%;
        border-radius: calc(var(--curve) * 1px);
        overflow: hidden;
        text-decoration: none;
      }

      .card__image {
        width: 100%;
        height: auto;
      }

      .card__overlay {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        z-index: 1;
        border-radius: calc(var(--curve) * 1px);
        background-color: var(--surface-color);
        transform: translateY(100%);
        transition: .2s ease-in-out;
      }

      .card:hover .card__overlay {
        transform: translateY(0);
      }

      .card__header {
        position: relative;
        display: flex;
        align-items: center;
        gap: 2em;
        padding: 2em;
        border-radius: calc(var(--curve) * 1px) 0 0 0;
        background-color: cadetblue;
        transform: translateY(-100%);
        transition: .2s ease-in-out;
      }

      .card__arc {
        width: 80px;
        height: 80px;
        position: absolute;
        bottom: 100%;
        right: 0;
        z-index: 1;
      }

      .card__arc path {
        fill: cadetblue;
        d: path("M 40 80 c 22 0 40 -22 40 -40 v 40 Z");
      }

      .card:hover .card__header {
        transform: translateY(0);
      }

      .card__thumb {
        flex-shrink: 0;
        width: 50px;
        height: 50px;
        border-radius: 50%;
      }

      .card__title {
        font-size: 1em;
        margin: 0 0 .3em;
        color: #6A515E;
      }

      .card__tagline {
        display: block;
        margin: 1em 0;

        font-size: .8em;
        color: #D7BDCA;
      }

      .card__status {
        font-size: .8em;
        color: #D7BDCA;
      }

      .card__description {
        padding: 0 2em 2em;
        margin: 0;
        color: white;

        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 3;
        overflow: hidden;
        background-color: #0068a1;
      }

  </style>


  <style>
    .card {
        background-color: #fff;
        border-radius: 10px;
        border: none;
        position: relative;
        margin-bottom: 5px;
        box-shadow: 0 0.46875rem 2.1875rem rgba(90,97,105,0.1), 0 0.9375rem 1.40625rem rgba(90,97,105,0.1), 0 0.25rem 0.53125rem rgba(90,97,105,0.12), 0 0.125rem 0.1875rem rgba(90,97,105,0.1);
    }
    .l-bg-cherry {
        background: linear-gradient(to right, #2b6db4, rgba(29, 192, 170, 0.623)) !important;
        color: #fff;
    }

    .l-bg-blue-dark {
        background: linear-gradient(to right, #373b44, rgba(29, 192, 170, 0.623)) !important;
        color: #fff;
    }

    .l-bg-green-dark {
        background: linear-gradient(to right, #0a504a, #38ef7d) !important;
        color: #fff;
    }

    .l-bg-orange-dark {
        background: linear-gradient(to right, #a86008, #ffba56) !important;
        color: #fff;
    }

    .card .card-statistic-3 .card-icon-large .fas, .card .card-statistic-3 .card-icon-large .far, .card .card-statistic-3 .card-icon-large .fab, .card .card-statistic-3 .card-icon-large .fal {
        font-size: 110px;
    }

    .card .card-statistic-3 .card-icon {
        text-align: center;
        line-height: 50px;
        margin-left: 15px;
        color: #000;
        position: absolute;
        right: -5px;
        top: 20px;
        opacity: 0.1;
    }

    .l-bg-cyan {
        background: linear-gradient(135deg, #289cf5, #84c0ec) !important;
        color: #fff;
    }

    .l-bg-green {
        background: linear-gradient(135deg, #23bdb8 0%, #43e794 100%) !important;
        color: #fff;
    }

    .l-bg-orange {
        background: linear-gradient(to right, #f9900e, #ffba56) !important;
        color: #fff;
    }

    .l-bg-cyan {
        background: linear-gradient(135deg, #289cf5, #84c0ec) !important;
        color: #fff;
    }
    </style>


<style>
    /* Rounded tabs */

@media (min-width: 576px) {
    .rounded-nav {
      border-radius: 50rem !important;
    }
  }

  @media (min-width: 576px) {
    .rounded-nav .nav-link {
      border-radius: 50rem !important;
    }
  }

  /* With arrow tabs */

  .with-arrow .nav-link.active {
    position: relative;
  }

  .with-arrow .nav-link.active::after {
    content: '';
    border-left: 6px solid transparent;
    border-right: 6px solid transparent;
    border-top: 6px solid #2b90d9;
    position: absolute;
    bottom: -6px;
    left: 50%;
    transform: translateX(-50%);
    display: block;
  }

  /* lined tabs */

  .lined .nav-link {
    border: none;
    border-bottom: 3px solid transparent;
  }

  .lined .nav-link:hover {
    border: none;
    border-bottom: 3px solid transparent;
  }

  .lined .nav-link.active {
    background: none;
    color: #555;
    border-color: #2fc5b9;
  }

  /*
  *
  * ==========================================
  * FOR DEMO PURPOSE
  * ==========================================
  *
  */


  .nav-pills .nav-link {
    color: #555;
  }
  .text-uppercase {
    letter-spacing: 0.1em;
  }

  .striped {
   background: linear-gradient(to bottom left, #2fc5b9 50%, #2b6db4 50%);
}
</style>


<div class='col-lg-12'>
  <br>
    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b style="color:#2fc5b9;">Our Servicing </b><b> Domains</b></p>
    <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

</div>
<div class="striped">
<br/><br/>
  <div class="container">

    <div class="p-5 bg-white rounded shadow mb-5">
      <!-- Lined tabs-->
      <ul id="myTab2" role="tablist" class="nav nav-tabs nav-pills with-arrow lined flex-sm-row text-center">
        <li class="nav-item flex-sm-fill">
          <a id="home2-tab" data-toggle="tab" href="#home2" role="tab" aria-controls="home2" aria-selected="true" class="nav-link text-uppercase font-weight-bold mr-sm-3 rounded-0 active"><b style="color:#0068a1;font-weight:500;">Health</b></a>
        </li>
        <li class="nav-item flex-sm-fill">
          <a id="profile2-tab" data-toggle="tab" href="#profile2" role="tab" aria-controls="profile2" aria-selected="false" class="nav-link text-uppercase font-weight-bold mr-sm-3 rounded-0"><b style="color:#0068a1;font-weight:500;">Real Estate</b></a>
        </li>
        <li class="nav-item flex-sm-fill">
          <a id="contact2-tab" data-toggle="tab" href="#contact2" role="tab" aria-controls="contact2" aria-selected="false" class="nav-link text-uppercase font-weight-bold rounded-0"><b style="color:#0068a1;font-weight:500;">Media</b></a>
        </li>

        <li class="nav-item flex-sm-fill">
          <a id="profile2-tab" data-toggle="tab" href="#profile12" role="tab" aria-controls="profile2" aria-selected="false" class="nav-link text-uppercase font-weight-bold mr-sm-3 rounded-0"><b style="color:#0068a1;font-weight:500;">NGO's</b></a>
        </li>
        <li class="nav-item flex-sm-fill">
          <a id="contact2-tab" data-toggle="tab" href="#contact12" role="tab" aria-controls="contact2" aria-selected="false" class="nav-link text-uppercase font-weight-bold rounded-0"><b style="color:#0068a1;font-weight:500;">Hotel</b></a>
        </li>
        <li class="nav-item flex-sm-fill">
          <a id="profile2-tab" data-toggle="tab" href="#profile22" role="tab" aria-controls="profile2" aria-selected="false" class="nav-link text-uppercase font-weight-bold mr-sm-3 rounded-0"><b style="color:#0068a1;font-weight:500;">Booking</b></a>
        </li>
        <li class="nav-item flex-sm-fill">
          <a id="contact2-tab" data-toggle="tab" href="#contact22" role="tab" aria-controls="contact2" aria-selected="false" class="nav-link text-uppercase font-weight-bold rounded-0"><b style="color:#0068a1;font-weight:500;" >Education</b></a>
        </li>
        <li class="nav-item flex-sm-fill">
          <a id="profile2-tab" data-toggle="tab" href="#profile32" role="tab" aria-controls="profile2" aria-selected="false" class="nav-link text-uppercase font-weight-bold mr-sm-3 rounded-0"><b style="color:#0068a1;font-weight:500;" >Labs</b></a>
        </li>
      </ul>
      <div id="myTab2Content" class="tab-content">

        <div id="home2" role="tabpanel" aria-labelledby="home-tab" class="tab-pane fade px-4 py-5 show active" style="background-image: url('imgnew/bg5.jpg');background-repeat: no-repeat;width:100%;">
          <p class="leade " align="justify">We are expert in designing and developing responsive websites and portals. It enables customers access website from any device.</p>
        </div>
        <div id="profile2" role="tabpanel" aria-labelledby="profile-tab" class="tab-pane fade px-4 py-5" style="background-image: url('imgnew/bg6.jpg');background-repeat: no-repeat;width:100%;">
          <p class="leade">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
            irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
        <div id="contact2" role="tabpanel" aria-labelledby="contact-tab" class="tab-pane fade px-4 py-5" style="background-image: url('imgnew/bg4.jpg');background-repeat: no-repeat;width:100%;">
          <p class="leade" align="justify">We provide digital marketing services to our client to greatly help them promote their products and services.</p>
        </div>
        <div id="profile12" role="tabpanel" aria-labelledby="profile-tab" class="tab-pane fade px-4 py-5" style="background-image: url('imgnew/bg1.jpg');background-repeat: no-repeat;width:100%;">
          <p class="leade" align="justify">We offer attractive CRM Development, Responsive store design & development, eCommerce Mobile Apps development, Plugins & Module development and Product Support services.</p>
        </div>
        <div id="contact12" role="tabpanel" aria-labelledby="contact-tab" class="tab-pane fade px-4 py-5" style="background-image: url('imgnew/bg2.jpg');background-repeat: no-repeat;width:100%;">
          <p class="leade" align="justify">We offer clients mobile development services for android and ios platforms.</p>
        </div>
        <div id="profile22" role="tabpanel" aria-labelledby="profile-tab" class="tab-pane fade px-4 py-5" style="background-image: url('imgnew/bg4.jpg');">
          <p class="leade">We use the best-in-class technology to design and develop web portals.Our team of developers are very well versed in developing any kind of portals.</p>
        </div>
        <div id="contact22" role="tabpanel" aria-labelledby="contact-tab" class="tab-pane fade px-4 py-5" style="background-image: url('imgnew/bg3.jpg');">
          <p class="leade" align="justify">We offer ERP development and maintenence services across varied industries and services.</p>
        </div>
        <div id="profile32" role="tabpanel" aria-labelledby="profile-tab" class="tab-pane fade px-4 py-5" style="background-image: url('imgnew/bg2.jpg');">
          <p class="leade" align="justify">We are specialised in delivering Graphics Designing, Our team comprises of the experts who have strong experience of handling large chunks of data.</p>
        </div>
        <div id="contact32" role="tabpanel" aria-labelledby="contact-tab" class="tab-pane fade px-4 py-5"style="background-image: url('imgnew/bg1.jpg');">
          <p class="leade" align="justify">We develop softwares which best meet business objectives of our clients and create long-term value for their business. Our solutions help customers organize business cost effectively without compromising quality.</p>
        </div>

      </div>
      <!-- End lined tabs -->
    </div>
<br/>
  </div>
</div>


<div >
<div style="background-image: url('img/kpimg3.png');">
<div class="container">

  <p style="font-size: 30px;text-align: center;"><b style="color:#2fc5b9;">Get In </b><b style="color:#2b6db4;">Touch</b></p>

  <div class='row'>

      <div class="col-lg-6 col-xs-12">
      <div class="container">
        <img class="img-fluid ii"  src="{{ asset('img/bgg2.png') }}" alt="livetech"/>
        <br>
</div>

      </div>


      <div class="col-lg-6 col-xs-12 card" style="background-image: url('img/icons/case.png');
  background-size: auto;">
<style>
    input::placeholder {
  color: gray;
}
    input {
  border-radius: 50px;
  background-color: #ecf0f3;
  padding-left: 20px;
  box-shadow: inset 16px 16px 16px #cbced1, inset -6px -6px 6px white;
  display: block;
  padding: 0;
  border: none;
  outline: none;
  box-sizing: border-box;
}
textarea {
  border-radius: 50px;
  background-color: #ecf0f3;
  padding-left: 20px;
  box-shadow: inset 16px 16px 16px #cbced1, inset -6px -6px 6px white;
  display: block;
  padding: 0;
  border: none;
  outline: none;
  box-sizing: border-box;
}
    </style>

@if(session('message'))
 <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
             {{ session('message')}}

           </div>
            @endif
            <br/>
<form action="{{ url('contact_form') }}" method="post" role="form" class="info-box">
            	@csrf
              <div class="form-row">
              <i class="fa fa-user" style="color:#2fc5b9;margin-top:10px;"></i>
              <div class="col form-group">
                <input type="text" name="name" class="form-control" id="name" placeholder="Name" value="{{ old('name') }}"  />
                   @error('name')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
                <i class="fa fa-envelope" style="color:#2fc5b9;margin-top:10px;"></i>
                <div class="col form-group">
                <input type="email" class="form-control" name="email" id="email" placeholder="Email" value="{{ old('email') }}"  />
                @error('email')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
              </div>
              <div class="form-row">
              <i class="fa fa-phone" style="color:#2fc5b9;margin-top:10px;"></i>
              <div class="col form-group">
                <input type="number" name="phone" class="form-control" id="phone" placeholder="Phone"  value="{{ old('phone') }}"  />
                   @error('phone')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
                <i class="fa fa-edit" style="color:#2fc5b9;margin-top:10px;"></i>
                <div class="col form-group">
                  <input type="text" class="form-control" name="subject" id="subject" placeholder="subject" value="{{ old('subject') }}"  />
                @error('subject')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
              </div>
              <i class="fa fa-pencil" style="color:#2fc5b9;"></i>
              <div class="form-group">
              <textarea class="form-control" name="message" rows="5"   placeholder="Message" ></textarea>
                  @error('message')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
              </div>

<div style="marign-left:auto;margin-right:auto;text-align:center;">             <button type="submit" class="btn btn-outline-primary" style='border:2px solid #2b6db4;color:#2fc5b9;width:100px;height:40px;'>SUBMIT</button></div>
            </form>



          <br>
      </div>


  </div>
</div>
</div>
</div>


</div>

<style>
  .contact-form{
    background: #fff;
    margin-top: 10%;
    margin-bottom: 5%;
    width: 70%;
}
.contact-form .form-control{
    border-radius:1rem;
}
.contact-image{
    text-align: center;
}
.contact-image img{
    border-radius: 6rem;
    width: 11%;
    margin-top: -3%;
    transform: rotate(29deg);
}
.contact-form form{
    padding: 5%;
}
.contact-form form .row{
    margin-bottom: -7%;
}
.contact-form h3{
    margin-bottom: 8%;
    margin-top: -10%;
    text-align: center;
    color: #0062cc;
}
.contact-form .btnContact {
    width: 100%;
    border: none;
    border-radius: 1rem;
    padding: 1.5%;
    background: #0062cc;
    font-weight: 600;
    color: #fff;
    cursor: pointer;
}
.btnContactSubmit
{
    width: 50%;
    border-radius: 1rem;
    padding: 1.5%;
    color: #fff;
    background-color: #0062cc;
    border: none;
    cursor: pointer;
}
</style>

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" style="color:#067751;">Quick call <i class="fa fa-bullhorn"></i></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="background-image: url('imgnew/bg6.jpg');">
        <div class="container contact-form">
          <div class="contact-image">
              <img src="https://image.ibb.co/kUagtU/rocket_contact.png" alt="rocket_contact"/>
          </div>
          <form method="post">
              <h3>Drop Us a Message</h3>
             <div class="row">
                  <div class="col-lg-12">
                      <div class="form-group">
                          <input type="text" name="txtName" class="form-control" placeholder="Your Name *" value="" />
                      </div>
                      <div class="form-group">
                          <input type="text" name="txtEmail" class="form-control" placeholder="Your Email *" value="" />
                      </div>
                      <div class="form-group">
                          <input type="text" name="txtPhone" class="form-control" placeholder="Your Phone Number *" value="" />
                      </div>

                  </div>
                  <div class="col-lg-12">
                      <div class="form-group">
                          <textarea name="txtMsg" class="form-control" placeholder="Your Message *" style="width: 100%; height: 150px;"></textarea>
                      </div>
                      <div class="form-group">
                        <input type="submit" name="btnSubmit" class="btnContact" value="Send Message" />
                    </div>
                  </div>

              </div>
          </form>
</div>
      </div>

    </div>
  </div>
</div>


<br>
<img src="img/kpimg2.png" class="img-fluid" width="100%" >




<style>
  .parallax {
      /* The image used */
      background-image: url("images/bg1.jpg");
      /* Set a specific height */
      min-height: 450px;
      /* Create the parallax scrolling effect */
      background-attachment: fixed;
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
  }
</style>


<div >
<div class="parallax">
  <div style="background-color:  #2b6db4;opacity:0.8;height: auto;padding:10px;">

      <br>
      <p style="font-size: 30px;color:white;text-align: center;"><b>What Clients say</b></p>
<br>

<div class="deskContent">

<div id="carouselExampleControls" class="carousel slide" data-ride="carousel" style="min-height:300px;">
  <div class="carousel-inner">
    <div class="carousel-item active">

<div class="row slidetesti">
    <div class="col-lg-6 col-md-6 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="images/seo.jpg" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
    <div class="col-lg-6 col-md-6 col-xs-12">
    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="images/seo.jpg" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>
    </div>
</div>

    </div>
    <div class="carousel-item">


<div class="row slidetesti">
    <div class="col-lg-6 col-md-6 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="images/seo.jpg" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
    <div class="col-lg-6 col-md-6 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="images/seo.jpg" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
</div>


    </div>

    <div class="carousel-item">


    <div class="row slidetesti">
    <div class="col-lg-6 col-md-6 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="images/seo.jpg" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
    <div class="col-lg-6 col-md-6 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="images/seo.jpg" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
</div>


    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>

<div class="phoneContent">

<div id="carouselExampleControlss" class="carousel slide" data-ride="carousel" style="min-height:300px;">
  <div class="carousel-inner">
    <div class="carousel-item active">

<div class="row slidetesti">

    <div class="col-lg-12 col-md-12 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="images/seo.jpg" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
</div>

    </div>
    <div class="carousel-item">


<div class="row slidetesti">

    <div class="col-lg-12 col-md-12 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="images/seo.jpg" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
</div>


    </div>

    <div class="carousel-item">


    <div class="row slidetesti">

    <div class="col-lg-12 col-md-12 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="images/seo.jpg" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
</div>


    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControlss" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControlss" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>

      <div>
          <div>

          </div>
      </div>
  </div>

</div>
</div>

<style>
  .modal.left .modal-dialog,
  .modal.right .modal-dialog {
      position: fixed;
      margin: auto;
      width: 320px;
      height: 100%;
      -webkit-transform: translate3d(0%, 0, 0);
      -ms-transform: translate3d(0%, 0, 0);
      -o-transform: translate3d(0%, 0, 0);
      transform: translate3d(0%, 0, 0);
  }

  .modal.left .modal-content,
  .modal.right .modal-content {
      height: 100%;
      width: 100%;
      margin-top: 100px;
      margin-left: 20px;
      overflow-y: hidden;
      padding: 10px 5px 0px 5px;
  }

  .modal.left .modal-body,
  .modal.right .modal-body {
      padding: 15px 15px 80px;
  }
  /*Right*/

  .modal.right.fade .modal-dialog {
      right: -30px;
      -webkit-transition: opacity 0.4s linear, right 0.8s ease-out;
      -moz-transition: opacity 0.3s linear, right 0.8s ease-out;
      -o-transition: opacity 0.3s linear, right 0.8s ease-out;
      transition: opacity 0.3s linear, right 0.8s ease-out;
      background: transparent;
  }

  .modal.right.fade.in .modal-dialog {
      right: 0;
  }

  .fade.show {
      background-color: transparent;
  }

  #hiddenPanel {
      position: fixed;
      top: 0;
      right: -270px;
      width: 270px;
      height: 250px;
  }

  #close-bar {
      /* position: absolute;
      left: -20px;
      margin-top: -350px; */
      /* background-image: url('assets/images/lets.png'); */
      /* background-color: red; */
      /* color: white;
      width: 20px;
      height: 250px; */
  }

</style>


<section id="hiddenPanel" class="txt-highlight-color bg-color bg-pattern">
  <div class="modal-dialog" role="document">
      <div class="modal-content " style='padding:10px;margin-top: 100px;'>




          <div class="modal-body " style="background-color: #2b6db4;height: 435px;">
              <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close" style='color:white'><span aria-hidden="true">&times;</span></button> -->
<br>
              <p style='color:white;text-align: center;font-size: 14px;font-family: open sans,sans-serif;'><b>Request a call back now</b></p>

              <form style='margin-top:52px;'>
                  <input class='form-control' placeholder="Name" style="height:33px">
                  <input class='form-control' placeholder="Email" style='margin-top:13px;height:33px'>
                  <input class='form-control' placeholder="Phone" style='margin-top:13px;height:33px'>
                  <input class='form-control' placeholder="Service" style='margin-top:13px;height:33px'>
                  <textarea class='form-control' rows='2' placeholder="Message" style='margin-top:13px;'>
                       </textarea>
                  <br>
                  <div style='text-align: center;'>
                      <button class='btn btn-success' style='border-radius: 200px;'>Submit</button>
                  </div>


              </form>
          </div>

      </div>
      <!-- modal-content -->
  </div>


  <span id="close-bar" class="myButton" style='position: absolute;
      margin-top: 200px;
  height: 48px;
  width: 160px;
  text-align: center;
  box-shadow: -2px -1px 8px rgba(58,56,52,.28);
  cursor: pointer;
  background: #0068a1;
  top: 45%;
  font-weight: 600;
  left: -104px;
  border-radius: 3px 3px 0 0;
  transform: rotate(270deg);
  cursor: pointer;
  color: #fff;
  line-height: 48px;
  font-size: 16px;
  z-index: 999;' data-toggle="modal" data-target="#exampleModalCenter">Let's Connect </span>
</section>

<div class="modal right fade " id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
      <div class="modal-content " style='padding:10px;'>




          <div class="modal-body " style="background-color: #2b6db4;height:200px">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close" style='color:white'><span aria-hidden="true">&times;</span></button>

              <p style='color:white;text-align: center;font-size: 14px;font-family: open sans,sans-serif;'><b>Request a call back now</b></p>

              <form style='margin-top:52px;'>
                  <input class='form-control' placeholder="Name" style="height:33px">
                  <input class='form-control' placeholder="Email" style='margin-top:13px;height:33px'>
                  <input class='form-control' placeholder="Phone" style='margin-top:13px;height:33px'>
                  <input class='form-control' placeholder="Service" style='margin-top:13px;height:33px'>
                  <textarea class='form-control' rows='2' placeholder="Message" style='margin-top:13px;'>
                       </textarea>
                  <br>
                  <div style='text-align: center;'>
                      <button class='btn btn-success' style='border-radius: 200px;'>Submit</button>
                  </div>


              </form>
          </div>

      </div>
      <!-- modal-content -->
  </div>
  <!-- modal-dialog -->
</div>






@endsection
