@extends('front/layout')
@section('page_title','Livetech-Vision-And-Mission')

@section('container')

<style>
     .card {
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
        transition: 0.3s;
    }

    .card:hover {
      box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
      transition: 0.3s;
      border-left:2px solid #2fc5b9;
      border-right:2px solid #2b6db4;
      border-radius:10px;
  }

    </style>

<img class="img-fluid" src="{{ asset('img/vision.png') }}" alt="livetch"/>


<div >
<div class='col-lg-12'>
  <br>
    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b style="color:#2fc5b9;">Careers At</b><b> Livetech</b></p>
    <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

</div>

<div class='container-fluid' style='margin-bottom:10px;'>
  <div class='row'>

<div class="col-lg-6">
  <img src="img/visionimg.png" class="img-fluid" style="height:auto;width:auto;">
</div>
<div class="col-lg-6"  >

<p style="font-size: 20px;font-weight:500;color:#2b6db4;text-align: center;">Our Vision</p>
    <hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

  <p align="justify" style="margin-top:10px;color:#067751;font-weight:500;padding:10px;"> We have a vivid presence in the Indian as well as the International market for our top-notch software development services, Being a customer oriented company, we pay special attention to offer our clients an insight driven intuitive service to ensure the best outcome at the most affordable budget.understand the requirement of our customers, thus we have hired the professionals who can think like a customer and deliver the solutions exactly. Our products are totally trend defining that rely on the basis of market's needs. We cover almost all verticals of software solutions from the web to latest android and ios application. We are trying to make customer’s life easy and comfortable through technology because we are making something different for them.</p>

<br/>
<p style="font-size: 20px;font-weight:500;color:#2b6db4;text-align: center;">Our Mission</p>
    <hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

  <p align="justify" style="margin-top:10px;color:#067751;font-weight:500;padding:10px;">LTS is one of the fastest growing software development companies in Delhi NCR that provides one-stop-web-solution to every organization and individual.</p>


</div>

  </div>

</div>
</div>


<div class="container">
<div class='col-lg-12'>
  <br>
    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b style="color:#2fc5b9;">Company's</b><b> Goals</b></p>
    <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

</div>


<div class="row">

<div class="col-lg-3 col-md-3 col-xs-12">
        <div class="card" style="box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;">
        <div style="background-image: url('{{ asset('img/bgg3.png') }}');  background-repeat: no-repeat;background-size: auto;">

<div style="margin-left:auto;margin-right:auto;text-align:center;">        <i class="fa fa-cogs" style="font-size:70px;color:#2fc5b9;"></i>
</div>
<br>
        <h5 style="color:#2b6db4;text-align:center;background-color:white;padding:5px;">Skill Development</h5>
</div>
    </div>
    </div>
    <div class="col-lg-3 col-md-3 col-xs-12">
        <div class="card" style="box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;">
        <div style="background-image: url('{{ asset('img/bgg3.png') }}');  background-repeat: no-repeat;background-size: auto;">

<div style="margin-left:auto;margin-right:auto;text-align:center;">        <i class="fa fa-gavel" style="font-size:70px;color:#2fc5b9;"></i>
</div>
<br>
        <h5 style="color:#2b6db4;text-align:center;background-color:white;padding:5px;">On time Delivery</h5>
</div>
    </div>
    </div>
    <div class="col-lg-3 col-md-3 col-xs-12">
        <div class="card" style="box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;">
        <div style="background-image: url('{{ asset('img/bgg3.png') }}');  background-repeat: no-repeat;background-size: auto;">

<div style="margin-left:auto;margin-right:auto;text-align:center;">        <i class="fa fa-wrench" style="font-size:70px;color:#2fc5b9;"></i>
</div>
<br>
        <h5 style="color:#2b6db4;text-align:center;background-color:white;padding:5px;">Agile Development</h5>
</div>
    </div>
    </div>
    <div class="col-lg-3 col-md-3 col-xs-12">
        <div class="card" style="box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;">
        <div style="background-image: url('{{ asset('img/bgg3.png') }}');  background-repeat: no-repeat;background-size: auto;">

<div style="margin-left:auto;margin-right:auto;text-align:center;">        <i class="fa fa-puzzle-piece" style="font-size:70px;color:#2fc5b9;"></i>
</div>
<br>
        <h5 style="color:#2b6db4;text-align:center;background-color:white;padding:5px;">Best Deployment and Maintainence</h5>
</div>
    </div>
    </div>



</div>






</div>

@endsection
