@extends('front/layout')
@section('page_title','Livetech-Career')

@section('container')

<style>
     .card {
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
        transition: 0.3s;
    }

    .card:hover {
      box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
      transition: 0.3s;
      border-left:2px solid #2fc5b9;
      border-right:2px solid #2b6db4;
      border-radius:10px;
  }

    </style>

<img class="img-fluid" src="{{ asset('img/career.png') }}" alt="livetch"/>


<div >
<div class='col-lg-12'>
  <br>
    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b style="color:#2fc5b9;">Careers At</b><b> Livetech</b></p>
    <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

</div>

<div class='container-fluid' style='margin-bottom:10px;'>
  <div class='row'>

<div class="col-lg-6">
  <img src="img/careerimg.png" class="img-fluid" style="height:auto;width:auto;">
</div>
<div class="col-lg-6"  >

<p style="font-size: 20px;font-weight:500;color:#2b6db4;text-align: center;">Who Are We ?</p>
    <hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

  <p align="justify" style="margin-top:10px;color:#067751;font-weight:500;padding:10px;"> We have a vivid presence in the Indian as well as the International market for our top-notch software development services, Being a customer oriented company, we pay special attention to offer our clients an insight driven intuitive service to ensure the best outcome at the most affordable budget.understand the requirement of our customers, thus we have hired the professionals who can think like a customer and deliver the solutions exactly. Our products are totally trend defining that rely on the basis of market's needs. We cover almost all verticals of software solutions from the web to latest android and ios application. We are trying to make customer’s life easy and comfortable through technology because we are making something different for them.</p>

<br/>
<p style="font-size: 20px;font-weight:500;color:#2b6db4;text-align: center;">Where Are We ?</p>
    <hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

  <p align="justify" style="margin-top:10px;color:#067751;font-weight:500;padding:10px;">LTS is one of the fastest growing software development companies in Delhi NCR that provides one-stop-web-solution to every organization and individual.</p>


</div>

  </div>

</div>
</div>


<div class="container">
<div class='col-lg-12'>
  <br>
    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b style="color:#2fc5b9;">Benifits At</b><b> Livetech</b></p>
    <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

</div>


<div class="row">

<div class="col-lg-3 col-md-3 col-xs-12">
        <div class="card" style="box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;">
        <div style="background-image: url('{{ asset('img/bgg3.png') }}');  background-repeat: no-repeat;background-size: auto;">

<div style="margin-left:auto;margin-right:auto;text-align:center;">        <i class="fa fa-star" style="font-size:70px;color:#2fc5b9;"></i>
</div>
<br>
        <h5 style="color:#2b6db4;text-align:center;background-color:white;padding:5px;">Skill Enhancement</h5>
</div>
    </div>
    </div>
    <div class="col-lg-3 col-md-3 col-xs-12">
        <div class="card" style="box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;">
        <div style="background-image: url('{{ asset('img/bgg3.png') }}');  background-repeat: no-repeat;background-size: auto;">

<div style="margin-left:auto;margin-right:auto;text-align:center;">        <i class="fa fa-cogs" style="font-size:70px;color:#2fc5b9;"></i>
</div>
<br>
        <h5 style="color:#2b6db4;text-align:center;background-color:white;padding:5px;">Work on LiveProjects</h5>
</div>
    </div>
    </div>
    <div class="col-lg-3 col-md-3 col-xs-12">
        <div class="card" style="box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;">
        <div style="background-image: url('{{ asset('img/bgg3.png') }}');  background-repeat: no-repeat;background-size: auto;">

<div style="margin-left:auto;margin-right:auto;text-align:center;">        <i class="fa fa-users" style="font-size:70px;color:#2fc5b9;"></i>
</div>
<br>
        <h5 style="color:#2b6db4;text-align:center;background-color:white;padding:5px;">Client Interaction</h5>
</div>
    </div>
    </div>
    <div class="col-lg-3 col-md-3 col-xs-12">
        <div class="card" style="box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;">
        <div style="background-image: url('{{ asset('img/bgg3.png') }}');  background-repeat: no-repeat;background-size: auto;">

<div style="margin-left:auto;margin-right:auto;text-align:center;">        <i class="fa fa-trophy" style="font-size:70px;color:#2fc5b9;"></i>
</div>
<br>
        <h5 style="color:#2b6db4;text-align:center;background-color:white;padding:5px;">Games</h5>
</div>
    </div>
    </div>



</div>




<div class='col-lg-12'>
  <br>
    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b style="color:#2fc5b9;">Drop Your</b><b> Resume</b></p>
    <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

</div>


@if(session('message'))
 <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
             {{ session('message')}}

           </div>
            @endif
<form action="{{ url('resume_form') }}" method="post" role="form" class="info-box" enctype="multipart/form-data" >
            	@csrf
              <div class="form-row">
                <div class="col form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name"  />
                   @error('name')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
                <div class="col form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email"  />
                @error('email')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
              </div>
              <div class="form-row">
                <div class="col form-group">
                  <input type="number" name="phone" class="form-control" id="phone" placeholder="Your Mobile"  />
                   @error('phone')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
                <div class="col form-group">
                  <input type="text" class="form-control" name="college" id="college" placeholder="Your College Name" />
                @error('college')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
              </div>
              <div class="form-row">
              <div class="col form-group">
                  <input type="text" class="form-control" name="qualification" id="qualification" placeholder="Your highest Qualifications"  />
                @error('qualification')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>

              <div class="col form-group">
                  <input type="text" class="form-control" name="marks" id="marks" placeholder="Your highest Qualification Marks"  />
                @error('marks')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>

</div>
<div class="form-row">
              <div class="col form-group">
                  <input type="text" class="form-control" name="type" id="type" placeholder="Fresher or Experience"  />
                @error('type')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>


              <div class="col form-group">
                  <input type="text" class="form-control" name="skill" id="skill" placeholder="Skills"  />
                @error('skill')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
              </div>

              <div class="form-group">
                <textarea class="form-control" name="address" rows="5"   placeholder="Your Address"></textarea>
                  @error('address')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
              </div>

              <div class="form-row">
              <div class="col form-group">
                  <label>Your Photo :</label>
                  <input type="file" class="form-control" name="image" id="image" />
                @error('image')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
                <div class="col form-group">
                <label>Your Resume : &nbsp;<b style="color:red;">(In pdf formate)</b></label>
                  <input type="file" class="form-control" name="image1" id="image1"  accept="application/pdf" />
                @error('image1')
                     <p style="color:red;">{{$message}}</p>
                      @enderror
                </div>
            </div>

<center>             <button type="submit" class="btn btn-primary">SUBMIT</button></center>
            </form>

      </div>



</div>

@endsection
