@extends('front/layout')
@section('page_title','Livetech-Services')

@section('container')

<style>
  .card {
      box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;
  }

  .card:hover {
    box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
      transition: 0.3s;
      background-color:transparent;
      border-left:2px solid #2fc5b9;
      border-right:2px solid #2b6db4;
      padding:15px;
      border-radius:10px;
  }

  .kk{
    border:2px solid #2b6db4;
  }
    .kk:hover{
    border:3px solid #067751;
  }
  .txt:hover {
    border-bottom: 2px solid #067751;
}
</style>

<img class="img-fluid" src="{{ asset('img/services.png') }}" alt="livetch"/>

<div style="background-image: url('img/bgg9.png');">
<div class="container marketing">
<br>
  <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b style="color:#2fc5b9;">Our Excellence </b><b>Services</b></p>
  <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

<br>
  <!-- Three columns of text below the carousel -->
  <div class="row">
    <div class="col-lg-3">
<div class="card" >
      <img class="img-fluid" style="height:180px;width:200px;margin-left:auto;margin-right:auto;display:block;" src='img/icons/web.png' alt="livetech"/>
      <h5 style="color:#2b6db4;text-align:center;">Web Designing</h5>
      <p align="justify" style="background-image: url('img/bgg5.png');  background-repeat: no-repeat;
  background-size: auto;">We design attractive and user friendly UI. Our Projects have good responsivness</p>
      <p><a class="btn btn-outline-primary" href="{{ url('page/WEB')}}" role="button">View details &raquo;</a></p>
</div>
    </div><!-- /.col-lg-4 -->
    <div class="col-lg-3">
      <div class="card">
      <img class="img-fluid" style="height:180px;width:200px;margin-left:auto;margin-right:auto;display:block;" src='img/icons/digital.png' alt="livetech"/>
      <h5 style="color:#2b6db4;text-align:center;">Digital Marketing</h5>
      <p align="justify" style="background-image: url('img/bgg5.png');  background-repeat: no-repeat;
  background-size: auto;">We have the best digital marketing service. we have SEO, SMO, Email Marketing etc.</p>
      <p><a class="btn btn-outline-primary" href="{{ url('page2/Digital')}}" role="button">View details &raquo;</a></p>
   </div>
    </div><!-- /.col-lg-4 -->
    <div class="col-lg-3">
      <div class="card">
      <img class="img-fluid" style="height:180px;width:200px;margin-left:auto;margin-right:auto;display:block;" src='img/icons/erp.png' alt="livetech"/>
      <h5 style="color:#2b6db4;text-align:center;">ERP</h5>
      <p align="justify" style="background-image: url('img/bgg5.png');  background-repeat: no-repeat;
  background-size: auto;">We have the best ERP Solutions. we design ERP platforms as per customer requirement.</p>
      <p><a class="btn btn-outline-primary" href="{{ url('page3/ERP')}}" role="button">View details &raquo;</a></p>
    </div>
    </div><!-- /.col-lg-4 -->
    <div class="col-lg-3">
      <div class="card">
      <img class="img-fluid" style="height:180px;width:200px;margin-left:auto;margin-right:auto;display:block;" src='img/icons/crm.png' alt="livetech"/>
      <h5 style="color:#2b6db4;text-align:center;">CRM</h5>
      <p align="justify" style="background-image: url('img/bgg5.png');  background-repeat: no-repeat;
  background-size: auto;">We have the best CRM Solutions. we design CRM platforms as per customer requirement.</p>
      <p><a class="btn btn-outline-primary" href="{{ url('page4/CRM')}}" role="button">View details &raquo;</a></p>
    </div>
    </div><!-- /.col-lg-4 -->

    <div class="col-lg-3">
      <div class="card">
      <img class="img-fluid" style="height:180px;width:200px;margin-left:auto;margin-right:auto;display:block;" src='img/icons/e-comm.png' alt="livetech"/>
      <h5 style="color:#2b6db4;text-align:center;">E-Commerce Solutons</h5>
      <p align="justify" style="background-image: url('img/bgg5.png');  background-repeat: no-repeat;
  background-size: auto;">We have the best E-Commerce Solutions. we design re-commerce solutions as per customer requirement.</p>
      <p><a class="btn btn-outline-primary" href="{{ url('page5/E-commerce')}}" role="button">View details &raquo;</a></p>
    </div>
    </div><!-- /.col-lg-4 -->

    <div class="col-lg-3">
      <div class="card">
      <img class="img-fluid" style="height:180px;width:200px;margin-left:auto;margin-right:auto;display:block;" src='img/icons/graphic.png' alt="livetech"/>
      <h5 style="color:#2b6db4;text-align:center;">Graphic Designing</h5>
      <p align="justify" style="background-image: url('img/bgg5.png');  background-repeat: no-repeat;
  background-size: auto;">We have the best web graphic design service. we design logo as per customer requirement.</p>
      <p><a class="btn btn-outline-primary" href="{{ url('page6/Graphic')}}" role="button">View details &raquo;</a></p>
    </div>
    </div><!-- /.col-lg-4 -->

    <div class="col-lg-3">
      <div class="card">
      <img class="img-fluid" style="height:180px;width:200px;margin-left:auto;margin-right:auto;display:block;" src='img/icons/graphic.png' alt="livetech"/>
      <h5 style="color:#2b6db4;text-align:center;">Mobile App Development</h5>
      <p align="justify" style="background-image: url('img/bgg5.png');  background-repeat: no-repeat;
  background-size: auto;">We have the best web graphic design service. we design logo as per customer requirement.</p>
      <p><a class="btn btn-outline-primary" href="{{ url('page7/Mobile')}}" role="button">View details &raquo;</a></p>
    </div>
    </div><!-- /.col-lg-4 -->

  </div><!-- /.row -->


  <style>

    .alizarin{background:#e74c3c}
.amethyst{background:#9b59b6}
.emerald{background:#2ecc71}
.midnight-blue{background:#2b6db4}
.peter-river{background:#2fc5b9}
.dl{background:#f0f0f0;padding:20px 0;border-radius:20px;position:relative}
.dl:before{content:" ";height:20px;width:20px;background:#2fc5b9;border-radius:20px;position:absolute;left:50%;top:20px;margin-left:-10px}
.dl .brand{text-transform:uppercase;letter-spacing:3px;padding:10px 15px;margin-top:10px;text-align:center;min-height:10px}
.dl .discount{min-height:50px;position:relative;font-size:20px;line-height:50px;text-align:center;font-weight:200;padding:2px 5px 0;color:white}
.dl .discount:after{content:" ";border-right:20px solid transparent;border-left:20px solid transparent;position:absolute;bottom:-20px;left:20%}
.dl .discount.alizarin:after{border-top:20px solid #e74c3c}
.dl .discount.peter-river:after{border-top:20px solid #2fc5b9}
.dl .discount.emerald:after{border-top:20px solid #2fc5b9}
.dl .discount.amethyst:after{border-top:20px solid #9b59b6}
.dl .discount .type{font-size:20px;letter-spacing:1px;text-transform:uppercase;margin-top:-30px}
.dl .descr{color:#999;margin-top:10px;padding:20px 15px}
.dl .ends{padding:0 15px;color:yellowgreen;margin-bottom:10px}
.dl .coupon{min-height:30px;text-align:center;text-transform:uppercase;font-weight:500;font-size:15px;padding:10px 15px}
.dl .coupon a.open-code{color:#16a085}
.dl .coupon .code{letter-spacing:1px;border-radius:4px;margin-top:10px;padding:10px 15px;color:#2fc5b9;background:#f0f0f0}
  </style>


</div>
</div>

<style>

  .counter{
    color: #f27f21;
    font-family: 'Open Sans', sans-serif;
    text-align: center;
    height: 190px;
    width: 190px;
    padding: 30px 25px 25px;
    margin: 0 auto;
    border: 3px solid #f27f21;
    border-radius: 20px 20px;
    position: relative;
    z-index: 1;
}
.counter:before,
.counter:after{
    content: "";
    background: #f3f3f3;
    border-radius: 20px;
    box-shadow: 4px 4px 2px rgba(0,0,0,0.2);
    position: absolute;
    left: 15px;
    top: 15px;
    bottom: 15px;
    right: 15px;
    z-index: -1;
}
.counter:after{
    background: transparent;
    width: 100px;
    height: 100px;
    border: 15px solid #f27f21;
    border-top: none;
    border-right: none;
    border-radius: 0 0 0 20px;
    box-shadow: none;
    top: auto;
    left: -10px;
    bottom: -10px;
    right: auto;
}
.counter .counter-icon{
    font-size: 35px;
    line-height: 35px;
    margin: 0 0 15px;
    transition: all 0.3s ease 0s;
}
.counter:hover .counter-icon{ transform: rotateY(360deg); }
.counter .counter-value{
    color: #555;
    font-size: 30px;
    font-weight: 600;
    line-height: 20px;
    margin: 0 0 20px;
    display: block;
    transition: all 0.3s ease 0s;
}
.counter:hover .counter-value{ text-shadow: 2px 2px 0 #d1d8e0; }
.counter h3{
    font-size: 17px;
    font-weight: 700;
    text-transform: uppercase;
    margin: 0 0 15px;
}
.counter.blue{
    color: #2b6db4;
    border-color: #2b6db4;
}
.counter.blue:after{
  border-bottom-color: #2b6db4;
  border-left-color: #2b6db4;
}
.counter.red{
  color: #df4010;
  border-color: #df0808;
}
.counter.red:after{
  border-bottom-color: #d60101;
  border-left-color: #d60101;
}
.counter.green{
  color: #28c700;
  border-color: #28c700;
}
.counter.green:after{
  border-bottom-color: #28c700;
  border-left-color: #28c700;
}

@media screen and (max-width:990px){
    .counter{ margin-bottom: 40px; }
}

</style>

<div >
<p style="font-size: 30px;color:#2b6db4;text-align: center;"><b style="color:#2fc5b9;">We Also </b><b> Work On</b></p>
<hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

<div class="container">
    <div class="row">
        <div class="col-md-3 col-sm-6">
            <div class="counter blue">
                <div class="counter-icon">
                    <i class="fa fa-globe"></i>
                </div>
                <span class="counter-value">761</span>
                <h3>Web Designing</h3>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="counter blue">
                <div class="counter-icon">
                    <i class="fa fa-rocket"></i>
                </div>
                <span class="counter-value">719</span>
                <h3>Web Development</h3>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="counter blue">
              <div class="counter-icon">
                  <i class="fa fa-rocket"></i>
              </div>
              <span class="counter-value">719</span>
              <h3>Web Development</h3>
          </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="counter blue">
            <div class="counter-icon">
                <i class="fa fa-rocket"></i>
            </div>
            <span class="counter-value">719</span>
            <h3>Web Development</h3>
        </div>
    </div>
    </div>
</div>
</div>

  <!-- START THE FEATURETTES -->

<br>
<p style="font-size: 30px;color:#2b6db4;text-align: center;"><b>Faq</b></p>
<hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">
<div style="background-image: url('img/kpimg3.png');  background-repeat: no-repeat;
  background-size: auto;">
<br>
<div class="container" >
  <div class="col-lg-12 " >
  <div >

   <div id="accordion">
     <div class="card">
       <div class="card-header" id="headingOne">
         <h5 class="mb-0">
           <button class="btn btn-outline-primary" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
             Fast Delivery
           </button>
           <i class="fa fa-plus btn btn-outline-primary" style="float:right;" aria-hidden="true" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne" aria-hidden="true"></i>
          </h5>
       </div>

       <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
         <div class="card-body">

           <p  align="justify">Fast Delivery </p>

         </div>
       </div>
     </div>
     <div class="card">
       <div class="card-header" id="headingTwo">
         <h5 class="mb-0">
           <button class="btn btn-outline-primary collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
             User Friendly
           </button>
           <i class="fa fa-plus btn btn-outline-primary collapsed" style="float:right;" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" aria-hidden="true"></i>
         </h5>
       </div>
       <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
         <div class="card-body">

           <p>User Friendly</p>
         </div>
       </div>
     </div>
     <div class="card">
       <div class="card-header" id="headingThree">
         <h5 class="mb-0">
           <button class="btn btn-outline-primary collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
             Based On User Requirement
           </button>
           <i class="fa fa-plus btn btn-outline-primary collapsed" style="float:right;" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree" aria-hidden="true"></i>
         </h5>
       </div>
       <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
         <div class="card-body">

             <p>Based On User Requirement</p>
         </div>
       </div>
     </div>
   </div>

  </div>
</div>
  </div>
  </div>

<br>





@endsection
