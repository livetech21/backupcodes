@extends('front/layout')
@section('page_title','Livetech-About')

@section('container')


<!-- Marketing messaging and featurettes
================================================== -->
<!-- Wrap the rest of the page in another container to center all the content. -->
<style>
  .card {
      box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;
  }

  .card:hover {
      box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
      transition: 0.3s;
      background-color:transparent;
      border-left:2px solid #2fc5b9;
      border-right:2px solid #2b6db4;
      padding:15px;
      border-radius:10px;
  }

  .kk{
    border:2px solid #2b6db4;
  }
    .kk:hover{
    border:3px solid #067751;
  }
  .txt:hover {
    border-bottom: 2px solid #067751;
}
</style>

<img class="img-fluid" src="{{ asset('img/about.png') }}" alt="livetch"/>


<div >
<div class='col-lg-12'>
  <br>
    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b style="color:#2fc5b9;">About </b><b>Us</b></p>
    <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

</div>

<div class='container-fluid' style='margin-bottom:10px;'>
  <div class='row'>

<div class="col-lg-6">
  <img src="img/photo.png" class="img-fluid" style="height:auto;width:auto;">
</div>
<div class="col-lg-6"  >

  <p align="justify" style="margin-top:10px;color:#067751;font-weight:500;padding:10px;">LTS is one of the fastest growing software development companies in Delhi NCR that provides one-stop-web-solution to every organization and individual. We have a vivid presence in the Indian as well as the International market for our top-notch software development services, Being a customer oriented company, we pay special attention to offer our clients an insight driven intuitive service to ensure the best outcome at the most affordable budget.understand the requirement of our customers, thus we have hired the professionals who can think like a customer and deliver the solutions exactly. Our products are totally trend defining that rely on the basis of market's needs. We cover almost all verticals of software solutions from the web to latest android and ios application. We are trying to make customer’s life easy and comfortable through technology because we are making something different for them.</p>


</div>

  </div>

</div>
</div>



<!-- <div class="module">
  <div class="demo">
      <br><br>
    <div class="container">
      <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b style="color:#2fc5b9;">About </b><b> Team</b></p>
      <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

<div class="row">
    <div class="col-lg-6 col-md-5 col-xs-12">
<div style="margin-left:auto;margin-right:auto;text-align:center;"><img src="img/icons/userpic.png" class="img-fluid" alt="immense"/>
</div>
<div style="margin-left:auto;margin-right:auto;text-align:center;padding:5px;"><b>CEO</b></div>
<p align="justify" style="padding:10px;">jsd  vnsd xchb sdbnxc bnsd xbv dsb  vvbf db nbsd xcnbd c.</p>
    </div>

    <div class="col-lg-6 col-md-6 col-xs-12">
    <div style="margin-left:auto;margin-right:auto;text-align:center;"><img src="img/icons/userpic.png" class="img-fluid" alt="immense"/>
</div>
<div style="margin-left:auto;margin-right:auto;text-align:center;padding:5px;"><b>MD</b></div>
<p align="justify" style="padding:10px;">jsd  vnsd xchb sdbnxc bnsd xbv dsb  vvbf db nbsd xcnbd c.</p>


    </div>


</div>

    </div>
  </div>
  </div> -->

<style>
  a{text-decoration:none}
h4{text-align:center;margin:30px 0;color:#444}
.main-timeline{position:relative}
.main-timeline:before{content:"";width:5px;height:100%;border-radius:20px;margin:0 auto;background:#242922;position:absolute;top:0;left:0;right:0}
.main-timeline .timeline{display:inline-block;margin-bottom:50px;position:relative}
.main-timeline .timeline:before{content:"";width:20px;height:20px;border-radius:50%;border:4px solid #fff;background:#ec496e;position:absolute;top:50%;left:50%;z-index:1;transform:translate(-50%,-50%)}
.main-timeline .timeline-icon{display:inline-block;width:130px;height:130px;border-radius:50%;border:3px solid #ec496e;padding:13px;text-align:center;position:absolute;top:50%;left:30%;transform:translateY(-50%)}
.main-timeline .timeline-icon i{display:block;border-radius:50%;background:#ec496e;font-size:64px;color:#fff;line-height:100px;z-index:1;position:relative}
.main-timeline .timeline-icon:after,.main-timeline .timeline-icon:before{content:"";width:100px;height:4px;background:#ec496e;position:absolute;top:50%;right:-100px;transform:translateY(-50%)}
.main-timeline .timeline-icon:after{width:70px;height:50px;background:#fff;top:89px;right:-30px}
.main-timeline .timeline-content{width:50%;padding:0 50px;margin:52px 0 0;float:right;position:relative}
.main-timeline .timeline-content:before{content:"";width:70%;height:100%;border:3px solid #ec496e;border-top:none;border-right:none;position:absolute;bottom:-13px;left:35px}
.main-timeline .timeline-content:after{content:"";width:37px;height:3px;background:#ec496e;position:absolute;top:13px;left:0}
.main-timeline .title{font-size:20px;font-weight:600;color:#ec496e;text-transform:uppercase;margin:0 0 5px}
.main-timeline .description{display:inline-block;font-size:16px;color:#404040;line-height:20px;letter-spacing:1px;margin:0}
.main-timeline .timeline:nth-child(even) .timeline-icon{left:auto;right:30%}
.main-timeline .timeline:nth-child(even) .timeline-icon:before{right:auto;left:-100px}
.main-timeline .timeline:nth-child(even) .timeline-icon:after{right:auto;left:-30px}
.main-timeline .timeline:nth-child(even) .timeline-content{float:left}
.main-timeline .timeline:nth-child(even) .timeline-content:before{left:auto;right:35px;transform:rotateY(180deg)}
.main-timeline .timeline:nth-child(even) .timeline-content:after{left:auto;right:0}
.main-timeline .timeline:nth-child(2n) .timeline-content:after,.main-timeline .timeline:nth-child(2n) .timeline-icon i,.main-timeline .timeline:nth-child(2n) .timeline-icon:before,.main-timeline .timeline:nth-child(2n):before{background:#f9850f}
.main-timeline .timeline:nth-child(2n) .timeline-icon{border-color:#f9850f}
.main-timeline .timeline:nth-child(2n) .title{color:#f9850f}
.main-timeline .timeline:nth-child(2n) .timeline-content:before{border-left-color:#f9850f;border-bottom-color:#f9850f}
.main-timeline .timeline:nth-child(3n) .timeline-content:after,.main-timeline .timeline:nth-child(3n) .timeline-icon i,.main-timeline .timeline:nth-child(3n) .timeline-icon:before,.main-timeline .timeline:nth-child(3n):before{background:#8fb800}
.main-timeline .timeline:nth-child(3n) .timeline-icon{border-color:#8fb800}
.main-timeline .timeline:nth-child(3n) .title{color:#8fb800}
.main-timeline .timeline:nth-child(3n) .timeline-content:before{border-left-color:#8fb800;border-bottom-color:#8fb800}
.main-timeline .timeline:nth-child(4n) .timeline-content:after,.main-timeline .timeline:nth-child(4n) .timeline-icon i,.main-timeline .timeline:nth-child(4n) .timeline-icon:before,.main-timeline .timeline:nth-child(4n):before{background:#2fcea5}
.main-timeline .timeline:nth-child(4n) .timeline-icon{border-color:#2fcea5}
.main-timeline .timeline:nth-child(4n) .title{color:#2fcea5}
.main-timeline .timeline:nth-child(4n) .timeline-content:before{border-left-color:#2fcea5;border-bottom-color:#2fcea5}
@media only screen and (max-width:1200px){.main-timeline .timeline-icon:before{width:50px;right:-50px}
.main-timeline .timeline:nth-child(even) .timeline-icon:before{right:auto;left:-50px}
.main-timeline .timeline-content{margin-top:75px}
}
@media only screen and (max-width:990px){.main-timeline .timeline{margin:0 0 10px}
.main-timeline .timeline-icon{left:25%}
.main-timeline .timeline:nth-child(even) .timeline-icon{right:25%}
.main-timeline .timeline-content{margin-top:115px}
}
@media only screen and (max-width:767px){.main-timeline{padding-top:50px}
.main-timeline:before{left:80px;right:0;margin:0}
.main-timeline .timeline{margin-bottom:70px}
.main-timeline .timeline:before{top:0;left:83px;right:0;margin:0}
.main-timeline .timeline-icon{width:60px;height:60px;line-height:40px;padding:5px;top:0;left:0}
.main-timeline .timeline:nth-child(even) .timeline-icon{left:0;right:auto}
.main-timeline .timeline-icon:before,.main-timeline .timeline:nth-child(even) .timeline-icon:before{width:25px;left:auto;right:-25px}
.main-timeline .timeline-icon:after,.main-timeline .timeline:nth-child(even) .timeline-icon:after{width:25px;height:30px;top:44px;left:auto;right:-5px}
.main-timeline .timeline-icon i{font-size:30px;line-height:45px}
.main-timeline .timeline-content,.main-timeline .timeline:nth-child(even) .timeline-content{width:100%;margin-top:-15px;padding-left:130px;padding-right:5px}
.main-timeline .timeline:nth-child(even) .timeline-content{float:right}
.main-timeline .timeline-content:before,.main-timeline .timeline:nth-child(even) .timeline-content:before{width:50%;left:120px}
.main-timeline .timeline:nth-child(even) .timeline-content:before{right:auto;transform:rotateY(0)}
.main-timeline .timeline-content:after,.main-timeline .timeline:nth-child(even) .timeline-content:after{left:85px}
}
@media only screen and (max-width:479px){.main-timeline .timeline-content,.main-timeline .timeline:nth-child(2n) .timeline-content{padding-left:110px}
.main-timeline .timeline-content:before,.main-timeline .timeline:nth-child(2n) .timeline-content:before{left:99px}
.main-timeline .timeline-content:after,.main-timeline .timeline:nth-child(2n) .timeline-content:after{left:65px}
}


/******************* Timeline Demo - 6 *****************/
.demo{background:#f2f2f2}
.main-timeline6{overflow:hidden;position:relative}
.main-timeline6 .timeline{width:50%;float:right;position:relative;z-index:1}
.main-timeline6 .timeline:after,.main-timeline6 .timeline:before{position:absolute;top:50%;content:"";display:block;clear:both}
.main-timeline6 .timeline:before{width:40%;height:6px;background:#2fc5b9;left:0;z-index:-1;transform:translateY(-50%)}
.main-timeline6 .timeline:after{width:6px;height:70%;background:#2fc5b9;left:-3px}
.main-timeline6 .timeline-content{width:65%;float:right;padding:0 0 30px 30px;margin-right:15px;background:#fff;border-radius:10px;box-shadow:3px 3px 5px 6px #ccc}
.main-timeline6 .timeline-content:after,.main-timeline6 .timeline-content:before{content:"";width:26px;height:26px;border-radius:50%;background:#2fc5b9;position:absolute;top:50%;left:-13px;z-index:1;transform:translateY(-50%)}
.main-timeline6 .timeline-content:after{left:30%;transform:translate(-50%,-50%)}
.main-timeline6 .year{display:block;font-size:28px;font-weight:700;color:#2fc5b9;text-align:center;padding-left:50px}
.main-timeline6 .content-inner{padding:35px 15px 35px 110px;margin-right:-15px;background:#2fc5b9;border-radius:150px 0 0 150px;position:relative}
.main-timeline6 .content-inner:after,.main-timeline6 .content-inner:before{content:"";border-left:15px solid #2fc5b9;border-top:10px solid transparent;position:absolute;top:-10px;right:0}
.main-timeline6 .content-inner:after{border-top:none;border-bottom:10px solid transparent;top:auto;bottom:-10px}
.main-timeline6 .icon{width:110px;height:100%;text-align:center;position:absolute;top:0;left:0}
.main-timeline6 .icon i{font-size:60px;font-weight:700;color:#fff;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)}
.main-timeline6 .title{font-size:22px;font-weight:700;color:#fff;margin:0 0 5px}
.main-timeline6 .description{font-size:14px;color:#fff;margin:0}
.main-timeline6 .timeline:nth-child(2n) .icon,.main-timeline6 .timeline:nth-child(2n):after,.main-timeline6 .timeline:nth-child(2n):before{left:auto;right:0}
.main-timeline6 .timeline:nth-child(2n):after{right:-3px}
.main-timeline6 .timeline:nth-child(2n) .timeline-content{float:left;padding:0 30px 30px 0;margin:0 0 0 15px}
.main-timeline6 .timeline:nth-child(2n) .timeline-content:after,.main-timeline6 .timeline:nth-child(2n) .timeline-content:before{left:auto;right:-13px}
.main-timeline6 .timeline:nth-child(2n) .timeline-content:after{right:30%;margin-right:-25px}
.main-timeline6 .timeline:nth-child(2n) .year{padding:0 50px 0 0;color:#2b6db4}
.main-timeline6 .timeline:nth-child(2n) .content-inner{padding:35px 110px 35px 15px;margin:0 0 0 -15px;border-radius:0 150px 150px 0}
.main-timeline6 .timeline:nth-child(2n) .content-inner:after,.main-timeline6 .timeline:nth-child(2n) .content-inner:before{border:none;border-right:15px solid #2b6db4;border-top:10px solid transparent;right:auto;left:0}
.main-timeline6 .timeline:nth-child(2n) .content-inner:after{border-top:none;border-bottom:10px solid transparent}
.main-timeline6 .timeline:nth-child(2){margin-top:200px}
.main-timeline6 .timeline:nth-child(odd){margin:-190px 0 0}
.main-timeline6 .timeline:nth-child(even){margin-bottom:70px}
.main-timeline6 .timeline:first-child,.main-timeline6 .timeline:last-child:nth-child(even){margin:0}
.main-timeline6 .timeline:nth-child(2n) .content-inner,.main-timeline6 .timeline:nth-child(2n) .timeline-content:after,.main-timeline6 .timeline:nth-child(2n) .timeline-content:before,.main-timeline6 .timeline:nth-child(2n):after,.main-timeline6 .timeline:nth-child(2n):before{background:#2b6db4}
.main-timeline6 .timeline:nth-child(3n) .content-inner,.main-timeline6 .timeline:nth-child(3n) .timeline-content:after,.main-timeline6 .timeline:nth-child(3n) .timeline-content:before,.main-timeline6 .timeline:nth-child(3n):after,.main-timeline6 .timeline:nth-child(3n):before{background:#2b6db4}
.main-timeline6 .timeline:nth-child(3n) .content-inner:after,.main-timeline6 .timeline:nth-child(3n) .content-inner:before{border-left-color:#006662}
.main-timeline6 .timeline:nth-child(3n) .year{color:#00a3a9}
.main-timeline6 .timeline:nth-child(4n) .content-inner,.main-timeline6 .timeline:nth-child(4n) .timeline-content:after,.main-timeline6 .timeline:nth-child(4n) .timeline-content:before,.main-timeline6 .timeline:nth-child(4n):after,.main-timeline6 .timeline:nth-child(4n):before{background:#2fc5b9}
.main-timeline6 .timeline:nth-child(4n) .content-inner:after,.main-timeline6 .timeline:nth-child(4n) .content-inner:before{border-right-color:#2fc5b9}
.main-timeline6 .timeline:nth-child(4n) .year{color:#2fc5b9}
@media only screen and (max-width:990px) and (min-width:768px){.main-timeline6 .timeline:after{height:80%}
}
@media only screen and (max-width:767px){.main-timeline6 .timeline:last-child,.main-timeline6 .timeline:nth-child(even),.main-timeline6 .timeline:nth-child(odd){margin:0}
.main-timeline6 .timeline{width:95%;margin:15px 15px 15px 0!important}
.main-timeline6 .timeline .timeline-content:after,.main-timeline6 .timeline .timeline-content:before,.main-timeline6 .timeline:after,.main-timeline6 .timeline:before{display:none}
.main-timeline6 .timeline-content,.main-timeline6 .timeline:nth-child(2n) .timeline-content{width:100%;float:none;padding:0 0 30px 30px;margin:0}
.main-timeline6 .content-inner,.main-timeline6 .timeline:nth-child(2n) .content-inner{padding:35px 15px 35px 110px;margin:0 -15px 0 0;border-radius:150px 0 0 150px}
.main-timeline6 .timeline:nth-child(2n) .content-inner:after,.main-timeline6 .timeline:nth-child(2n) .content-inner:before{border:none;border-left:15px solid #027dcd;border-top:10px solid transparent;right:0;left:auto}
.main-timeline6 .timeline:nth-child(2n) .content-inner:after{border-top:none;border-bottom:10px solid transparent}
.main-timeline6 .timeline:nth-child(2n) .icon{top:0;left:0}
.main-timeline6 .timeline:nth-child(4n) .content-inner:after,.main-timeline6 .timeline:nth-child(4n) .content-inner:before{border-left-color:#2fc5b9}
}



</style>

<br>

<p style="font-size: 30px;color:#2b6db4;text-align: center;"><b>Faq</b></p>
<hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

<br>
<div style="background-image: url('img/kpimg3.png');  background-repeat: no-repeat;
  background-size: auto;">
<div class="container">
  <div class="col-lg-12 " >
  <div >

   <div id="accordion">
     <div class="card">
       <div class="card-header" id="headingOne">
         <h5 class="mb-0">
           <button class="btn btn-outline-primary" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
             Fast Delivery
           </button>
           <i class="fa fa-plus btn btn-outline-primary" style="float:right;" aria-hidden="true" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne" aria-hidden="true"></i>
          </h5>
       </div>

       <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
         <div class="card-body">

           <p  align="justify">Fast Delivery </p>

         </div>
       </div>
     </div>
     <div class="card">
       <div class="card-header" id="headingTwo">
         <h5 class="mb-0">
           <button class="btn btn-outline-primary collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
             User Friendly
           </button>
           <i class="fa fa-plus btn btn-outline-primary collapsed" style="float:right;" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" aria-hidden="true"></i>
         </h5>
       </div>
       <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
         <div class="card-body">

           <p>User Friendly</p>
         </div>
       </div>
     </div>
     <div class="card">
       <div class="card-header" id="headingThree">
         <h5 class="mb-0">
           <button class="btn btn-outline-primary collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
             Based On User Requirement
           </button>
           <i class="fa fa-plus btn btn-outline-primary collapsed" style="float:right;" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree" aria-hidden="true"></i>
         </h5>
       </div>
       <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
         <div class="card-body">

             <p>Based On User Requirement</p>
         </div>
       </div>
     </div>
   </div>

  </div>

  </div>
  </div>
</div>
<br/>


@endsection
