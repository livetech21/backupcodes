@extends('admin/layoutinner')
@section('page_title','Livetech-Dashboard')

@section('container')


@if(session()->has('message'))
    <div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
        {{session('message')}}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
    @endif
    <h1 class="mb10">Gallery</h1>
    <a href="{{url('admin/gallery/add-gallery')}}">
        <button type="button" class="btn btn-primary">
            Add Gallery
        </button>
    </a>
    <a href="{{url('admin/dashboard/')}}">
        <button type="button" class="btn btn-primary">
            Dashboard
        </button>
    </a>
    <div class="row m-t-30">
        <div class="col-md-12">
            <!-- DATA TABLE-->
            <div class="table-responsive m-b-40">
                <table class="table table-secondary">
                    <thead>
                        <tr>
                        <th>Sr.</th>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Description</th>

                            <th>Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($data as $list)
                        <tr>
                        <td>{{$list->id}}</td>
                            <td>{{$list->name}}</td>
                            <td>{{$list->type}}</td>
                            <td>{{$list->des}}</td>


                            <td>
                            <!-- <img src="{{asset('storage/testimonials/'.$list->photo) }}" style="width: 100px; height: 100px;"> -->
                            <img src="{{asset('uploads/gallery/'.$list->photo)}}" style="width: 100px; height: 100px;">
                          </td>

                            <td>
                                <a href="{{url('admin/gallery/edit/')}}/{{$list->id}}"><button type="button" class="btn btn-success"><i class="fa fa-edit" style="color:white;">&nbsp;&nbsp; Edit</i> </button></a>

                                <a href="{{url('admin/gallery/delete/')}}/{{$list->id}}"><button type="button" class="btn btn-danger"><i class="fa fa-trash" style="color:white;">&nbsp;&nbsp; Delete</i> </button></a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <!-- END DATA TABLE-->
        </div>
    </div>


@endsection
