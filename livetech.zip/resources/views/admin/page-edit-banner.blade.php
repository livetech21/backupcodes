@extends('admin/layoutinner')
@section('container')



<h1 class="mb10">Update Banner Image</h1>
    <a href="{{url('admin/pages')}}">
        <button type="button" class="btn btn-primary">
            Go Back
        </button>
    </a>
    <br><br>
    @if(session()->has('message'))
    <div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
        {{session('message')}}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
    @endif
    <div class="row m-t-30">
        <div class="col-md-12">
        <div class="row">
                <div class="col-lg-10">
                    <div class="card">
                        <div class="card-body">
                            <form action="{{ url('/admin/pages/updatebanner/'.$data['0']->id ) }}" method="post" enctype="multipart/form-data">
                                @csrf
                                <div class="form-group">
                                    <div class="row">

                                        <div class="col-lg-12">
                                            <label for="color" class="control-label mb-1">Banner Image</label>
                                            <input id="image1"  name="image1" type="file" class="form-control" aria-required="true" aria-invalid="false" required>
                                            @error('image1')

                                                <p style="color:red;">{{$message}}</p>

                                            @enderror
                                             <img src="{{asset('uploads/pages/bannerimg/'.$data['0']->photo1) }}" style="width: 200px; height: 100px;margin:10px;">
                                        </div>



                                    </div>
                                </div>

                                <div>
                                    <center><button id="payment-button" type="submit" class="btn btn-sm btn-primary">
                                        Update
                                    </button>
</center>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>

@endsection
