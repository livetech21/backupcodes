<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
    <meta http-equiv="Expires" content="0" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/homecss.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/blogcss.css')); ?>">

    <script src="<?php echo e(asset('js/headercss.js ')); ?>"></script>
    <script src="<?php echo e(asset('js/slide.js ')); ?>"></script>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


    <title><?php echo $__env->yieldContent('page_title'); ?></title>

</head>

<body>

<style>

    .ah:hover{
  background-color : #2fc5b9;
  color:white;
}
.bb{
    text-transform:uppercase;
    color:#2b6db4;
}
.kkg{
    border-bottom: 1px solid #e0e0e0;
    transition: all .5s ease;
    text-transform:uppercase;
    font-size:200;
}

.subnav{
    width: 100%;
    background-color: #5353ad;
    position: fixed;
    z-index:2;
    top:0;
 }

 .navbar-light .navbar-toggler{
    color: #2b6db4;
    border: 2px solid #2b6db4;
}



    </style>


<style>
@media  all and (min-width: 480px) {
    .deskContent {display:block;}
    .phoneContent {display:none;}

.dropdown-menu{
    min-width:270px;
    transition: all 0.9s ease-in;
    border-bottom:3px solid #2b6db4;
}

.nav-link{
    /* border-right: 1px solid #e0e0e0; */
    border-top: 1px solid #2fc5b9;
    border-bottom: 1px solid #2b6db4;
    transition: all .5s ease;
}


.gg:hover{

    border-left:2px solid #2fc5b9;
    border-right:2px solid #2b6db4;
    border-radius:10px;
    color:white;
    transition: all 0.3sec ease;
}

.cc-img{
    height:300px;
}

  }

  @media  all and (max-width: 479px) {
    .deskContent {display:none;}
    .phoneContent {display:block;}

    .cc-img{
    height:auto;
}

  }



</style>


<script>


    </script>
<header>

<div >

<div class="col-lg-12 col-md-12 col-xs-12">
<div class="row" style="background-color:#2fc5b9;padding:5px;">

<div class="col-lg-6 col-md-6 col-xs-12">

<i class="fa fa-envelope" style="color:white;letter-spacing:1px;">&nbsp;<b>info@livetechservices.com</b></i>
  </div>
  <div class="col-lg-6 col-md-6 col-xs-12">
  <i class="fa fa-phone" style="color:white;float:right;margin-top:5px;letter-spacing:1px;">&nbsp;<b>+91 9643824091</b></i>
</div>

</div>
</div>


<nav class="navbar navbar-expand-lg navbar-light bg-light">
<a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img class="img-fluid" src="<?php echo e(asset('images/livetech.png')); ?>"  style="height:80px;width:100%;" alt="Immense" /></a>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="fa fa-bars" style="font-size:25px;"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav" style="margin-left:auto;">
      <li class="nav-item active gg">
        <a class="nav-link" href="<?php echo e(url('/')); ?>"><b class="bb">Home </b><span class="sr-only">(current)</span></a>
      </li>

      <li class="nav-item dropdown gg">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <b class="bb" >Website Designing</b>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails/Web-Design-Services')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp; Web Design Services</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails/Mobile-Website-Designing')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp; Mobile Website Designing</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails/Ecommerce web-Designing')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp; Ecommerce web-Designing</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails/Ecommerce web-Development')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp; Ecommerce web-Development</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails/Website Re-Designing')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp; Website Re-Designing</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails/PWA Development')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp; PWA Development</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails/Content Management System')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp; Content Management System</a>
          <a class="dropdown-item ah" style="color:#2b6db4;" href="<?php echo e(url('pagedetails/PSD To XHTML')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp; PSD To XHTML</a>

        </div>
      </li>
      <li class="nav-item dropdown gg">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <b class="bb">Digital Marketing</b>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails2/SEO')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;SEO</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails2/Enterprise SEO')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Enterprise SEO</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails2/Local SEO')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Local SEO</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails2/Ecommerce SEO')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Ecommerce SEO</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails2/Video SEO')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Video SEO</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails2/Google Recovery Services')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Google Recovery Services</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails2/SEO Reseller Services')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;SEO Reseller Services</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails2/Multi Lingual SEO')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Multi Lingual SEO</a>
          <a class="dropdown-item ah" style="color:#2b6db4;" href="<?php echo e(url('pagedetails2/Web Analytics')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Web Analytics</a>


        </div>
      </li>
      <li class="nav-item dropdown gg">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <b class="bb">ERP</b>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails3/ERP')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;ERP</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails3/Retail ERP')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Retail ERP</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails3/Manufacturing ERP')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Manufacturing ERP</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails3/ERP Web-Development')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;ERP Web-Development</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails3/ERP Web-SEO')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;ERP Web-SEO</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails3/ERP For Financial Services')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;ERP For Financial Services</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails3/Automotive ERP')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Automotive ERP</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails3/Furniture ERP')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Furniture ERP</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails3/Construction ERP')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Construction ERP</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails3/ERP For Service Industry')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;ERP For Service Industry</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails3/Real Estate ERP')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Real Estate ERP</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails3/Media and Advertising')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Media & Advertising</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails3/Banking ERP')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Banking ERP</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails3/Healthcare ERP')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Healthcare ERP</a>
          <a class="dropdown-item ah" style="color:#2b6db4;" href="<?php echo e(url('pagedetails3/Hospitality ERP')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Hospitality ERP</a>

        </div>
      </li>
      <li class="nav-item dropdown gg">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <b class="bb">CRM</b>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails4/Manfacturing CRM')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Manufaturing CRM</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails4/CRM For Financial Services')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;CRM-Financial</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails4/Wealth CRM')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Wealth CRM</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails4/Retail CRM')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Retail CRM</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails4/Real Estate CRM')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Real Estate CRM</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails4/Construction CRM')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Construction CRM</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails4/Banking CRM')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Banking CRM</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails4/Healthcare CRM')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Healthcare CRM</a>
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails4/Hospitality CRM')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;Hospitality CRM</a>
          <a class="dropdown-item ah" style="color:#2b6db4;" href="<?php echo e(url('pagedetails4/E-commerce CRM')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;E-commerce CRM</a>

        </div>
      </li>
      <li class="nav-item dropdown gg">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <b class="bb">Ecommerce-Solutions</b>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item ah kkg" style="color:#2b6db4;" href="<?php echo e(url('pagedetails5/E-Commerce Web-Designing')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;E-Commerce Web-Designing</a>
          <a class="dropdown-item ah" style="color:#2b6db4;" href="<?php echo e(url('pagedetails5/E-Commerce Development')); ?>"><i class="fa fa-edit"></i>&nbsp;&nbsp;E-Commerce Development</a>

        </div>
      </li>
      <!-- <li class="nav-item">
        <a class="nav-link disabled" href="#">Disabled</a>
      </li> -->

      <li class="nav-item gg">
        <a class="nav-link" href="<?php echo e(url('/page6/Graphic')); ?>"><b class="bb">Graphic Design</b></a>
      </li>
      <li class="nav-item gg">
        <a class="nav-link" href="<?php echo e(url('/contact')); ?>"><b class="bb">Contact Us</b></a>
      </li>
    </ul>

  </div>

</nav>


<!-- <hr  style="color: #2b6db4; margin-top: 0; margin-bottom: 0; border-bottom: 7px solid #2b6db4;">
</hr> -->

<div class="col-lg-12 col-md-12 col-xs-12">
<div class="row" style="background-color:#2b6db4;padding:5px;">

<div class="col-6">

  </div>
  <div class="col-6">
  <i class='fa fa-facebook icon' style='color:white;float:right;padding:5px;'></i> &nbsp;
  <i class='fa fa-twitter icon' style='color:white;float:right;padding:5px;'></i> &nbsp;
  <i class='fa fa-linkedin icon' style='color:white;float:right;padding:5px;'></i> &nbsp;
  <i class='fa fa-youtube icon' style='color:white;float:right;padding:5px;'></i>&nbsp;

</div>

</div>
</div>

</div>

</header>


<?php $__env->startSection('container'); ?>
        <?php echo $__env->yieldSection(); ?>



        <div style="background: linear-gradient(5deg, #2b6db4 0%, #2b6db4 25%, transparent 26%), linear-gradient(-5deg, #2b6db4 0%, #2b6db4 24%, transparent 25%);height:100px;width:100%;">

</div>
<footer>
<style>
  .hero-image {
    /* Use "linear-gradient" to add a darken background effect to the image (photographer.jpg). This will make the text easier to read */
    background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("photographer.jpg");

    /* Set a specific height */
    height: 100%;

    /* Position and center the image to scale nicely on all screens */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    position: relative;
  }
  .home-newsletter {
    padding: 30px 0;
    background: #2b6db4;
    }

    .home-newsletter .single {
    max-width: auto;
    margin: 0 auto;
    text-align: center;
    position: relative;
    z-index: 2; }
    .home-newsletter .single h2 {
    font-size: 22px;
    color: white;
    text-transform: uppercase;
    margin-bottom: auto; }
    .home-newsletter .single .form-control {
    height: 50px;
    background: rgba(255, 255, 255, 0.6);
    border-color: transparent;
    border-radius: 20px 0 0 20px; }
    .home-newsletter .single .form-control:focus {
    box-shadow: none;
    border-color: #243c4f; }
    .home-newsletter .single .btn {
    min-height: 50px;
    border-radius: 0 20px 20px 0;
    background: #243c4f;
    color: #fff;
    }

</style>

<section class="home-newsletter" style="background-image: url('imgnew/sg.jpg');">
  <div class="container">
  <div class="row">


    <div class="col-lg-6 col-sm-6">


      <div class="single">
        <h2 style="margin-top:15px;">Subscribe to our Newsletter</h2>

      </div>

    </div>

    <div class="col-lg-6 col-sm-6">


    <div class="single">

    <div class="input-group">
           <input type="email" class="form-control" placeholder="Enter your email">
           <span class="input-group-btn">
           <button class="btn btn-theme" type="submit">Subscribe</button>
           </span>
            </div>
    </div>


  </div>
  </div>
  </div>
  </section>
<hr style="color:white;margin-top: 0;
margin-bottom: 0;">

<div class="container-fluid" >
    <div class="row" style="background-color: #2b6db4;">


      <div class="col-lg-3">
            <p style="margin-top:20px;color:white;font-size: 18px;text-align: center;"><b>Abut Company</b></p>
            <hr style="background-color: white;width:30%">
            <ul id="kkm" style="list-style: none;color:white">
               <p align="justify">LTS is IT Company and we are dealing with Web Development, mobile application, Big Data Solution, Digital Marketing, Web Portal Development, ERP developemnt, Software Development and IT Services.</p>
            </ul>
        </div>
        <div class="col-lg-3">
            <p style="margin-top:20px;color:white;font-size: 20px;text-align: center;"><b>Quick Links</b></p>
            <hr style="background-color: white;width:30%">
            <ul style="list-style: none;color:white;text-align: center;margin-left:-30px;">
              <a href="/"><li style="color:white;line-height: 0.3rem;">Home</li></a>
                <br>
                <a href="/about">
                    <li style="color:white;line-height: 0.3rem;">About Us</li>
                </a>
                <br>
                <a href="/gallery">
                    <li style="color:white;line-height: 0.3rem;">Portfolio</li>
                </a>

              <br>
                <a href="/media">
                  <li style="color:white;line-height: 0.3rem;">News and Media</li>
              </a>
              <br>

              <a href="/casestudy">
                  <li style="color:white;line-height: 0.3rem;">Case Study</li>
              </a>
              <br>
                <a href="/blog">
                  <li style="color:white;line-height: 0.3rem;">Blogs</li>
              </a>


            </ul>
        </div>
        <div class="col-lg-3">
          <p style="margin-top:20px;color:white;font-size: 18px;text-align: center;"><b>Quick Links</b></p>
          <hr style="background-color: white;width:30%">
          <ul style="list-style: none;color:white;text-align: center;margin-left:-30px;">

                <a href="/services">
                  <li style="color:white;line-height: 0.3rem;">Services</li>
              </a>

              <br>
              <a href="/video-editing">
                  <li style="color:white;line-height: 0.3rem;">Video Editing</li>
              </a>
              <br>

              <a href="/vision-and-mission">
                  <li style="color:white;line-height: 0.3rem;">Vision And Mission</li>
              </a>
              <br>

              <a href="/career">
                  <li style="color:white;line-height: 0.3rem;">Career</li>
              </a>
              <br>
                <a href="/contact-us">
                    <li style="color:white;line-height: 0.3rem;">Contact</li>
                </a>

          </ul>
      </div>
        <div class="col-lg-3">
          <p style="margin-top:20px;color:white;font-size: 18px;text-align: center;"><b>CONTACT INFO</b></p>
          <hr style="background-color: white;width:30%">
          <ul id="kkm" style="list-style: none;color:white">
              <li style="line-height: 1rem;"><i class="fa fa-map-marker"></i>&nbsp; D-175, Sector 49, Noida, GB Nagar (U.P.)</li>
              <br>
              <li style="line-height: 0.3rem;"><i class="fa fa-phone"></i>&nbsp;+91-9643824091 </li>
              <br>
              <li style="line-height: 0.3rem;"><i class="fa fa-envelope"></i>&nbsp;info@livetechservices.com</li>


          </ul>

    </div>

<div class="col-lg-12">
  <div id="accordion">
    <div class="card" style="background-color:transparent;">
      <div class="card-header" id="headingTwoo">
        <h5 class="mb-0">
          <a class="collapsed" data-toggle="collapse" data-target="#collapseff" aria-expanded="false" aria-controls="collapseff" style="color:white;font-size:18px;">
            Quick Directory Links
          </a>
          <i class="fa fa-arrow-down btn btn-outline-primary collapsed" style="float:right;color:white;" data-toggle="collapse" data-target="#collapseff" aria-expanded="false" aria-controls="collapseff" aria-hidden="true"></i>
        </h5>
      </div>
      <div id="collapseff" style="padding:0.2px;" class="collapse" aria-labelledby="headingTwoo" data-parent="#accordion">
        <div class="card-body">

          <div class="row">

          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
            <ul class="list-unstyled mb-0">
              <li>
                <a routerLink="/6lr61-9v-alkaline-battery" class="text-white">IT</a>
              </li>
              <li>
                <a routerLink="/6lr61-9v-alkaline-battery" class="text-white">Software solutions</a>
              </li>

            </ul>
          </div>
          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">

            <ul class="list-unstyled mb-0">
              <li>
                <a routerLink="/c-lr14-1.5v-alkaline-battery" class="text-white">CRM</a>
              </li>
              <li>
                <a routerLink="/c-lr14-1.5v-alkaline-battery" class="text-white">Digital Marketing</a>
              </li>

            </ul>
          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">

            <ul class="list-unstyled mb-0">
              <li>
                <a routerLink="/lr6-aa-Ultra-Digital-Battery" class="text-white">SMO</a>
              </li>
              <li>
                <a routerLink="/lr6-aa-Ultra-Digital-Battery" class="text-white">ERP</a>
              </li>


            </ul>


          </div>

          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">

            <ul class="list-unstyled mb-0">
              <li>
                <a routerLink="/ultra-digital-batteries" class="text-white">Testing Solutions</a>
              </li>
              <li>
                <a routerLink="/alkaline-batteries" class="text-white">Technology</a>
              </li>



            </ul>


          </div>

</div>

        </div>
      </div>
    </div>
    </div>

</div>

    <div class="col-lg-12">

      <hr style="background-color: white;">
      <p style="color:white;text-align:center">© Copyrights 2022 All Rights Reserved.</p>

  </div>

</div>


</footer>

</body>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

</html>
<?php /**PATH D:\laravel projects\livetech\resources\views/front/layout.blade.php ENDPATH**/ ?>