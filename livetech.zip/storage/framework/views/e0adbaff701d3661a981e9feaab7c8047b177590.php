<?php $__env->startSection('page_title','Livetech-News-And-Media'); ?>

<?php $__env->startSection('container'); ?>

<style>
      .card:hover {
      box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
      transition: 0.3s;
      border-left:2px solid #2fc5b9;
      border-right:2px solid #2b6db4;
      border-radius:10px;
      padding:none;
  }
    </style>

<img class="img-fluid" src="<?php echo e(asset('img/news.png')); ?>" alt="livetch"/>

<div class="album py-5 bg-light">

  <div >
  <div class="container" style="background-image: url('<?php echo e(asset('img/bgg3.png')); ?>');
  background-size: auto;">
    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b>News And Media</b></p>
<hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">


<div class="row">
    <div class="col-lg-6 col-xs-12">
        <div class="card" style="padding:20px;">
            <h3>Latest news</h3>
            <hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

            <p align="justify">Livetech</p>
            <p align="justify">Livetech</p>
            <p align="justify">Livetech</p>

        </div>
    </div>
    <div class="col-lg-6 col-xs-12">
    <img class="img-fluid img-flip" src="<?php echo e(asset('img/bgg1.png')); ?>" alt="livetch"/>
    </div>
</div>



    <div class="row" style="margin-top:70px;">



      <div class="col-md-4">
        <div class="card mb-4 box-shadow" style="padding:15px;">
          <a href="<?php echo e(asset('img/icons/graphic.png')); ?>" ><img class="card-img-top" src="<?php echo e(asset('img/icons/graphic.png')); ?>" alt="livetech"></a>
          <div class="card-body">
            <p class="card-text">Livetech</p>
            <div class="d-flex justify-content-between align-items-center">
              <div class="btn-group">
              <a href="#" > <button type="button" class="btn btn-sm btn-outline-primary">See&nbsp;<i class="fa fa-eye"></i></button></a>

              </div>

            </div>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card mb-4 box-shadow" style="padding:15px;">
          <a href="<?php echo e(asset('img/icons/graphic.png')); ?>" ><img class="card-img-top" src="<?php echo e(asset('img/icons/graphic.png')); ?>" alt="livetech"></a>
          <div class="card-body">
            <p class="card-text">Livetech</p>
            <div class="d-flex justify-content-between align-items-center">
              <div class="btn-group">
              <a href="#" > <button type="button" class="btn btn-sm btn-outline-primary">See&nbsp;<i class="fa fa-eye"></i></button></a>

              </div>

            </div>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card mb-4 box-shadow" style="padding:15px;">
          <a href="<?php echo e(asset('img/icons/graphic.png')); ?>" ><img class="card-img-top" src="<?php echo e(asset('img/icons/graphic.png')); ?>" alt="livetech"></a>
          <div class="card-body">
            <p class="card-text">Livetech</p>
            <div class="d-flex justify-content-between align-items-center">
              <div class="btn-group">
              <a href="#" > <button type="button" class="btn btn-sm btn-outline-primary">See&nbsp;<i class="fa fa-eye"></i></button></a>

              </div>

            </div>
          </div>
        </div>
      </div>




    </div>
  </div>
</div>

</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('front/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel projects\livetech\resources\views/front/media.blade.php ENDPATH**/ ?>