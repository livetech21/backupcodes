<?php $__env->startSection('page_title','Livetech-Case-Studies'); ?>

<?php $__env->startSection('container'); ?>

<style>
    .card{
        padding:15px;
    }
      .card:hover {
      box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
      transition: 0.3s;
      border-left:2px solid #2fc5b9;
      border-right:2px solid #2b6db4;
      border-radius:10px;
      padding:none;
  }
    </style>

<img class="img-fluid" src="<?php echo e(asset('img/gallery.png')); ?>" alt="livetch"/>

<div class="album py-5 bg-light">

  <div >
  <div class="container" style="background-image: url('<?php echo e(asset('img/bgg3.png')); ?>');
  background-size: auto;">
    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b>Case Studies</b></p>
<hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">


<div class="row">
    <div class="col-lg-6 col-xs-12">
        <div class="card" style="padding:20px;">
            <h3>Heighlights</h3>
            <hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

            <p align="justify">nbcsdn cb dx cbndx cb xdbv sc.</p>
            <p align="justify">nbcsdn cb dx cbndx cb xdbv sc.</p>
            <p align="justify">nbcsdn cb dx cbndx cb xdbv sc.</p>

        </div>
    </div>
    <div class="col-lg-6 col-xs-12">
    <img class="img-fluid img-flip" src="<?php echo e(asset('img/bgg1.png')); ?>" alt="livetch"/>
    </div>
</div>



    <div class="row" style="margin-top:70px;">




    <div class="col-lg-4 col-md-4 col-xs-12">
        <div class="card">
        <div style="background-image: url('img/bgg5.png');  background-repeat: no-repeat;background-size: auto;">
        <img class="img-fluid img-flip" src='img/icons/case.png' alt="livetech " style="display: block;margin-left: auto;margin-right: auto;" />
<br>
        <h5 style="color:#2b6db4;text-align:center;">Case Study 1</h5>
        <p align="justify">Hdsjcbs xc vfdn xvndf v dn nm.</p>
        <p><a class="btn btn-outline-primary" href="/casestudydetails" role="button">Explore More &raquo; &nbsp;&nbsp; <i class="fa fa-arrow-right-long;"></i></a></p>
</div>
    </div>
    </div>
    <div class="col-lg-4 col-md-4 col-xs-12">
        <div class="card">
        <div style="background-image: url('img/bgg5.png');  background-repeat: no-repeat;background-size: auto;">
        <img class="img-fluid img-flip" src='img/icons/case.png' alt="livetech " style="display: block;margin-left: auto;margin-right: auto;" />
<br>
        <h5 style="color:#2b6db4;text-align:center;">Case Study 1</h5>
        <p align="justify">Hdsjcbs xc vfdn xvndf v dn nm.</p>
        <p><a class="btn btn-outline-primary" href="/casestudydetails" role="button">Explore More &raquo; &nbsp;&nbsp; <i class="fa fa-arrow-right-long;"></i></a></p>
</div>
    </div>
    </div>

    <div class="col-lg-4 col-md-4 col-xs-12">
        <div class="card">
        <div style="background-image: url('img/bgg5.png');  background-repeat: no-repeat;background-size: auto;">
        <img class="img-fluid img-flip" src='img/icons/case.png' alt="livetech " style="display: block;margin-left: auto;margin-right: auto;" />
<br>
        <h5 style="color:#2b6db4;text-align:center;">Case Study 1</h5>
        <p align="justify">Hdsjcbs xc vfdn xvndf v dn nm.</p>
        <p><a class="btn btn-outline-primary" href="/casestudydetails" role="button">Explore More &raquo; &nbsp;&nbsp; <i class="fa fa-arrow-right-long;"></i></a></p>
</div>
    </div>
    </div>





    </div>
  </div>
</div>

</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('front/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel projects\livetech\resources\views/front/casestudies.blade.php ENDPATH**/ ?>