<?php $__env->startSection('page_title','Livetech-Mobile-App-Design'); ?>

<?php $__env->startSection('container'); ?>

<style>
@media  all and (min-width: 480px) {
    .deskContent {display:block;}
    .phoneContent {display:none;}
  }

  @media  all and (max-width: 479px) {
    .deskContent {display:none;}
    .phoneContent {display:block;}
  }
  </style>



<style>
    .card {
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
        transition: 0.3s;
    }

    .card:hover {
      box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
      transition: 0.3s;
      border-left:2px solid #2fc5b9;
      border-right:2px solid #2b6db4;
      border-radius:10px;
  }

    .card-counter{
      box-shadow: 2px 2px 10px #DADADA;
      margin: 5px;
      padding: 20px 10px;
      background-color: #fff;
      height: 100px;
      border-radius: 5px;
      transition: .3s linear all;
    }

    .card-counter:hover{
      box-shadow: 4px 4px 20px #DADADA;
      transition: .3s linear all;
    }

    .card-counter.primary{
      background-color: #007bff;
      color: #FFF;
    }

    .card-counter.danger{
      background-color: #ef5350;
      color: #FFF;
    }

    .card-counter.success{
      background-color: #66bb6a;
      color: #FFF;
    }

    .card-counter.info{
      background-color: #26c6da;
      color: #FFF;
    }

    .card-counter i{
      font-size: 5em;
      opacity: 0.2;
    }

    .card-counter .count-numbers{
      position: absolute;
      right: 35px;
      top: 20px;
      font-size: 32px;
      display: block;
    }

    .card-counter .count-name{
      position: absolute;
      right: 35px;
      top: 65px;
      font-style: italic;
      text-transform: capitalize;
      opacity: 0.5;
      display: block;
      font-size: 18px;
    }

</style>
<?php $__currentLoopData = $page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="deskContent">
<img class="img-fluid carasual-hh" src="<?php echo e(asset('uploads/pages/bannerimg/'.$list->photo1)); ?>" alt="Immense" style="border-bottom:2px solid #e0e0e0;" />
</div>

<div class="phoneContent">
<img class="img-fluid carasual-hh" src="<?php echo e(asset('uploads/pages/bannerimg/'.$list->photo1)); ?>" alt="Immense" style="border-bottom:2px solid #e0e0e0;" />
</div>

<div >
<div class='container'>

        <div class='col-lg-12' style="background-image: url( '<?php echo e(asset('img/bgg8.png')); ?>' );">
            <br> <br>
            <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b><?php echo e($list->title); ?></b></p>
            <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">


        </div>
        <div class='row'>
            <div class='col-lg-6 col-xs-12'>
                <br><br>
                <div class="card" style='width:auto'>
                  <div class="card-body">
                    <img src="<?php echo e(asset('uploads/pages/'.$list->photo)); ?>" class="img-fluid img-flip" alt="livetech"/></div>

                </div>
                </div>
            <div class='col-lg-6 col-xs-12' style="margin-top:-60px;">
                <br><br><br><br>

                <div class='card' style='border: 2px solid  #2b6db4 ;'>
                    <div class='card-body'>
                        <p style='color: #2b6db4;;font-family: "open sans", sans-serif;font-size: 15px;'><b><?php echo e($list->des); ?></b></p>
                        <!-- <ul style='color:#2fc5b9;;font-family: "open sans", sans-serif;font-size: 15px;line-height: 35px;margin-left: -35px;list-style:
                            none;'>

                         <b>   <li> <i style="font-size:24px" class="fa">&#xf105;</i> &nbsp; Evolution of digital marketing & why it is the buzzword</li>
                            <li> <i style="font-size:24px" class="fa">&#xf105;</i> &nbsp; Evolution of digital marketing & why it is the buzzword</li>
                            <li> <i style="font-size:24px" class="fa">&#xf105;</i> &nbsp; Evolution of digital marketing & why it is the buzzword</li>
                            <li> <i style="font-size:24px" class="fa">&#xf105;</i> &nbsp; Evolution of digital marketing & why it is the buzzword</li>
                        </b>

                        </ul> -->


                    </div>
                </div>


            </div>
        </div>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<style>
  .hori-timeline .events {
    border-top: 3px solid #e9ecef;
}
.hori-timeline .events .event-list {
    display: block;
    position: relative;
    text-align: center;
    padding-top: 70px;
    margin-right: 0;
}
.hori-timeline .events .event-list:before {
    content: "";
    position: absolute;
    height: 36px;
    border-right: 2px dashed #dee2e6;
    top: 0;
}
.hori-timeline .events .event-list .event-date {
    position: absolute;
    top: 38px;
    left: 0;
    right: 0;
    width: 75px;
    margin: 0 auto;
    border-radius: 4px;
    padding: 2px 4px;
}
@media (min-width: 1140px) {
    .hori-timeline .events .event-list {
        display: inline-block;
        width: 24%;
        padding-top: 45px;
    }
    .hori-timeline .events .event-list .event-date {
        top: -12px;
    }
}
.bg-soft-primary {
    background-color: rgba(64,144,203,.3)!important;
}
.bg-soft-success {
    background-color: rgba(71,189,154,.3)!important;
}
.bg-soft-danger {
    background-color: rgba(231,76,94,.3)!important;
}
.bg-soft-warning {
    background-color: rgba(249,213,112,.3)!important;
}
.card {
    border: none;
    margin-bottom: 24px;
    -webkit-box-shadow: 0 0 13px 0 rgba(236,236,241,.44);
    box-shadow: 0 0 13px 0 rgba(236,236,241,.44);
}
</style>


<style>
  .contact-form{
    background: #fff;
    margin-top: 10%;
    margin-bottom: 5%;
    width: 70%;
}
.contact-form .form-control{
    border-radius:1rem;
}
.contact-image{
    text-align: center;
}
.contact-image img{
    border-radius: 6rem;
    width: 11%;
    margin-top: -3%;
    transform: rotate(29deg);
}
.contact-form form{
    padding: 5%;
}
.contact-form form .row{
    margin-bottom: -7%;
}
.contact-form h3{
    margin-bottom: 8%;
    margin-top: -10%;
    text-align: center;
    color: #0062cc;
}
.contact-form .btnContact {
    width: 100%;
    border: none;
    border-radius: 1rem;
    padding: 1.5%;
    background: #0062cc;
    font-weight: 600;
    color: #fff;
    cursor: pointer;
}
.btnContactSubmit
{
    width: 50%;
    border-radius: 1rem;
    padding: 1.5%;
    color: #fff;
    background-color: #0062cc;
    border: none;
    cursor: pointer;
}
</style>

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" style="color:#067751;">Quick call <i class="fa fa-bullhorn"></i></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="background-image: url('imgnew/bg6.jpg');">
        <div class="container contact-form">
          <div class="contact-image">
              <img src="https://image.ibb.co/kUagtU/rocket_contact.png" alt="rocket_contact"/>
          </div>
          <form method="post">
              <h3>Drop Us a Message</h3>
             <div class="row">
                  <div class="col-lg-12">
                      <div class="form-group">
                          <input type="text" name="txtName" class="form-control" placeholder="Your Name *" value="" />
                      </div>
                      <div class="form-group">
                          <input type="text" name="txtEmail" class="form-control" placeholder="Your Email *" value="" />
                      </div>
                      <div class="form-group">
                          <input type="text" name="txtPhone" class="form-control" placeholder="Your Phone Number *" value="" />
                      </div>

                  </div>
                  <div class="col-lg-12">
                      <div class="form-group">
                          <textarea name="txtMsg" class="form-control" placeholder="Your Message *" style="width: 100%; height: 150px;"></textarea>
                      </div>
                      <div class="form-group">
                        <input type="submit" name="btnSubmit" class="btnContact" value="Send Message" />
                    </div>
                  </div>

              </div>
          </form>
</div>
      </div>

    </div>
  </div>
</div>

<div style="background-image: url( '<?php echo e(asset('img/bgg8.png')); ?>' );">
  <div class="container">
  <div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="card" style="border: 1px solid #888888;box-shadow: 5px 10px #888888;">
                <div class="card-body" style="background-image: url( '<?php echo e(asset('img/bgg7.png')); ?>' );">
                    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b>Our Process</b></p>
                    <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">


                    <div class="hori-timeline" dir="ltr">
                        <ul class="list-inline events">
                            <li class="list-inline-item event-list">
                                <div class="px-4">
                                    <div class="event-date bg-soft-primary text-primary">Step 1</div>
                                    <h5 class="font-size-16" style="color:#2b6db4;">Requirement Gathering</h5>
                                    <p class="text-muted">It will be as simple as occidental in fact it will be Occidental Cambridge friend</p>
                                    <div>
                                      <button type="button" class="btn btn-success" style="background-color:cadetblue;" data-toggle="modal" data-target="#exampleModalCenter">
                                        Contact <i class="fa fa-bullhorn"></i>
                                      </button>
                                    </div>
                                </div>
                            </li>
                            <li class="list-inline-item event-list">
                                <div class="px-4">
                                    <div class="event-date bg-soft-success text-success">Step 2</div>
                                    <h5 class="font-size-16" style="color:#2b6db4;">Documentation and Designning </h5>
                                    <p class="text-muted">Everyone realizes why a new common language one could refuse translators.</p>
                                    <div>
                                      <button type="button" class="btn btn-success" style="background-color:cadetblue;" data-toggle="modal" data-target="#exampleModalCenter">
                                        Contact <i class="fa fa-bullhorn"></i>
                                      </button>
                                    </div>
                                </div>
                            </li>
                            <li class="list-inline-item event-list">
                                <div class="px-4">
                                <div class="event-date bg-soft-primary text-primary">Step 3</div>
                                    <h5 class="font-size-16" style="color:#2b6db4;">Coding</h5>
                                    <p class="text-muted">If several languages coalesce the grammar of the resulting simple and regular</p>
                                    <div>
                                      <button type="button" class="btn btn-success" style="background-color:cadetblue;" data-toggle="modal" data-target="#exampleModalCenter">
                                        Contact <i class="fa fa-bullhorn"></i>
                                      </button>
                                    </div>
                                </div>
                            </li>
                            <li class="list-inline-item event-list">
                                <div class="px-4">
                                <div class="event-date bg-soft-success text-success">Step 4</div>
                                    <h5 class="font-size-16" style="color:#2b6db4;">Database Management</h5>
                                    <p class="text-muted">Languages only differ in their pronunciation and their most common words.</p>
                                    <div>
                                      <button type="button" class="btn btn-success" style="background-color:cadetblue;" data-toggle="modal" data-target="#exampleModalCenter">
                                        Contact <i class="fa fa-bullhorn"></i>
                                      </button>
                                    </div>
                                </div>
                            </li>
</ul>
<br>
                            <ul class="list-inline events">
                            <li class="list-inline-item event-list">
                                <div class="px-4">
                                <div class="event-date bg-soft-primary text-primary">Step 5</div>
                                    <h5 class="font-size-16" style="color:#2b6db4;">QA Engineering</h5>
                                    <p class="text-muted">Languages only differ in their pronunciation and their most common words.</p>
                                    <div>
                                      <button type="button" class="btn btn-success" style="background-color:cadetblue;" data-toggle="modal" data-target="#exampleModalCenter">
                                        Contact <i class="fa fa-bullhorn"></i>
                                      </button>
                                    </div>
                                </div>
                            </li>

                            <li class="list-inline-item event-list">
                                <div class="px-4">
                                <div class="event-date bg-soft-success text-success">Step 6</div>
                                    <h5 class="font-size-16" style="color:#2b6db4;">Debug and Testing</h5>
                                    <p class="text-muted">Languages only differ in their pronunciation and their most common words.</p>
                                    <div>
                                      <button type="button" class="btn btn-success" style="background-color:cadetblue;" data-toggle="modal" data-target="#exampleModalCenter">
                                        Contact <i class="fa fa-bullhorn"></i>
                                      </button>
                                    </div>
                                </div>
                            </li>

                            <li class="list-inline-item event-list">
                                <div class="px-4">
                                <div class="event-date bg-soft-primary text-primary">Step 7</div>
                                    <h5 class="font-size-16" style="color:#2b6db4;">Deployment</h5>
                                    <p class="text-muted">Languages only differ in their pronunciation and their most common words.</p>
                                    <div>
                                      <button type="button" class="btn btn-success" style="background-color:cadetblue;" data-toggle="modal" data-target="#exampleModalCenter">
                                        Contact <i class="fa fa-bullhorn"></i>
                                      </button>
                                    </div>
                                </div>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
            <!-- end card -->
        </div>
    </div>
  </div>
  </div>
  </div>



<br>
<style>
  /* Rounded tabs */

@media (min-width: 576px) {
  .rounded-nav {
    border-radius: 50rem !important;
  }
}

@media (min-width: 576px) {
  .rounded-nav .nav-link {
    border-radius: 50rem !important;
  }
}

/* With arrow tabs */

.with-arrow .nav-link.active {
  position: relative;
}

.with-arrow .nav-link.active::after {
  content: '';
  border-left: 6px solid transparent;
  border-right: 6px solid transparent;
  border-top: 6px solid #2b90d9;
  position: absolute;
  bottom: -6px;
  left: 50%;
  transform: translateX(-50%);
  display: block;
}

/* lined tabs */

.lined .nav-link {
  border: none;
  border-bottom: 3px solid transparent;
}

.lined .nav-link:hover {
  border: none;
  border-bottom: 3px solid transparent;
}

.lined .nav-link.active {
  background: none;
  color: #555;
  border-color: #2fc5b9;
}

/*
*
* ==========================================
* FOR DEMO PURPOSE
* ==========================================
*
*/


.nav-pills .nav-link {
  color: #555;
}
.text-uppercase {
  letter-spacing: 0.1em;
}

.thumb {
  width: 100%;
  height: 300px;
  margin: 70px auto;
  perspective: 1000px;
}

.thumb a {
  display: block;
  width: 100%;
  height: 100%;
  background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)),
  url("<?php echo e(asset('imgnew/test.jpg')); ?>");
  background-size: 0, cover;
  transform-style: preserve-3d;
  transition: all 0.5s;
}

.thumb:hover a {
  transform: rotateX(80deg);
  transform-origin: bottom;
}
.thumb a:after {
  content: '';
  position: absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 36px;
  background: inherit;
  background-size: cover, cover;
  background-position: bottom;
  transform: rotateX(90deg);
  transform-origin: bottom;
}
.thumb a span {
  color: white;
  text-transform: uppercase;
  position: absolute;
  top: 100%;
  left: 0;
  width: 100%;
  font: bold 12px/36px "Open Sans";
  text-align: center;
  transform: rotateX(-89.99deg);
  transform-origin: top;
  z-index: 1;
}
.thumb a:before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  box-shadow: 0 0 100px 50px rgba(0, 0, 0, 0.5);
  transition: all 0.5s;
  opacity: 0.15;
  transform: rotateX(95deg) translateZ(-80px) scale(0.75);
  transform-origin: bottom;
}

.thumb:hover a:before {
  opacity: 1;
  box-shadow: 0 0 25px 25px rgba(0, 0, 0, 0.5);
  transform: rotateX(0) translateZ(-60px) scale(0.85);
}


</style>


<div class="thumb">
  <a href="#">
      <span>Welcome to the Livetech</span>
  </a>
</div>


<div style="padding:20px;">
<div class="row">

  <div class="col-lg-7 col-md-7 col-xs-12">


  <p style="margin-top:20px;font-size: 30px;color:#2b6db4;text-align: center;"><b>Stages of Mobile App Design Process</b></p>
          <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">


<div class="card">

<div style="padding:15px;background-image: url('<?php echo e(asset('img/bgg4.png')); ?>');  background-repeat: no-repeat;
  background-size: auto;" >
<h4> <b style="color:#2b6db4;font-weight:600;"> 1. Confirming On The Idea </b> </h4>

<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="<?php echo e(asset('img/icons/downarrow.png')); ?>" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>

<p align="justify">
Before planning to proceed, you need to answer the following questions to make sure that you are not marrying the wrong idea, and the idea is worth investing time and effort.
</p>
</div>
<hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

<div style="padding:15px;background-image: url('<?php echo e(asset('img/bgg4.png')); ?>');  background-repeat: no-repeat;
  background-size: auto;">
<h4> <b style="color:#2b6db4;font-weight:600;"> 2. Market Research </b> </h4>
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="<?php echo e(asset('img/icons/downarrow.png')); ?>" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>
<p align="justify">
Now is the time to do the most important part of your journey. Market research shows you the real demand or interest of the market; accordingly, you can modify your idea, and the research can give you a clear list of requirements that can help you prioritize the work.
</p>
</div>
<hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

<div style="padding:15px;background-image: url('<?php echo e(asset('img/bgg4.png')); ?>');  background-repeat: no-repeat;
  background-size: auto;">
<h4> <b style="color:#2b6db4;font-weight:600;"> 3. Build Your App's Wireframe </b> </h4>
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="<?php echo e(asset('img/icons/downarrow.png')); ?>" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>
<p align="justify">
Once your idea list is ready, it’s time to put a shape to your idea- Wireframes. You can consider a wireframe as a blueprint of your application. It will display the design of your app and functionality. Also, it will help you understand the look and the work of the application.
</p>
</div>
<hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

<div style="padding:15px;background-image: url('<?php echo e(asset('img/bgg4.png')); ?>');  background-repeat: no-repeat;
  background-size: auto;">
<h4><b style="color:#2b6db4;font-weight:600;"> 4. Platform Choice </b></h4>
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="<?php echo e(asset('img/icons/downarrow.png')); ?>" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>
<p align="justify">
Now we are going to help you make the right decision among all the platforms of mobile app development phases.Three options are available in the sector of development.Native App,Cross-Platform App/ Hybrid App,HTML5 Web App.
</p>
</div>
<hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

<div style="padding:15px;background-image: url('<?php echo e(asset('img/bgg4.png')); ?>');  background-repeat: no-repeat;
  background-size: auto;">
<h4> <b style="color:#2b6db4;font-weight:600;"> 5. Development </b></h4>
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="<?php echo e(asset('img/icons/downarrow.png')); ?>" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>
<p align="justify">
One development project would require programming and configuring the development environment. Usually, there are three aspects of any app- back-end, APIs, and the app front-end. Development is usually done in stages and you can expect your developer to provide interim builds that you will be able to run on your device itself.
</p>
</div>
<hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

<div style="padding:15px;background-image: url('<?php echo e(asset('img/bgg4.png')); ?>');  background-repeat: no-repeat;
  background-size: auto;">
<h4> <b style="color:#2b6db4;font-weight:600;"> 6. Test Your App And Improve </b></h4>
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="<?php echo e(asset('img/icons/downarrow.png')); ?>" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>
<p align="justify">
Running a code review process during development helps in making sure that there are no major bugs left at the end to solve
</p>
</div>
<hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

<div style="padding:15px;background-image: url('<?php echo e(asset('img/bgg4.png')); ?>');  background-repeat: no-repeat;
  background-size: auto;">
<h4> <b style="color:#2b6db4;font-weight:600;"> 7. Launch A Beta Version Of Your App  </b></h4>
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="<?php echo e(asset('img/icons/downarrow.png')); ?>" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>
<p align="justify">
A beta version of any application can attract early adopters, which is an important step in taking your mobile app mainstream. Early adopters provide a lot of beneficial feedback about your application’s pros and cons. And their experience and rating can help you to understand the acceptance of the app and the demand as well. This type of word-of-mouth marketing for your mobile app will bolster its reputation, and help the admin to acquire even more users.
</p>
</div>
<hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

<div style="padding:15px;background-image: url('<?php echo e(asset('img/bgg4.png')); ?>');  background-repeat: no-repeat;
  background-size: auto;">
<h4> <b style="color:#2b6db4;font-weight:600;"> 8. Launching Your App </b></h4>
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="<?php echo e(asset('img/icons/downarrow.png')); ?>" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>
<p align="justify">
You have designed the structure, tested, and developed your application. Now it is time to launch it in the Google Play Store or Apple store.
</p>
</div>
<hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

<div style="padding:15px;background-image: url('<?php echo e(asset('img/bgg4.png')); ?>');  background-repeat: no-repeat;
  background-size: auto;">
<h4> <b style="color:#2b6db4;font-weight:600;"> 9.  Post Launch Activity </b></h4>
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img src="<?php echo e(asset('img/icons/downarrow.png')); ?>" style="height:margin:5px;50px;width:50px;" class="img-fluid img-flip" alt="livetech"/>
</div>
<p align="justify">
After launching your mobile app, the next and crucial step is marketing it. If people don’t get to know about your app, then there is no chance of downloading it. To spread your app and convince people to explore it, consider making attractive and informative videos that can show your app’s functionality. And do not forget the potential of social media, use all digital platforms to reach every corner of the world. It will deliver people a glimpse of your app and highlight the key features that can simplify the need for life.
</p>
</div>


</div>


  </div>



  <div class="phoneContent">
  <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b>Latest Blogs</b></p>
          <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

<div id="carouselExampleControls1s1" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">

    <div class="row" style="padding:15px;">

        <div class="col-lg-12 col-md-12 col-xs-12">
        <div class="card" style='width:100%;margin-top:5px;'>
                                      <div class="card-body">
                                          <img src="<?php echo e(asset('images/ultimage-guide-app-store.jpg')); ?>" style='width:100%;height:100px;'>

                                          <p style='font-size: 18px;margin-top: 20px;'>App Store Optimization<br><br> Aug 21, 2020</p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet.
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>


                                      </div>
                                  </div>
        </div>
    </div>

    </div>
    <div class="carousel-item">
    <div class="row" style="padding:15px;">

        <div class="col-lg-12 col-md-12 col-xs-12">
        <div class="card" style='width:100%'>
                                      <div class="card-body">
                                          <img src="<?php echo e(asset('images/ultimage-guide-app-store.jpg')); ?>" style='width:100%;height:100px;'>

                                          <p style='font-size: 18px;margin-top: 20px;'>App Store Optimization <br><br> Aug 21, 2020</p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet.
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>


                                      </div>
                                  </div>
        </div>
    </div>
    </div>

  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls1s1" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls1s1" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>

      </div>

  <div class="col-lg-5 col-md-5 col-xs-12 deskContent">
  <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b>Latest Blogs</b></p>
          <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

  <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">

    <div class="row" style="padding:5px;">
        <div class="col-lg-6 col-md-6 col-xs-12">
        <div class="card" style='width:100%;margin-top:5px;'>
                                      <div class="card-body" >
                                         <p style='font-size: 18px;'>App Store Optimization (ASO) The Ultimate ASO Guide 2020 <br>
                                              <br> Aug 21, 2020
                                          </p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet. The best part, you ask? I'm going ...
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>

                                          <img src="<?php echo e(asset('images/ultimage-guide-app-store.jpg')); ?>" style='width:100%;height:100px;margin-top:20px ;'>

                                      </div>
                                  </div>
        </div>
        <div class="col-lg-6 col-md-6 col-xs-12">
        <div class="card" style='width:100%;margin-top:5px;'>
                                      <div class="card-body">
                                          <img src="<?php echo e(asset('images/seo-tools-20201.jpg')); ?>" style='width:100%;height:100px;'>

                                          <p style='font-size: 18px;margin-top: 20px;'>App Store Optimization (ASO) The Ultimate ASO Guide 2020 <br><br> Aug 21, 2020</p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet. The best part, you ask? I'm going ...
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>


                                      </div>
                                  </div>
        </div>
    </div>

    </div>
    <div class="carousel-item">

    <div class="row" style="padding:5px;">
        <div class="col-lg-6 col-md-6 col-xs-12">
        <div class="card" style='width:100%;margin-top:5px;'>
                                      <div class="card-body" >
                                         <p style='font-size: 18px;'>App Store Optimization (ASO) The Ultimate ASO Guide 2020 <br>
                                              <br> Aug 21, 2020
                                          </p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet. The best part, you ask? I'm going ...
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>

                                          <img src="<?php echo e(asset('images/ultimage-guide-app-store.jpg')); ?>" style='width:100%;height:100px;margin-top:20px ;'>

                                      </div>
                                  </div>
        </div>
        <div class="col-lg-6 col-md-6 col-xs-12">
        <div class="card" style='width:100%;margin-top:5px;'>
                                      <div class="card-body">
                                          <img src="<?php echo e(asset('images/seo-tools-20201.jpg')); ?>" style='width:100%;height:100px;'>

                                          <p style='font-size: 18px;margin-top: 20px;'>App Store Optimization (ASO) The Ultimate ASO Guide 2020 <br><br> Aug 21, 2020</p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet. The best part, you ask? I'm going ...
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>


                                      </div>
                                  </div>
        </div>
    </div>

    </div>
    <div class="carousel-item">

    <div class="row" style="padding:5px;">
        <div class="col-lg-6 col-md-6 col-xs-12">
        <div class="card" style='width:100%;margin-top:5px;'>
                                      <div class="card-body" >
                                         <p style='font-size: 18px;'>App Store Optimization (ASO) The Ultimate ASO Guide 2020 <br>
                                              <br> Aug 21, 2020
                                          </p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet. The best part, you ask? I'm going ...
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>

                                          <img src="<?php echo e(asset('images/ultimage-guide-app-store.jpg')); ?>" style='width:100%;height:100px;margin-top:20px ;'>

                                      </div>
                                  </div>
        </div>
        <div class="col-lg-6 col-md-6 col-xs-12">
        <div class="card" style='width:100%;margin-top:5px;'>
                                      <div class="card-body">
                                          <img src="<?php echo e(asset('images/seo-tools-20201.jpg')); ?>" style='width:100%;height:100px;'>

                                          <p style='font-size: 18px;margin-top: 20px;'>App Store Optimization (ASO) The Ultimate ASO Guide 2020 <br><br> Aug 21, 2020</p>
                                          <p>
                                              This is the most comprehensive guide to app store optimization on the planet. The best part, you ask? I'm going ...
                                          </p>
                                          <button style="border: 2px solid #276ea2;color: #276ea2;padding: 4px 20px;border-radius: 10px;background-color: white;">Read More</button>


                                      </div>
                                  </div>
        </div>
    </div>

    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<br/>

<p style="font-size: 30px;color:#2b6db4;text-align: center;"><b>Latest News</b></p>
        <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

          <br>

              <div  class="item">
                  <div   style='background-color: white;'>

                  <marquee width="100%" direction="up" height="auto">

                  <p style='padding: 20px 20px 17px;border-radius:10px;background-color: #2b6db4;color:white;font-weight: 600;font-size: 14px;'>
                    cdgbhg jdsbn sdn bsd cbnsd bnsd csd chjsd bc sdbsd.
                    <br><br>
                    <span>15 Jan, 2022</span>
                    </p>

                    <p style='padding: 20px 20px 17px;border-radius:10px;background-color: #2b6db4;color:white;font-weight: 600;font-size: 14px;'>
                    cdgbhg jdsbn sdn bsd cbnsd bnsd csd chjsd bc sdbsd.
                    <br><br>
                    <span>15 Jan, 2022</span>
                    </p>

                    <p style='padding: 20px 20px 17px;border-radius:10px;background-color: #2b6db4;color:white;font-weight: 600;font-size: 14px;'>
                    cdgbhg jdsbn sdn bsd cbnsd bnsd csd chjsd bc sdbsd.
                    <br><br>
                    <span>15 Jan, 2022</span>
                    </p>
</marquee>

                  </div>

              </div>



  </div>

</div>


</div>



<style>
  .parallax {
      /* The image used */
      background-image: url("<?php echo e(asset('images/get in touch.jpg')); ?>");
      /* Set a specific height */
      min-height: 400px;
      /* Create the parallax scrolling effect */
      background-attachment: fixed;
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
  }
</style>


<div class="deskContent">
<div class="parallax">
  <div style="background-color:#2b6db4;opacity:0.8;height: auto;padding:10px;">

      <br>
      <p style="font-size: 30px;color:white;text-align: center;"><b>What Clients say</b></p>
<br>
<div id="carouselExampleControlstts" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">

<div class="row">
    <div class="col-lg-6 col-md-6 col-xs-12">
    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="<?php echo e(asset('images/seo.jpg')); ?>" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
    <div class="col-lg-6 col-md-6 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="<?php echo e(asset('images/seo.jpg')); ?>" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
</div>

    </div>
    <div class="carousel-item">


<div class="row">
    <div class="col-lg-6 col-md-6 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="<?php echo e(asset('images/seo.jpg')); ?>" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
    <div class="col-lg-6 col-md-6 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="<?php echo e(asset('images/seo.jpg')); ?>" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
</div>


    </div>

    <div class="carousel-item">


    <div class="row">
    <div class="col-lg-6 col-md-6 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="<?php echo e(asset('images/seo.jpg')); ?>" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
    <div class="col-lg-6 col-md-6 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="<?php echo e(asset('images/seo.jpg')); ?>" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
</div>


    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControlstts" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControlstts" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


      <div>
          <div>

          </div>
      </div>
  </div>

</div>
</div>


<div class="phoneContent">
<div class="parallax">
  <div style="background-color:#2b6db4;opacity:0.8;height: auto;padding:10px;">

      <br>
      <p style="font-size: 30px;color:white;text-align: center;"><b>What Clients say</b></p>
<br>
<div id="carouselExampleControlstt" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">

<div class="row">
    <!-- <div class="col-lg-6 col-md-6 col-xs-12">

    </div> -->
    <div class="col-lg-12 col-md-12 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="<?php echo e(asset('images/seo.jpg')); ?>" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
</div>

    </div>
    <div class="carousel-item">


<div class="row">
    <!-- <div class="col-lg-6 col-md-6 col-xs-12">
    </div> -->
    <div class="col-lg-12 col-md-12 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="<?php echo e(asset('images/seo.jpg')); ?>" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
</div>


    </div>

    <div class="carousel-item">


    <div class="row">
    <!-- <div class="col-lg-6 col-md-6 col-xs-12">

    </div> -->
    <div class="col-lg-12 col-md-12 col-xs-12">

    <div class="container">
<div class="position:relative;">
<div style="margin-left:auto;margin-right:auto;text-align:center;">
<img class="img-fluid" src="<?php echo e(asset('images/seo.jpg')); ?>" style="border:5px #2b6db4 solid;height:100px;width:100px;border-radius:50%;" alt="livetech">
</div>
</div>
<div class="position:absolute;">
<div style="border:2px solid #2b6db4;margin-top:-20px;padding:10px;background-color:white;border-radius:15px;">

<p align="justify" style="color:#2b6db4;margin-top:20px;">
<i class="fa fa-quote-left" style="color:#2b6db4;" aria-hidden="true"></i>
ckdjsbvn sdnbv jhdx vb dxnc snbd x csdc nbsd chsd cv sdhb.
<i class="fa fa-quote-right" style="color:#2b6db4;" aria-hidden="true"></i>
</p>

<div style="margin-left:auto;margin-right:auto;text-align:center;"><h4   style="margin-right:20px;color:#2b6db4;"><b>- &nbsp; Tony</b></h4></div>

</div>
</div>
</div>

    </div>
</div>


    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControlstt" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControlstt" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


      <div>
          <div>

          </div>
      </div>
  </div>

</div>
</div>



<div style="width:100%;height:100px;background: linear-gradient(
-2deg, #2fc5b9 0%, #2fc5b9 36%, white 37%);"></div>
<div class='container-fluid' style='background-color: #2fc5b9;'>
  <div class='container' >
      <div class='row' >
          <div class='col-lg-12'>
            <br>
            <p style="font-size: 30px;color:white;text-align: center;"><b>Faq's</b></p>

          </div>
          <div>

          </div>
      </div>

      <div class='row' >
          <div class='col-lg-12'>


              <section>
                  <p style='color:white'><i class="fa fa-ravelry" aria-hidden="true"></i> Agile Methodology</p> <button type="button" class="pull-right btn btn-outline-primary" style="margin-top: -40px;color:white;border-color:white;" data-toggle="collapse" data-target="#demo"><i class="fa fa-plus" ></i></button>
                  <section id="demo" class="collapse">

                      <p style="margin-top: 10px;color:white">We provide Agile methodology,it seeks alternatives to traditional project management & help teams respond to unpredictability through incremental, iterative work cadences and empirical feedbacks.</p>

                  </section>
                  <hr style="background-color: white;">
              </section>
              <br>



              <section>
                  <p style='color:white'><i class="fa fa-life-ring" aria-hidden="true"></i> End To End Solution</p> <button type="button" class="pull-right btn btn-outline-primary" style="margin-top: -40px;color:white;border-color:white;" data-toggle="collapse" data-target="#demo1"><i class="fa fa-plus" ></i></button>
                  <section id="demo1" class="collapse">

                      <p style="margin-top: 10px;color:#fff">We provide end to end solution to our customers, it means that the supplier of an application program or system will provide all the hardware and/or software components and resources to meet the customer's requirement.</p>

                  </section>
                  <hr style="background-color: white;">
              </section>
              <br>


              <section>
                  <p style='color:white'><i class="fa fa-laptop" aria-hidden="true"></i> Quality Code</p> <button type="button" class="pull-right btn btn-outline-primary" style="margin-top: -40px;color:white;border-color:white;" data-toggle="collapse" data-target="#demo2"><i class="fa fa-plus" ></i></button>
                  <section id="demo2" class="collapse">

                      <p style="margin-top: 10px;color:#fff">We provide bug-free code to our clients. Our quality products consist of the features highly adhering to the needs of customers.</p>

                  </section>
                  <hr style="background-color: white;">
              </section>
              <br>


              <section>
                  <p style='color:white'><i class="fa fa-language" aria-hidden="true"></i> Onsite Support</p> <button type="button" class="pull-right btn btn-outline-primary" style="margin-top: -40px;color:white;border-color:white;" data-toggle="collapse" data-target="#demo3"><i class="fa fa-plus" ></i></button>
                  <section id="demo3" class="collapse">

                      <p style="margin-top: 10px;color:#fff">We provide onsite support services.The User Support and Engagement On-Site Support group is committed to providing professional, informed, courteous, customer-focused IT services.</p>

                  </section>
                  <hr style="background-color: white;">
              </section>


          </div>
          <div>

          </div>
      </div>
  </div>
</div>
<div style="width:100%;height:100px;background: linear-gradient(-4deg, white 50%,transparent 50%, #2fc5b9 51%)"></div>



<div class="container">
<p style="font-size: 30px;color:#2b6db4;text-align: center;"><b>Case Study</b></p>
        <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">


        <div class="row">
    <div class="col-lg-4 col-md-4 col-xs-12">
        <div class="card" style="box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;">
        <div style="background-image: url('<?php echo e(asset('img/bgg5.png')); ?>');  background-repeat: no-repeat;background-size: auto;">
        <img class="img-fluid img-flip" src="<?php echo e(asset('img/icons/case.png')); ?>" alt="livetech " style="display: block;margin-left: auto;margin-right: auto;" />
<br>
        <h5 style="color:#2b6db4;text-align:center;">Case Study 1</h5>
        <p align="justify">Hdsjcbs xc vfdn xvndf v dn nm.</p>
        <p><a class="btn btn-outline-primary" href="<?php echo e(url('/casestudy')); ?>" role="button">Explore More &raquo; &nbsp;&nbsp; <i class="fa fa-arrow-right-long;"></i></a></p>
</div>
    </div>
    </div>
    <div class="col-lg-4 col-md-4 col-xs-12">
        <div class="card" style="box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;">
        <div style="background-image: url('<?php echo e(asset('img/bgg5.png')); ?>');  background-repeat: no-repeat;background-size: auto;">
        <img class="img-fluid img-flip" src="<?php echo e(asset('img/icons/case.png')); ?>" alt="livetech " style="display: block;margin-left: auto;margin-right: auto;" />
<br>
        <h5 style="color:#2b6db4;text-align:center;">Case Study 1</h5>
        <p align="justify">Hdsjcbs xc vfdn xvndf v dn nm.</p>
        <p><a class="btn btn-outline-primary" href="<?php echo e(url('/casestudy')); ?>" role="button">Explore More &raquo; &nbsp;&nbsp; <i class="fa fa-arrow-right-long;"></i></a></p>
</div>
    </div>
    </div>

    <div class="col-lg-4 col-md-4 col-xs-12">
        <div class="card" style="box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;">
        <div style="background-image: url('<?php echo e(asset('img/bgg5.png')); ?>');  background-repeat: no-repeat;background-size: auto;">
        <img class="img-fluid img-flip" src="<?php echo e(asset('img/icons/case.png')); ?>" alt="livetech " style="display: block;margin-left: auto;margin-right: auto;" />
<br>
        <h5 style="color:#2b6db4;text-align:center;">Case Study 1</h5>
        <p align="justify">Hdsjcbs xc vfdn xvndf v dn nm.</p>
        <p><a class="btn btn-outline-primary" href="<?php echo e(url('/casestudy')); ?>" role="button">Explore More &raquo; &nbsp;&nbsp; <i class="fa fa-arrow-right-long;"></i></a></p>
</div>
    </div>
    </div>


</div>


</div>





<style>
  a{text-decoration:none}
h4{text-align:center;margin:30px 0;color:#444}
.main-timeline{position:relative}
.main-timeline:before{content:"";width:5px;height:100%;border-radius:20px;margin:0 auto;background:#2fc5b9;position:absolute;top:0;left:0;right:0}
.main-timeline .timeline{display:inline-block;margin-bottom:50px;position:relative}
.main-timeline .timeline:before{content:"";width:20px;height:20px;border-radius:50%;border:4px solid #fff;background:#2b6db4;position:absolute;top:50%;left:50%;z-index:1;transform:translate(-50%,-50%)}
.main-timeline .timeline-icon{display:inline-block;width:130px;height:130px;border-radius:50%;border:3px solid #2b6db4;padding:13px;text-align:center;position:absolute;top:50%;left:30%;transform:translateY(-50%)}
.main-timeline .timeline-icon i{display:block;border-radius:50%;background:#2b6db4;font-size:64px;color:#fff;line-height:100px;z-index:1;position:relative}
.main-timeline .timeline-icon:after,.main-timeline .timeline-icon:before{content:"";width:100px;height:4px;background:#2b6db4;position:absolute;top:50%;right:-100px;transform:translateY(-50%)}
.main-timeline .timeline-icon:after{width:70px;height:50px;background:#fff;top:89px;right:-30px}
.main-timeline .timeline-content{width:50%;padding:0 50px;margin:52px 0 0;float:right;position:relative}
.main-timeline .timeline-content:before{content:"";width:70%;height:100%;border:3px solid #2b6db4;border-top:none;border-right:none;position:absolute;bottom:-13px;left:35px}
.main-timeline .timeline-content:after{content:"";width:37px;height:3px;background:#2b6db4;position:absolute;top:13px;left:0}
.main-timeline .title{font-size:20px;font-weight:600;color:#2b6db4;text-transform:uppercase;margin:0 0 5px}
.main-timeline .description{display:inline-block;font-size:16px;color:#404040;line-height:20px;letter-spacing:1px;margin:0}
.main-timeline .timeline:nth-child(even) .timeline-icon{left:auto;right:30%}
.main-timeline .timeline:nth-child(even) .timeline-icon:before{right:auto;left:-100px}
.main-timeline .timeline:nth-child(even) .timeline-icon:after{right:auto;left:-30px}
.main-timeline .timeline:nth-child(even) .timeline-content{float:left}
.main-timeline .timeline:nth-child(even) .timeline-content:before{left:auto;right:35px;transform:rotateY(180deg)}
.main-timeline .timeline:nth-child(even) .timeline-content:after{left:auto;right:0}
.main-timeline .timeline:nth-child(2n) .timeline-content:after,.main-timeline .timeline:nth-child(2n) .timeline-icon i,.main-timeline .timeline:nth-child(2n) .timeline-icon:before,.main-timeline .timeline:nth-child(2n):before{background:#2b6db4}
.main-timeline .timeline:nth-child(2n) .timeline-icon{border-color:#2b6db4}
.main-timeline .timeline:nth-child(2n) .title{color:#2b6db4}
.main-timeline .timeline:nth-child(2n) .timeline-content:before{border-left-color:#2b6db4;border-bottom-color:#2b6db4}
.main-timeline .timeline:nth-child(3n) .timeline-content:after,.main-timeline .timeline:nth-child(3n) .timeline-icon i,.main-timeline .timeline:nth-child(3n) .timeline-icon:before,.main-timeline .timeline:nth-child(3n):before{background:#2b6db4}
.main-timeline .timeline:nth-child(3n) .timeline-icon{border-color:#2b6db4}
.main-timeline .timeline:nth-child(3n) .title{color:#2b6db4}
.main-timeline .timeline:nth-child(3n) .timeline-content:before{border-left-color:#2b6db4;border-bottom-color:#2b6db4}
.main-timeline .timeline:nth-child(4n) .timeline-content:after,.main-timeline .timeline:nth-child(4n) .timeline-icon i,.main-timeline .timeline:nth-child(4n) .timeline-icon:before,.main-timeline .timeline:nth-child(4n):before{background:#2b6db4}
.main-timeline .timeline:nth-child(4n) .timeline-icon{border-color:#2b6db4}
.main-timeline .timeline:nth-child(4n) .title{color:#2b6db4}
.main-timeline .timeline:nth-child(4n) .timeline-content:before{border-left-color:#2b6db4;border-bottom-color:#2b6db4}
@media  only screen and (max-width:1200px){.main-timeline .timeline-icon:before{width:50px;right:-50px}
.main-timeline .timeline:nth-child(even) .timeline-icon:before{right:auto;left:-50px}
.main-timeline .timeline-content{margin-top:75px}
}
@media  only screen and (max-width:990px){.main-timeline .timeline{margin:0 0 10px}
.main-timeline .timeline-icon{left:25%}
.main-timeline .timeline:nth-child(even) .timeline-icon{right:25%}
.main-timeline .timeline-content{margin-top:115px}
}
@media  only screen and (max-width:767px){.main-timeline{padding-top:50px}
.main-timeline:before{left:80px;right:0;margin:0}
.main-timeline .timeline{margin-bottom:70px}
.main-timeline .timeline:before{top:0;left:83px;right:0;margin:0}
.main-timeline .timeline-icon{width:60px;height:60px;line-height:40px;padding:5px;top:0;left:0}
.main-timeline .timeline:nth-child(even) .timeline-icon{left:0;right:auto}
.main-timeline .timeline-icon:before,.main-timeline .timeline:nth-child(even) .timeline-icon:before{width:25px;left:auto;right:-25px}
.main-timeline .timeline-icon:after,.main-timeline .timeline:nth-child(even) .timeline-icon:after{width:25px;height:30px;top:44px;left:auto;right:-5px}
.main-timeline .timeline-icon i{font-size:30px;line-height:45px}
.main-timeline .timeline-content,.main-timeline .timeline:nth-child(even) .timeline-content{width:100%;margin-top:-15px;padding-left:130px;padding-right:5px}
.main-timeline .timeline:nth-child(even) .timeline-content{float:right}
.main-timeline .timeline-content:before,.main-timeline .timeline:nth-child(even) .timeline-content:before{width:50%;left:120px}
.main-timeline .timeline:nth-child(even) .timeline-content:before{right:auto;transform:rotateY(0)}
.main-timeline .timeline-content:after,.main-timeline .timeline:nth-child(even) .timeline-content:after{left:85px}
}
@media  only screen and (max-width:479px){.main-timeline .timeline-content,.main-timeline .timeline:nth-child(2n) .timeline-content{padding-left:110px}
.main-timeline .timeline-content:before,.main-timeline .timeline:nth-child(2n) .timeline-content:before{left:99px}
.main-timeline .timeline-content:after,.main-timeline .timeline:nth-child(2n) .timeline-content:after{left:65px}
}


/******************* Timeline Demo - 6 *****************/
.demo{background:#f2f2f2}
.main-timeline6{overflow:hidden;position:relative}
.main-timeline6 .timeline{width:50%;float:right;position:relative;z-index:1}
.main-timeline6 .timeline:after,.main-timeline6 .timeline:before{position:absolute;top:50%;content:"";display:block;clear:both}
.main-timeline6 .timeline:before{width:40%;height:6px;background:#2fc5b9;left:0;z-index:-1;transform:translateY(-50%)}
.main-timeline6 .timeline:after{width:6px;height:70%;background:#2fc5b9;left:-3px}
.main-timeline6 .timeline-content{width:65%;float:right;padding:0 0 30px 30px;margin-right:15px;background:#fff;border-radius:10px;box-shadow:3px 3px 5px 6px #ccc}
.main-timeline6 .timeline-content:after,.main-timeline6 .timeline-content:before{content:"";width:26px;height:26px;border-radius:50%;background:#2fc5b9;position:absolute;top:50%;left:-13px;z-index:1;transform:translateY(-50%)}
.main-timeline6 .timeline-content:after{left:30%;transform:translate(-50%,-50%)}
.main-timeline6 .year{display:block;font-size:28px;font-weight:700;color:#2fc5b9;text-align:center;padding-left:50px}
.main-timeline6 .content-inner{padding:35px 15px 35px 110px;margin-right:-15px;background:#2fc5b9;border-radius:150px 0 0 150px;position:relative}
.main-timeline6 .content-inner:after,.main-timeline6 .content-inner:before{content:"";border-left:15px solid #2fc5b9;border-top:10px solid transparent;position:absolute;top:-10px;right:0}
.main-timeline6 .content-inner:after{border-top:none;border-bottom:10px solid transparent;top:auto;bottom:-10px}
.main-timeline6 .icon{width:110px;height:100%;text-align:center;position:absolute;top:0;left:0}
.main-timeline6 .icon i{font-size:60px;font-weight:700;color:#fff;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)}
.main-timeline6 .title{font-size:18px;font-weight:500;color:#fff;margin:0 0 5px}
.main-timeline6 .description{font-size:14px;color:#fff;margin:0}
.main-timeline6 .timeline:nth-child(2n) .icon,.main-timeline6 .timeline:nth-child(2n):after,.main-timeline6 .timeline:nth-child(2n):before{left:auto;right:0}
.main-timeline6 .timeline:nth-child(2n):after{right:-3px}
.main-timeline6 .timeline:nth-child(2n) .timeline-content{float:left;padding:0 30px 30px 0;margin:0 0 0 15px}
.main-timeline6 .timeline:nth-child(2n) .timeline-content:after,.main-timeline6 .timeline:nth-child(2n) .timeline-content:before{left:auto;right:-13px}
.main-timeline6 .timeline:nth-child(2n) .timeline-content:after{right:30%;margin-right:-25px}
.main-timeline6 .timeline:nth-child(2n) .year{padding:0 50px 0 0;color:#2b6db4}
.main-timeline6 .timeline:nth-child(2n) .content-inner{padding:35px 110px 35px 15px;margin:0 0 0 -15px;border-radius:0 150px 150px 0}
.main-timeline6 .timeline:nth-child(2n) .content-inner:after,.main-timeline6 .timeline:nth-child(2n) .content-inner:before{border:none;border-right:15px solid #2b6db4;border-top:10px solid transparent;right:auto;left:0}
.main-timeline6 .timeline:nth-child(2n) .content-inner:after{border-top:none;border-bottom:10px solid transparent}
.main-timeline6 .timeline:nth-child(2){margin-top:200px}
.main-timeline6 .timeline:nth-child(odd){margin:-190px 0 0}
.main-timeline6 .timeline:nth-child(even){margin-bottom:70px}
.main-timeline6 .timeline:first-child,.main-timeline6 .timeline:last-child:nth-child(even){margin:0}
.main-timeline6 .timeline:nth-child(2n) .content-inner,.main-timeline6 .timeline:nth-child(2n) .timeline-content:after,.main-timeline6 .timeline:nth-child(2n) .timeline-content:before,.main-timeline6 .timeline:nth-child(2n):after,.main-timeline6 .timeline:nth-child(2n):before{background:#2b6db4}
.main-timeline6 .timeline:nth-child(3n) .content-inner,.main-timeline6 .timeline:nth-child(3n) .timeline-content:after,.main-timeline6 .timeline:nth-child(3n) .timeline-content:before,.main-timeline6 .timeline:nth-child(3n):after,.main-timeline6 .timeline:nth-child(3n):before{background:#2b6db4}
.main-timeline6 .timeline:nth-child(3n) .content-inner:after,.main-timeline6 .timeline:nth-child(3n) .content-inner:before{border-left-color:#006662}
.main-timeline6 .timeline:nth-child(3n) .year{color:#00a3a9}
.main-timeline6 .timeline:nth-child(4n) .content-inner,.main-timeline6 .timeline:nth-child(4n) .timeline-content:after,.main-timeline6 .timeline:nth-child(4n) .timeline-content:before,.main-timeline6 .timeline:nth-child(4n):after,.main-timeline6 .timeline:nth-child(4n):before{background:#2fc5b9}
.main-timeline6 .timeline:nth-child(4n) .content-inner:after,.main-timeline6 .timeline:nth-child(4n) .content-inner:before{border-right-color:#2fc5b9}
.main-timeline6 .timeline:nth-child(4n) .year{color:#2fc5b9}
@media  only screen and (max-width:990px) and (min-width:768px){.main-timeline6 .timeline:after{height:80%}
}
@media  only screen and (max-width:767px){.main-timeline6 .timeline:last-child,.main-timeline6 .timeline:nth-child(even),.main-timeline6 .timeline:nth-child(odd){margin:0}
.main-timeline6 .timeline{width:95%;margin:15px 15px 15px 0!important}
.main-timeline6 .timeline .timeline-content:after,.main-timeline6 .timeline .timeline-content:before,.main-timeline6 .timeline:after,.main-timeline6 .timeline:before{display:none}
.main-timeline6 .timeline-content,.main-timeline6 .timeline:nth-child(2n) .timeline-content{width:100%;float:none;padding:0 0 30px 30px;margin:0}
.main-timeline6 .content-inner,.main-timeline6 .timeline:nth-child(2n) .content-inner{padding:35px 15px 35px 110px;margin:0 -15px 0 0;border-radius:150px 0 0 150px}
.main-timeline6 .timeline:nth-child(2n) .content-inner:after,.main-timeline6 .timeline:nth-child(2n) .content-inner:before{border:none;border-left:15px solid #027dcd;border-top:10px solid transparent;right:0;left:auto}
.main-timeline6 .timeline:nth-child(2n) .content-inner:after{border-top:none;border-bottom:10px solid transparent}
.main-timeline6 .timeline:nth-child(2n) .icon{top:0;left:0}
.main-timeline6 .timeline:nth-child(4n) .content-inner:after,.main-timeline6 .timeline:nth-child(4n) .content-inner:before{border-left-color:#2fc5b9}
}



</style>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('front/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel projects\livetech\resources\views/front/pagedetails7.blade.php ENDPATH**/ ?>