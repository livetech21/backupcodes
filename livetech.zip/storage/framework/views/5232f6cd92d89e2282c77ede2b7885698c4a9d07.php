<?php $__env->startSection('page_title','Livetech-Career'); ?>

<?php $__env->startSection('container'); ?>

<style>
     .card {
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
        transition: 0.3s;
    }

    .card:hover {
      box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
      transition: 0.3s;
      border-left:2px solid #2fc5b9;
      border-right:2px solid #2b6db4;
      border-radius:10px;
  }

    </style>

<img class="img-fluid" src="<?php echo e(asset('img/career.png')); ?>" alt="livetch"/>


<div >
<div class='col-lg-12'>
  <br>
    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b style="color:#2fc5b9;">Careers At</b><b> Livetech</b></p>
    <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

</div>

<div class='container-fluid' style='margin-bottom:10px;'>
  <div class='row'>

<div class="col-lg-6">
  <img src="img/careerimg.png" class="img-fluid" style="height:auto;width:auto;">
</div>
<div class="col-lg-6"  >

<p style="font-size: 20px;font-weight:500;color:#2b6db4;text-align: center;">Who Are We ?</p>
    <hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

  <p align="justify" style="margin-top:10px;color:#067751;font-weight:500;padding:10px;"> We have a vivid presence in the Indian as well as the International market for our top-notch software development services, Being a customer oriented company, we pay special attention to offer our clients an insight driven intuitive service to ensure the best outcome at the most affordable budget.understand the requirement of our customers, thus we have hired the professionals who can think like a customer and deliver the solutions exactly. Our products are totally trend defining that rely on the basis of market's needs. We cover almost all verticals of software solutions from the web to latest android and ios application. We are trying to make customer’s life easy and comfortable through technology because we are making something different for them.</p>

<br/>
<p style="font-size: 20px;font-weight:500;color:#2b6db4;text-align: center;">Where Are We ?</p>
    <hr style="background-color:#2fc5b9;width:100%;height:2px;text-align: center;margin-top: -10px;">

  <p align="justify" style="margin-top:10px;color:#067751;font-weight:500;padding:10px;">LTS is one of the fastest growing software development companies in Delhi NCR that provides one-stop-web-solution to every organization and individual.</p>


</div>

  </div>

</div>
</div>


<div class="container">
<div class='col-lg-12'>
  <br>
    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b style="color:#2fc5b9;">Benifits At</b><b> Livetech</b></p>
    <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

</div>


<div class="row">

<div class="col-lg-3 col-md-3 col-xs-12">
        <div class="card" style="box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;">
        <div style="background-image: url('<?php echo e(asset('img/bgg3.png')); ?>');  background-repeat: no-repeat;background-size: auto;">

<div style="margin-left:auto;margin-right:auto;text-align:center;">        <i class="fa fa-star" style="font-size:70px;color:#2fc5b9;"></i>
</div>
<br>
        <h5 style="color:#2b6db4;text-align:center;background-color:white;padding:5px;">Skill Enhancement</h5>
</div>
    </div>
    </div>
    <div class="col-lg-3 col-md-3 col-xs-12">
        <div class="card" style="box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;">
        <div style="background-image: url('<?php echo e(asset('img/bgg3.png')); ?>');  background-repeat: no-repeat;background-size: auto;">

<div style="margin-left:auto;margin-right:auto;text-align:center;">        <i class="fa fa-cogs" style="font-size:70px;color:#2fc5b9;"></i>
</div>
<br>
        <h5 style="color:#2b6db4;text-align:center;background-color:white;padding:5px;">Work on LiveProjects</h5>
</div>
    </div>
    </div>
    <div class="col-lg-3 col-md-3 col-xs-12">
        <div class="card" style="box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;">
        <div style="background-image: url('<?php echo e(asset('img/bgg3.png')); ?>');  background-repeat: no-repeat;background-size: auto;">

<div style="margin-left:auto;margin-right:auto;text-align:center;">        <i class="fa fa-users" style="font-size:70px;color:#2fc5b9;"></i>
</div>
<br>
        <h5 style="color:#2b6db4;text-align:center;background-color:white;padding:5px;">Client Interaction</h5>
</div>
    </div>
    </div>
    <div class="col-lg-3 col-md-3 col-xs-12">
        <div class="card" style="box-shadow: 0 4px 8px 0 rgba(194, 143, 143, 0.2);
padding:15px;">
        <div style="background-image: url('<?php echo e(asset('img/bgg3.png')); ?>');  background-repeat: no-repeat;background-size: auto;">

<div style="margin-left:auto;margin-right:auto;text-align:center;">        <i class="fa fa-trophy" style="font-size:70px;color:#2fc5b9;"></i>
</div>
<br>
        <h5 style="color:#2b6db4;text-align:center;background-color:white;padding:5px;">Games</h5>
</div>
    </div>
    </div>



</div>




<div class='col-lg-12'>
  <br>
    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b style="color:#2fc5b9;">Drop Your</b><b> Resume</b></p>
    <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

</div>


<?php if(session('message')): ?>
 <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
             <?php echo e(session('message')); ?>


           </div>
            <?php endif; ?>
<form action="<?php echo e(url('resume_form')); ?>" method="post" role="form" class="info-box" enctype="multipart/form-data" >
            	<?php echo csrf_field(); ?>
              <div class="form-row">
                <div class="col form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name"  />
                   <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <p style="color:red;"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email"  />
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <p style="color:red;"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="form-row">
                <div class="col form-group">
                  <input type="number" name="phone" class="form-control" id="phone" placeholder="Your Mobile"  />
                   <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <p style="color:red;"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col form-group">
                  <input type="text" class="form-control" name="college" id="college" placeholder="Your College Name" />
                <?php $__errorArgs = ['college'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <p style="color:red;"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="form-row">
              <div class="col form-group">
                  <input type="text" class="form-control" name="qualification" id="qualification" placeholder="Your highest Qualifications"  />
                <?php $__errorArgs = ['qualification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <p style="color:red;"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

              <div class="col form-group">
                  <input type="text" class="form-control" name="marks" id="marks" placeholder="Your highest Qualification Marks"  />
                <?php $__errorArgs = ['marks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <p style="color:red;"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

</div>
<div class="form-row">
              <div class="col form-group">
                  <input type="text" class="form-control" name="type" id="type" placeholder="Fresher or Experience"  />
                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <p style="color:red;"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


              <div class="col form-group">
                  <input type="text" class="form-control" name="skill" id="skill" placeholder="Skills"  />
                <?php $__errorArgs = ['skill'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <p style="color:red;"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="form-group">
                <textarea class="form-control" name="address" rows="5"   placeholder="Your Address"></textarea>
                  <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <p style="color:red;"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-row">
              <div class="col form-group">
                  <label>Your Photo :</label>
                  <input type="file" class="form-control" name="image" id="image" />
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <p style="color:red;"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col form-group">
                <label>Your Resume : &nbsp;<b style="color:red;">(In pdf formate)</b></label>
                  <input type="file" class="form-control" name="image1" id="image1"  accept="application/pdf" />
                <?php $__errorArgs = ['image1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <p style="color:red;"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

<center>             <button type="submit" class="btn btn-primary">SUBMIT</button></center>
            </form>

      </div>



</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel projects\livetech\resources\views/front/career.blade.php ENDPATH**/ ?>