<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <title><?php echo $__env->yieldContent('page_title'); ?></title>

<style>
a:hover{
    color:green;
}
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  color: white;
  text-align: center;
}
</style>

  </head>


<body>

<header>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a href='/'>
        <img src="<?php echo e(asset('images/livetech.png')); ?>" style='width:100px;height:50px;margin-top:20px;margin-right:50px;'>
    </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('admin/')); ?>"><i class="fa fa-home" style="color:#075196;">&nbsp;&nbsp;<b>Dashboard</b></i></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Pages</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Notifications</a>
      </li>

    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="<?php echo e(url('admin/logout')); ?>" style="color:red;"><span class="fa fa-power-off" ></span> <b>&nbsp;&nbsp;Logout</b></a></li>

    </ul>
  </div>
</nav>
<hr style="color: #28AE7B; margin-top: 0; margin-bottom: 0; border-bottom: 7px solid #28AE7B;">
</hr>
</header>

<br>
<div class="container">
<?php $__env->startSection('container'); ?>
        <?php echo $__env->yieldSection(); ?>
</div>
<br>
<br>
<br>
<br>

<footer class="footer" style="background-color:#075196;">


  <div class="footer-copyright text-center py-3" style="color:white;">© 2022 Copyright:
    <a href="#" style="color:white;"> <b>LTS</b></a>
  </div>


</footer>

</body>

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>


</html>
<?php /**PATH D:\laravel projects\livetech\resources\views/admin/layoutinner.blade.php ENDPATH**/ ?>