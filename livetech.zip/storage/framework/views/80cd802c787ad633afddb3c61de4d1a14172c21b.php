<?php $__env->startSection('page_title','Livetech-Add-testimonials'); ?>

<?php $__env->startSection('container'); ?>

<h1 class="mb10">Add Testimonials</h1>
    <a href="<?php echo e(url('admin/testi')); ?>">
        <button type="button" class="btn btn-primary">
            Show List
        </button>
    </a>
    <br><br>
    <?php if(session()->has('message')): ?>
    <div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
        <?php echo e(session('message')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
    <?php endif; ?>
    <div class="row m-t-30">
        <div class="col-md-12">
        <div class="row">
                <div class="col-lg-10">
                    <div class="card">
                        <div class="card-body">
                            <form action="insert" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <div class="row">

                                    <div class="col-lg-12">
                                            <label for="color" class="control-label mb-1"> Name</label>
                                            <input id="name"  name="name" type="text" class="form-control" aria-required="true" aria-invalid="false" >
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                             <p style="color:red;"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>


                                        <div class="col-lg-12">
                                            <label for="color" class="control-label mb-1"> Description</label>
                                            <textarea id="description1" name="description1" type="text" class="form-control" aria-required="true" aria-invalid="false" required></textarea>
                                            <?php $__errorArgs = ['description1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                             <p style="color:red;"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>


                                        <div class="col-lg-12">
                                            <label for="color" class="control-label mb-1">Image</label>
                                            <input id="image"  name="image" type="file" class="form-control" aria-required="true" aria-invalid="false" >
                                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                                <p style="color:red;"><?php echo e($message); ?></p>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div>
                                  <center>  <button type="submit" class="btn btn-sm btn-primary">
                                        Submit
                                    </button>
</center>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layoutinner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel projects\livetech\resources\views/admin/testi-add.blade.php ENDPATH**/ ?>