<?php $__env->startSection('page_title','Livetech-Dashboard'); ?>

<?php $__env->startSection('container'); ?>

<style>

</style>

<div class="container">
<div class="row">
<div class="col-lg-2 col-md-4 col-xs-12">
<div class="accordion" id="accordionExample">
  <div class="card">
    <div class="card-header" id="headingOne">

        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        <center>        <p style="color:#075196;"><i class="fa fa-pencil"></i><b>Dashboard</b></p></center>
        </button>

    </div>

    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
      <li><a href="<?php echo e(url('admin/testi')); ?>">Show Testimonials</a></li>
      <li><a href="<?php echo e(url('admin/testi/add-testi')); ?>">Add Testimonials</a></li>

      <li><a href="<?php echo e(url('admin/gallery')); ?>">Show Gallery</a></li>
      <li><a href="<?php echo e(url('admin/gallery/add-gallery')); ?>">Add Gallery</a></li>

      <li><a href="<?php echo e(url('admin/news')); ?>">Show News-media</a></li>
      <li><a href="<?php echo e(url('admin/news/add-news')); ?>">Add News-media</a></li>

      <li><a href="<?php echo e(url('admin/blogs')); ?>">Show Blogs</a></li>
      <li><a href="<?php echo e(url('admin/blogs/add-blogs')); ?>">Add Blogs</a></li>
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingTwo">

        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
      <center>        <p style="color:#075196;"><i class="fa fa-edit"></i> &nbsp; <b>Pages</b></p></center>
    </button>

    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
      <div class="card-body">
      <li><a href="<?php echo e(url('admin/pages')); ?>">Show Pages</a></li>
      <li><a href="<?php echo e(url('admin/pages/add-page')); ?>">Add Pages</a></li>

      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingThree">

        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        <center>        <p style="color:#075196;"><i class="fa fa-list"></i> &nbsp; <b>Lists</b></p></center>
        </button>

    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
      <div class="card-body">
      <li><a href="<?php echo e(url('admin/contactlist')); ?>">Contacts</a></li>
      <li><a href="<?php echo e(url('admin/resumelist')); ?>">Resumes</a></li>

      </div>
    </div>
  </div>
</div>
</div>
<div class="col-lg-10 col-md-8 col-xs-12">
<div class="card" style="padding:20px;height:100%;">
<h4 style="color:#075196;">Dashboard</h4>
</div>
</div>
</div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layoutinner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel projects\livetech\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>