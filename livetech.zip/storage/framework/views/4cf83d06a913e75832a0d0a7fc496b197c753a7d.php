<?php $__env->startSection('page_title','Livetech-Blogs'); ?>

<?php $__env->startSection('container'); ?>

<img class="img-fluid" src="<?php echo e(asset('img/blogs.png')); ?>" alt="livetch"/>


<div id="main-content" class="blog-page">
  <div >
  <div class="container">
    <p style="font-size: 30px;color:#2b6db4;text-align: center;"><b>Our Blogs</b></p>
    <hr style="background-color:#2fc5b9;width:20%;height:2px;text-align: center;margin-top: -10px;">

      <div class="row clearfix">

      <div class="col-lg-8 col-md-12 left-box">
      <?php $__currentLoopData = $blog1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="card single_post">
                  <div class="body">
                      <div class="img-post">
                          <img class="d-block img-fluid" src="<?php echo e(asset('uploads/blogs/'.$list1->photo)); ?>" width="100%" alt="First slide">
                      </div>
                      <h5><a href="blog-details.html" style="color:#2b6db4;"><?php echo e($list1->title); ?></a></h5>
                      <p align="justify"><?php echo e(substr($list1->des1,0,200)); ?> ...<a href="<?php echo e(url('blogdetails/'.$list1->id)); ?>">Read More</a></p>
                  </div>
              </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<div class="row">

<?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-4">
    <div class="card" style="padding:5px;" >
                  <div class="body" style="padding:5px;">
                      <div class="img-post">
                          <img class="d-block img-fluid" src="<?php echo e(asset('uploads/blogs/'.$list->photo)); ?>" width="100%" alt="First slide">
                      </div>
                      <h5><a href="<?php echo e(url('blogdetails/'.$list->id)); ?>" style="color:#2b6db4;"><?php echo e($list->title); ?></a></h5>
                      <p align="justify"><?php echo e(substr($list->des1,0,100)); ?> ...<a href="<?php echo e(url('blogdetails/'.$list->id)); ?>">Read More</a></p>
                  </div>
              </div>
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>


          </div>
          <div class="col-lg-4 col-md-12 right-box" style="margin-top:50px;">
              <div class="card">
                  <div class="body search">
                      <div class="input-group m-b-0">
                          <div class="input-group-prepend">
                              <span class="input-group-text"><i class="fa fa-search"></i></span>
                          </div>
                          <input type="text" class="form-control" placeholder="Search...">
                      </div>
                  </div>
              </div>
              <div class="card">
                  <div class="header">
                      <h5>Categories Clouds</h5>
                  </div>
                  <div class="body widget">
                      <ul class="list-unstyled categories-clouds m-b-0">
                          <li><a href="javascript:void(0);" style="color:#2b6db4;">eCommerce</a></li>
                          <li><a href="javascript:void(0);" style="color:#2b6db4;">Microsoft Technologies</a></li>
                          <li><a href="javascript:void(0);" style="color:#2b6db4;">Creative UX</a></li>
                          <li><a href="javascript:void(0);" style="color:#2b6db4;">Wordpress</a></li>
                          <li><a href="javascript:void(0);" style="color:#2b6db4;">Angular JS</a></li>

                      </ul>
                  </div>
              </div>
              <div class="card">
                  <div class="header">
                      <h5>Popular Posts</h5>
                  </div>
                  <div class="body widget popular-post">
                      <div class="row">
                          <div class="col-lg-12">
                              <div class="single_post">
                                  <p class="m-b-0">Apple Introduces Search Ads Basic</p>
                                  <span>jun 22, 2018</span>
                                  <div class="img-post">
                                      <img src="https://via.placeholder.com/280x280/87CEFA/000000" alt="Awesome Image">
                                  </div>
                              </div>
                              <div class="single_post">
                                  <p class="m-b-0">new rules, more cars, more races</p>
                                  <span>jun 8, 2018</span>
                                  <div class="img-post">
                                      <img src="https://via.placeholder.com/280x280/87CEFA/000000" alt="Awesome Image">
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>

          </div>
      </div>

  </div>
</div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel projects\livetech\resources\views/front/blog.blade.php ENDPATH**/ ?>