<?php $__env->startSection('container'); ?>



<h1 class="mb10">Update Banner Image</h1>
    <a href="<?php echo e(url('admin/pages')); ?>">
        <button type="button" class="btn btn-primary">
            Go Back
        </button>
    </a>
    <br><br>
    <?php if(session()->has('message')): ?>
    <div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
        <?php echo e(session('message')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
    <?php endif; ?>
    <div class="row m-t-30">
        <div class="col-md-12">
        <div class="row">
                <div class="col-lg-10">
                    <div class="card">
                        <div class="card-body">
                            <form action="<?php echo e(url('/admin/pages/updatebanner/'.$data['0']->id )); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <div class="row">

                                        <div class="col-lg-12">
                                            <label for="color" class="control-label mb-1">Banner Image</label>
                                            <input id="image1"  name="image1" type="file" class="form-control" aria-required="true" aria-invalid="false" required>
                                            <?php $__errorArgs = ['image1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                                <p style="color:red;"><?php echo e($message); ?></p>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                             <img src="<?php echo e(asset('uploads/pages/bannerimg/'.$data['0']->photo1)); ?>" style="width: 200px; height: 100px;margin:10px;">
                                        </div>



                                    </div>
                                </div>

                                <div>
                                    <center><button id="payment-button" type="submit" class="btn btn-sm btn-primary">
                                        Update
                                    </button>
</center>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layoutinner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel projects\livetech\resources\views/admin/page-edit-banner.blade.php ENDPATH**/ ?>