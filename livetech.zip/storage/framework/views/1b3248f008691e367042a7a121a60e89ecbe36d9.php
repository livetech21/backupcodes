<?php $__env->startSection('page_title','Livetech-Dashboard'); ?>

<?php $__env->startSection('container'); ?>

<?php if(session()->has('message')): ?>
    <div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
        <?php echo e(session('message')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
    <?php endif; ?>
    <h1 class="mb10">Blogs</h1>
    <a href="<?php echo e(url('admin/blogs/add-blogs')); ?>">
        <button type="button" class="btn btn-primary">
            Add Blogs
        </button>
    </a>
    <a href="<?php echo e(url('admin/dashboard/')); ?>">
        <button type="button" class="btn btn-primary">
            Dashboard
        </button>
    </a>
    <div class="row m-t-30">
        <div class="col-md-12">
            <!-- DATA TABLE-->
            <div class="table-responsive m-b-40">
                <table class="table table-secondary">
                    <thead>
                        <tr>
                        <th>Sr.</th>
                            <th>Name</th>
                            <th>Title</th>
                            <th>Subtitle</th>
                            <th>Description A</th>
                            <th>Description B</th>

                            <th>Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($list->id); ?></td>
                            <td><?php echo e($list->name); ?></td>
                            <td><?php echo e($list->title); ?></td>
                            <td><?php echo e($list->subtitle); ?></td>
                            <td><?php echo e($list->des1); ?></td>
                            <td><?php echo e($list->des2); ?></td>


                            <td>
                            <!-- <img src="<?php echo e(asset('storage/testimonials/'.$list->photo)); ?>" style="width: 100px; height: 100px;"> -->
                            <img src="<?php echo e(asset('uploads/blogs/'.$list->photo)); ?>" style="width: 100px; height: 100px;">
                          </td>

                            <td>
                                <a href="<?php echo e(url('admin/blogs/edit/')); ?>/<?php echo e($list->id); ?>"><button type="button" class="btn btn-success"><i class="fa fa-edit" style="color:white;">&nbsp;&nbsp; Edit</i> </button></a>

                                <a href="<?php echo e(url('admin/blogs/delete/')); ?>/<?php echo e($list->id); ?>"><button type="button" class="btn btn-danger"><i class="fa fa-trash" style="color:white;">&nbsp;&nbsp; Delete</i> </button></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- END DATA TABLE-->
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layoutinner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel projects\livetech\resources\views/admin/blogs-list.blade.php ENDPATH**/ ?>